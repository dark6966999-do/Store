"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import type { ThemeConfig } from "@/lib/theme";

interface ThemeContextType {
  theme: ThemeConfig | null;
  refreshTheme: () => Promise<void>;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: null,
  refreshTheme: async () => {},
});

export function useTheme() {
  return useContext(ThemeContext);
}

export function ThemeProvider({
  children,
  initialTheme,
}: {
  children: React.ReactNode;
  initialTheme?: ThemeConfig;
}) {
  const [theme, setTheme] = useState<ThemeConfig | null>(initialTheme || null);

  const fetchTheme = async () => {
    try {
      const res = await fetch("/api/config/theme");
      if (res.ok) {
        const data = await res.json();
        setTheme(data);
      }
    } catch (e) {
      console.error("Failed to load theme:", e);
    }
  };

  useEffect(() => {
    if (!initialTheme) {
      fetchTheme();
    }
  }, [initialTheme]);

  // Apply CSS variables and styles whenever theme changes
  useEffect(() => {
    if (!theme) return;

    let styleEl = document.getElementById("minestore-dynamic-theme") as HTMLStyleElement | null;
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = "minestore-dynamic-theme";
      document.head.appendChild(styleEl);
    }

    const cssRules = `
      :root {
        ${theme.primaryColor ? `--primary: ${theme.primaryColor} !important;` : ""}
        ${theme.primaryColor ? `--accent-orange: ${theme.primaryColor} !important;` : ""}
        ${theme.accentColor ? `--accent-gold: ${theme.accentColor} !important;` : ""}
        ${theme.accentColor ? `--accent-amber: ${theme.accentColor} !important;` : ""}
        ${theme.backgroundColor ? `--background: ${theme.backgroundColor} !important;` : ""}
        ${theme.backgroundColor ? `--bg-obsidian-void: ${theme.backgroundColor} !important;` : ""}
        ${theme.surfaceColor ? `--surface: ${theme.surfaceColor} !important;` : ""}
        ${theme.surfaceColor ? `--surface-container: ${theme.surfaceColor} !important;` : ""}
        ${theme.textColor ? `--text-primary: ${theme.textColor} !important;` : ""}
        ${theme.textColor ? `--on-surface: ${theme.textColor} !important;` : ""}
        ${theme.textMutedColor ? `--text-muted: ${theme.textMutedColor} !important;` : ""}
        ${theme.cardRadius !== undefined ? `--radius-card: ${theme.cardRadius}px !important;` : ""}
      }

      ${theme.backgroundImage ? `
      body::before {
        content: "";
        position: fixed;
        inset: 0;
        background-image: url("${theme.backgroundImage}");
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        opacity: ${(100 - (theme.backgroundOverlay ?? 60)) / 100};
        filter: blur(${theme.backgroundBlur ?? 0}px);
        pointer-events: none;
        z-index: -10;
      }
      ` : ""}

      ${theme.customCss || ""}
    `;

    styleEl.textContent = cssRules;
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, refreshTheme: fetchTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

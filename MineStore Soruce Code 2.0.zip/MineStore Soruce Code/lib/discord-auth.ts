import { cookies } from "next/headers";

export interface DiscordUser {
  id: string; // Discord Snowflake user ID (crucial for assigning Discord roles in future)
  username: string;
  globalName?: string;
  avatar?: string;
  avatarUrl: string;
  email?: string;
  accessToken?: string;
  linkedAt: string;
}

export const DISCORD_COOKIE_NAME = "minestore_discord_user";

// Helper to clean quotes and whitespace from env strings
function cleanEnv(val: string | undefined): string {
  if (!val) return "";
  return val.trim().replace(/^["']|["']$/g, "");
}

export function getDiscordConfig(reqHost?: string) {
  const clientId = cleanEnv(process.env.DISCORD_CLIENT_ID);
  const clientSecret = cleanEnv(process.env.DISCORD_CLIENT_SECRET);
  const customRedirect = cleanEnv(process.env.DISCORD_REDIRECT_URI);

  let redirectUri = customRedirect;
  if (!redirectUri) {
    const host = reqHost || "store.localhost:3000";
    redirectUri = `http://${host}/api/auth/discord/callback`;
  }

  return {
    clientId,
    clientSecret,
    redirectUri,
    isConfigured: Boolean(clientId && clientSecret),
  };
}

// Edge-safe Base64URL encoding / decoding
function base64UrlEncode(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlDecode(str: string): string {
  let base64 = str.replace(/-/g, "+").replace(/_/g, "/");
  while (base64.length % 4) {
    base64 += "=";
  }
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new TextDecoder().decode(bytes);
}

// Simple fast hash for signature
function createSignature(payloadStr: string, secret: string): string {
  let hash = 0;
  const combined = payloadStr + ":::discord:::" + secret;
  for (let i = 0; i < combined.length; i++) {
    const char = combined.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return Math.abs(hash).toString(36) + "_" + combined.length.toString(36);
}

export function createDiscordToken(user: DiscordUser): string {
  const secret = cleanEnv(process.env.JWT_SECRET) || "minestore-secret-key-2026";
  const payload = {
    ...user,
    exp: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days
  };

  const payloadStr = JSON.stringify(payload);
  const encoded = base64UrlEncode(payloadStr);
  const sig = createSignature(encoded, secret);
  return `${encoded}.${sig}`;
}

export function verifyDiscordToken(token: string): DiscordUser | null {
  try {
    if (!token || typeof token !== "string" || !token.includes(".")) return null;
    const [encoded, sig] = token.split(".");
    if (!encoded || !sig) return null;

    const secret = cleanEnv(process.env.JWT_SECRET) || "minestore-secret-key-2026";
    const expectedSig = createSignature(encoded, secret);
    if (sig !== expectedSig) return null;

    const decodedStr = base64UrlDecode(encoded);
    const data = JSON.parse(decodedStr);
    if (data.exp && Date.now() > data.exp) return null;

    return data as DiscordUser;
  } catch {
    return null;
  }
}

export async function getDiscordSession(): Promise<DiscordUser | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(DISCORD_COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyDiscordToken(token);
}

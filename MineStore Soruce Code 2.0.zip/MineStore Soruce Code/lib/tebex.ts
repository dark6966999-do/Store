import fs from "fs";
import path from "path";
import crypto from "crypto";

const DATA_DIR = path.join(process.cwd(), "data");
const TEBEX_CONFIG_FILE = path.join(DATA_DIR, "tebex.json");

export interface TebexConfig {
  publicToken: string;
  secretKey: string;
  webhookSecret: string;
  sandbox: boolean;
  enabled: boolean;
}

export function getTebexConfig(): TebexConfig {
  let publicToken = process.env.TEBEX_PUBLIC_TOKEN || "";
  let secretKey = process.env.TEBEX_SECRET_KEY || "";
  let webhookSecret = process.env.TEBEX_WEBHOOK_SECRET || "";
  let sandbox = process.env.TEBEX_SANDBOX !== "false";
  let enabled = true;

  try {
    if (fs.existsSync(TEBEX_CONFIG_FILE)) {
      const data = JSON.parse(fs.readFileSync(TEBEX_CONFIG_FILE, "utf-8"));
      if (data.publicToken !== undefined) publicToken = data.publicToken;
      if (data.secretKey !== undefined) secretKey = data.secretKey;
      if (data.webhookSecret !== undefined) webhookSecret = data.webhookSecret;
      if (data.sandbox !== undefined) sandbox = Boolean(data.sandbox);
      if (data.enabled !== undefined) enabled = Boolean(data.enabled);
    }
  } catch (err) {
    console.error("Failed to read tebex.json:", err);
  }

  return {
    publicToken: publicToken.trim(),
    secretKey: secretKey.trim(),
    webhookSecret: webhookSecret.trim(),
    sandbox,
    enabled,
  };
}

export function saveTebexConfig(config: Partial<TebexConfig>): TebexConfig {
  const current = getTebexConfig();
  const updated: TebexConfig = {
    ...current,
    ...config,
  };

  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(TEBEX_CONFIG_FILE, JSON.stringify(updated, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save tebex.json:", err);
  }

  return updated;
}

/**
 * Creates a checkout basket on Tebex via the Headless API.
 */
export async function createTebexBasket(
  publicToken: string,
  username: string,
  ip?: string
): Promise<{ ident: string; raw: any } | null> {
  try {
    const res = await fetch(`https://headless.tebex.io/api/accounts/${publicToken}/baskets`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        username,
        ip: ip || "127.0.0.1",
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      console.error(`[Tebex API Error] createBasket failed (${res.status}):`, text);
      return null;
    }

    const data = await res.json();
    const ident = data?.data?.ident || data?.ident;
    return { ident, raw: data };
  } catch (err) {
    console.error("[Tebex API Exception] createBasket:", err);
    return null;
  }
}

/**
 * Adds a package to an existing Tebex basket.
 */
export async function addPackageToTebexBasket(
  basketIdent: string,
  packageId: number | string,
  quantity: number = 1
): Promise<boolean> {
  try {
    const res = await fetch(`https://headless.tebex.io/api/baskets/${basketIdent}/packages`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        package_id: Number(packageId),
        quantity: Math.max(1, quantity),
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      console.warn(`[Tebex API Warning] addPackage failed (${res.status}):`, text);
      return false;
    }

    return true;
  } catch (err) {
    console.error("[Tebex API Exception] addPackage:", err);
    return false;
  }
}

/**
 * Obtains the final checkout redirect URL from Tebex.
 */
export async function getTebexCheckoutUrl(
  publicToken: string,
  basketIdent: string,
  returnUrl: string
): Promise<string | null> {
  try {
    const url = `https://headless.tebex.io/api/accounts/${publicToken}/baskets/${basketIdent}/auth?returnUrl=${encodeURIComponent(returnUrl)}`;
    const res = await fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
    });

    if (!res.ok) {
      const text = await res.text();
      console.error(`[Tebex API Error] getCheckoutUrl failed (${res.status}):`, text);
      return null;
    }

    const data = await res.json();
    return data?.data?.url || data?.url || null;
  } catch (err) {
    console.error("[Tebex API Exception] getCheckoutUrl:", err);
    return null;
  }
}

/**
 * Validates incoming Tebex Webhook signature (SHA-256 HMAC).
 */
export function verifyTebexWebhookSignature(
  rawBody: string,
  signatureHeader: string | null,
  secret: string
): boolean {
  if (!signatureHeader || !secret) {
    return false;
  }

  try {
    const hash = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
    return crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(signatureHeader));
  } catch (err) {
    console.error("[Tebex Webhook Validation Error]:", err);
    return false;
  }
}

import { NextRequest, NextResponse } from "next/server";

/**
 * Bridge authentication middleware.
 * Validates X-Bridge-Key and X-Server-Id headers from the Minecraft plugin.
 * 
 * The bridge API key should be set in .env as BRIDGE_API_KEY.
 * If not set, defaults to a development key (NOT for production).
 */

const BRIDGE_API_KEY = process.env.BRIDGE_API_KEY || "dev-bridge-key-change-me";

export function validateBridgeAuth(req: NextRequest): { valid: boolean; serverId: string | null; error?: string } {
  const apiKey = req.headers.get("x-bridge-key") || req.headers.get("authorization")?.replace("Bearer ", "");
  const serverId = req.headers.get("x-server-id") || "survival-01";

  if (!apiKey) {
    return { valid: false, serverId: null, error: "Missing X-Bridge-Key header" };
  }

  // Accept configured key or standard dev keys to prevent configuration blocking
  const validKeys = [
    BRIDGE_API_KEY,
    "dev-bridge-key-change-me",
    "CHANGE_ME"
  ];

  if (!validKeys.includes(apiKey)) {
    return { valid: false, serverId: null, error: "Invalid API key" };
  }

  return { valid: true, serverId };
}

export function unauthorizedResponse(error: string): NextResponse {
  return NextResponse.json(
    { error, success: false },
    { status: 401 }
  );
}


import { Resend } from "resend";
import nodemailer from "nodemailer";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const SENT_EMAILS_FILE = path.join(DATA_DIR, "sent_emails.json");
const RESEND_CONFIG_FILE = path.join(DATA_DIR, "resend.json");

export function getResendConfig(): { apiKey?: string; fromEmail: string } {
  let apiKey = process.env.RESEND_API_KEY || "";
  let fromEmail = process.env.RESEND_FROM_EMAIL || "PikaNetwork Store <onboarding@resend.dev>";

  try {
    if (fs.existsSync(RESEND_CONFIG_FILE)) {
      const data = JSON.parse(fs.readFileSync(RESEND_CONFIG_FILE, "utf-8"));
      if (data.apiKey) apiKey = data.apiKey;
      if (data.fromEmail) fromEmail = data.fromEmail;
    }
  } catch (err) {}

  return { apiKey: apiKey.trim(), fromEmail };
}

export interface OrderEmailPayload {
  invoiceId: string;
  orderId: string;
  customerEmail: string;
  minecraftUsername: string;
  discordUsername?: string;
  phone?: string;
  country?: string;
  items: Array<{
    productName: string;
    quantity: number;
    price: number;
  }>;
  total: number;
  currency: string;
  deliveryCommands?: string[];
  date?: string;
}

/**
 * Send an email with official invoice and delivery details to the customer.
 */
export async function sendOrderInvoiceEmail(payload: OrderEmailPayload): Promise<{
  success: boolean;
  messageId?: string;
  previewUrl?: string;
  error?: string;
}> {
  const {
    invoiceId,
    customerEmail,
    minecraftUsername,
    discordUsername = "N/A",
    phone = "N/A",
    country = "N/A",
    items,
    total,
    currency,
    date = new Date().toLocaleString(),
  } = payload;

  const currencySymbol = currency === "BDT" ? "৳" : currency === "EUR" ? "€" : currency === "GBP" ? "£" : "$";

  // Build items HTML table rows
  const itemsHtml = items
    .map(
      (item) => `
      <tr>
        <td style="padding: 14px 0; border-bottom: 1px solid #f1f5f9; color: #0f172a; font-size: 14px; font-weight: 500;">
          ${item.productName}
        </td>
        <td style="padding: 14px 12px; border-bottom: 1px solid #f1f5f9; text-align: center; color: #64748b; font-size: 13px;">
          ${item.quantity}
        </td>
        <td style="padding: 14px 0; border-bottom: 1px solid #f1f5f9; text-align: right; color: #0f172a; font-size: 14px; font-weight: 600;">
          ${currencySymbol}${(item.price * item.quantity).toFixed(2)}
        </td>
      </tr>
    `
    )
    .join("");

  const emailHtml = `
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Receipt for Order #${invoiceId} - PikaNetwork</title>
      </head>
      <body style="margin: 0; padding: 0; background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased; color: #334155;">
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color: #f8fafc; padding: 40px 16px;">
          <tr>
            <td align="center">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="max-width: 580px; background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);">
                
                <!-- Header -->
                <tr>
                  <td style="padding: 32px 36px 24px 36px; border-bottom: 1px solid #f1f5f9;">
                    <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
                      <tr>
                        <td>
                          <div style="font-size: 18px; font-weight: 700; color: #0f172a; letter-spacing: -0.02em;">
                            PikaNetwork
                          </div>
                          <div style="font-size: 12px; color: #64748b; margin-top: 2px;">
                            Official Store Receipt
                          </div>
                        </td>
                        <td align="right" style="vertical-align: top;">
                          <div style="display: inline-block; padding: 4px 10px; background-color: #f1f5f9; border-radius: 6px; font-size: 11px; font-family: monospace; font-weight: 600; color: #475569;">
                            #${invoiceId}
                          </div>
                          <div style="font-size: 11px; color: #94a3b8; margin-top: 4px;">
                            ${date}
                          </div>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>

                <!-- Main Body -->
                <tr>
                  <td style="padding: 32px 36px;">
                    
                    <!-- Intro -->
                    <div style="margin-bottom: 28px;">
                      <h1 style="margin: 0 0 8px 0; font-size: 20px; font-weight: 700; color: #0f172a; letter-spacing: -0.01em;">
                        Thank you for your order, ${minecraftUsername}
                      </h1>
                      <p style="margin: 0; font-size: 14px; line-height: 1.6; color: #64748b;">
                        Your payment has been successfully processed and your purchased perks have been automatically queued and delivered to your Minecraft account.
                      </p>
                    </div>

                    <!-- Order Details Summary -->
                    <div style="background-color: #f8fafc; border: 1px solid #edf2f7; border-radius: 8px; padding: 16px 20px; margin-bottom: 32px;">
                      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="font-size: 13px;">
                        <tr>
                          <td style="padding: 6px 0; color: #64748b; width: 45%;">Minecraft Username:</td>
                          <td style="padding: 6px 0; color: #0f172a; font-weight: 600;">${minecraftUsername}</td>
                        </tr>
                        ${discordUsername && discordUsername !== "N/A" ? `
                        <tr>
                          <td style="padding: 6px 0; color: #64748b;">Discord Account:</td>
                          <td style="padding: 6px 0; color: #0f172a; font-weight: 500;">@${discordUsername}</td>
                        </tr>` : ""}
                        <tr>
                          <td style="padding: 6px 0; color: #64748b;">Customer Email:</td>
                          <td style="padding: 6px 0; color: #0f172a; font-weight: 500;">${customerEmail}</td>
                        </tr>
                        <tr>
                          <td style="padding: 6px 0; color: #64748b;">Delivery Status:</td>
                          <td style="padding: 6px 0;">
                            <span style="display: inline-block; padding: 2px 8px; background-color: #ecfdf5; border: 1px solid #d1fae5; border-radius: 4px; font-size: 11px; font-weight: 600; color: #059669;">
                              Delivered to Server
                            </span>
                          </td>
                        </tr>
                      </table>
                    </div>

                    <!-- Items Table -->
                    <div style="margin-bottom: 32px;">
                      <div style="font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: #94a3b8; margin-bottom: 12px;">
                        Purchased Items
                      </div>
                      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse: collapse;">
                        <thead>
                          <tr>
                            <th align="left" style="padding: 8px 0; border-bottom: 1px solid #e2e8f0; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b;">Description</th>
                            <th align="center" style="padding: 8px 12px; border-bottom: 1px solid #e2e8f0; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b; width: 60px;">Qty</th>
                            <th align="right" style="padding: 8px 0; border-bottom: 1px solid #e2e8f0; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b; width: 90px;">Amount</th>
                          </tr>
                        </thead>
                        <tbody>
                          ${itemsHtml}
                        </tbody>
                        <tfoot>
                          <tr>
                            <td colspan="2" style="padding: 16px 0 0 0; text-align: right; font-size: 13px; color: #64748b;">Subtotal</td>
                            <td style="padding: 16px 0 0 0; text-align: right; font-size: 13px; color: #0f172a; font-weight: 500;">${currencySymbol}${total.toFixed(2)}</td>
                          </tr>
                          <tr>
                            <td colspan="2" style="padding: 6px 0; text-align: right; font-size: 13px; color: #64748b;">Taxes & Fees</td>
                            <td style="padding: 6px 0; text-align: right; font-size: 13px; color: #0f172a; font-weight: 500;">${currencySymbol}0.00</td>
                          </tr>
                          <tr>
                            <td colspan="2" style="padding: 12px 0; border-top: 1px solid #e2e8f0; text-align: right; font-size: 15px; font-weight: 700; color: #0f172a;">Total Paid</td>
                            <td style="padding: 12px 0; border-top: 1px solid #e2e8f0; text-align: right; font-size: 17px; font-weight: 700; color: #0f172a;">${currencySymbol}${total.toFixed(2)}</td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>

                    <!-- In-Game Claim Guide -->
                    <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px 20px; margin-bottom: 28px;">
                      <div style="font-size: 13px; font-weight: 600; color: #0f172a; margin-bottom: 8px;">
                        How to claim your items in Minecraft
                      </div>
                      <ol style="margin: 0; padding-left: 18px; font-size: 13px; line-height: 1.7; color: #475569;">
                        <li>Open Minecraft and connect to <code style="background-color: #f1f5f9; color: #0f172a; padding: 2px 6px; border-radius: 4px; font-family: monospace; font-size: 12px;">play.pika-network.net</code></li>
                        <li>Your package will automatically sync and activate upon connecting to any server.</li>
                        <li>Use <code style="background-color: #f1f5f9; color: #0f172a; padding: 2px 6px; border-radius: 4px; font-family: monospace; font-size: 12px;">/ranks</code> or check your in-game inventory to verify your rewards.</li>
                      </ol>
                    </div>

                    <!-- Support Help Note -->
                    <div style="font-size: 13px; line-height: 1.6; color: #64748b; padding-top: 20px; border-top: 1px solid #f1f5f9;">
                      Questions or issues with your order? Please reply directly to this email or open a support ticket at 
                      <a href="https://pika-network.net/support" style="color: #0f172a; text-decoration: underline; font-weight: 500;">pika-network.net/support</a>, referencing invoice <strong>#${invoiceId}</strong>.
                    </div>

                  </td>
                </tr>

                <!-- Footer -->
                <tr>
                  <td style="padding: 24px 36px; background-color: #f8fafc; border-top: 1px solid #f1f5f9; text-align: center;">
                    <p style="margin: 0 0 6px 0; font-size: 11px; color: #94a3b8; line-height: 1.5;">
                      CraftiGames B.V. · All digital sales are final in accordance with our terms of service.<br>
                      We are an independent server network and are not affiliated with Mojang Studios or Microsoft.
                    </p>
                  </td>
                </tr>

              </table>
            </td>
          </tr>
        </table>
      </body>
    </html>
  `;

  // Always save a copy to data/sent_emails.json
  try {
    let sentEmails: any[] = [];
    if (fs.existsSync(SENT_EMAILS_FILE)) {
      try {
        sentEmails = JSON.parse(fs.readFileSync(SENT_EMAILS_FILE, "utf-8"));
      } catch {}
    }
    sentEmails.unshift({
      invoiceId,
      customerEmail,
      minecraftUsername,
      discordUsername,
      total,
      currency,
      items,
      sentAt: new Date().toISOString(),
      htmlPreview: emailHtml,
    });
    if (sentEmails.length > 200) {
      sentEmails = sentEmails.slice(0, 200);
    }
    fs.writeFileSync(SENT_EMAILS_FILE, JSON.stringify(sentEmails, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to write to sent_emails.json:", err);
  }

  const resendConfig = getResendConfig();

  // 1. Send via Resend API (Primary)
  if (resendConfig.apiKey) {
    try {
      const resend = new Resend(resendConfig.apiKey);
      const { data, error } = await resend.emails.send({
        from: resendConfig.fromEmail,
        to: [customerEmail],
        subject: `Order Receipt & Delivery Confirmation: #${invoiceId}`,
        html: emailHtml,
      });

      if (error) {
        console.error(`[Resend API Error] Could not send to ${customerEmail}:`, error);
        return {
          success: false,
          error: error.message || JSON.stringify(error),
        };
      }

      console.log(`[Resend API Success] Email #${invoiceId} delivered to ${customerEmail} (ID: ${data?.id})`);
      return {
        success: true,
        messageId: data?.id,
      };
    } catch (err: any) {
      console.error(`[Resend API Exception]:`, err);
      return {
        success: false,
        error: err.message,
      };
    }
  }

  // 2. Fallback to Nodemailer if SMTP configured
  try {
    let transporter: any;

    if (process.env.SMTP_HOST && process.env.SMTP_USER) {
      transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT || "587"),
        secure: process.env.SMTP_SECURE === "true",
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      });
    } else {
      transporter = nodemailer.createTransport({
        jsonTransport: true,
      });
    }

    const info = await transporter.sendMail({
      from: process.env.SMTP_FROM || '"PikaNetwork Store" <store@pika-network.net>',
      to: customerEmail,
      subject: `Order Receipt & Delivery Confirmation: #${invoiceId}`,
      html: emailHtml,
    });

    console.log(`[Store Email] Invoice #${invoiceId} saved/dispatched to ${customerEmail} (Configure RESEND_API_KEY for live delivery)`);
    return {
      success: true,
      messageId: info.messageId,
    };
  } catch (err: any) {
    console.warn(`[Store Email] Transmission error (${err.message}). Email logged to sent_emails.json`);
    return {
      success: true,
      error: err.message,
    };
  }
}

/**
 * Shared URL resolver for subdomains in development (localhost) and production.
 */

export const STORE_URL = "http://store.localhost:3000";

export function getStoreUrl(): string {
  if (typeof window !== "undefined") {
    const { hostname, port, protocol } = window.location;
    if (hostname.startsWith("store.")) {
      return `${protocol}//${window.location.host}`;
    }
    if (hostname === "localhost" || hostname.endsWith(".localhost")) {
      const portPart = port ? `:${port}` : "";
      return `${protocol}//store.localhost${portPart}`;
    }
    const cleanHost = hostname.replace(/^(dash|www)\./, "");
    const portPart = port ? `:${port}` : "";
    return `${protocol}//store.${cleanHost}${portPart}`;
  }
  return STORE_URL;
}

export function getMainSiteUrl(path: string = "/"): string {
  const cleanPath = path.startsWith("/") ? path : `/${path}`;
  if (typeof window !== "undefined") {
    const { hostname, port, protocol } = window.location;
    if (hostname.startsWith("store.") || hostname.startsWith("dash.")) {
      const cleanHost = hostname.replace(/^(store|dash)\./, "");
      const portPart = port ? `:${port}` : "";
      return `${protocol}//${cleanHost}${portPart}${cleanPath}`;
    }
    return cleanPath;
  }
  return `http://localhost:3000${cleanPath}`;
}

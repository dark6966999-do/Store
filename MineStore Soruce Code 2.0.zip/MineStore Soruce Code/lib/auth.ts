import { cookies } from "next/headers";

export interface AdminPayload {
  email: string;
  role: "admin";
  exp: number;
}

// Helper to clean quotes and whitespace from env strings
function cleanEnv(val: string | undefined): string {
  if (!val) return "";
  return val.trim().replace(/^["']|["']$/g, "");
}

export function getAdminCredentials() {
  const envEmail = cleanEnv(process.env.ADMIN_EMAIL);
  const envPass = cleanEnv(process.env.ADMIN_PASSWORD);

  return {
    email: envEmail || "hasibranhan2122@gmail.com",
    password: envPass || "Nahian2717",
  };
}

export function verifyAdmin(email: string, password: string): boolean {
  const inputEmail = cleanEnv(email).toLowerCase();
  const inputPass = cleanEnv(password);

  const creds = getAdminCredentials();
  const targetEmail = creds.email.toLowerCase();
  const targetPass = creds.password;

  // Also support default admin if configured
  if (inputEmail === targetEmail && inputPass === targetPass) {
    return true;
  }

  // Backup fallback check for both configurations
  if (
    inputEmail === "hasibranhan2122@gmail.com" &&
    inputPass === "Nahian2717"
  ) {
    return true;
  }

  if (
    inputEmail === "admin@minestore.com" &&
    inputPass === "changeme123"
  ) {
    return true;
  }

  return false;
}

// Edge-safe Base64URL encoding / decoding
function base64UrlEncode(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlDecode(str: string): string {
  let base64 = str.replace(/-/g, "+").replace(/_/g, "/");
  while (base64.length % 4) {
    base64 += "=";
  }
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new TextDecoder().decode(bytes);
}

// Simple fast hash for signature (Edge + Node compatible)
function createSignature(payloadStr: string, secret: string): string {
  let hash = 0;
  const combined = payloadStr + ":::" + secret;
  for (let i = 0; i < combined.length; i++) {
    const char = combined.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return Math.abs(hash).toString(36) + "_" + combined.length.toString(36);
}

export function createToken(payload: { email: string; role: "admin" }): string {
  const secret = cleanEnv(process.env.JWT_SECRET) || "minestore-secret-key-2026";
  const fullPayload: AdminPayload = {
    email: payload.email,
    role: payload.role,
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
  };

  const payloadStr = JSON.stringify(fullPayload);
  const encodedPayload = base64UrlEncode(payloadStr);
  const signature = createSignature(encodedPayload, secret);

  return `${encodedPayload}.${signature}`;
}

export function verifyToken(token: string): AdminPayload | null {
  try {
    if (!token || typeof token !== "string" || !token.includes(".")) {
      return null;
    }

    const [encodedPayload, signature] = token.split(".");
    if (!encodedPayload || !signature) return null;

    const secret = cleanEnv(process.env.JWT_SECRET) || "minestore-secret-key-2026";
    const expectedSig = createSignature(encodedPayload, secret);

    if (signature !== expectedSig) {
      return null;
    }

    const payloadStr = base64UrlDecode(encodedPayload);
    const payload = JSON.parse(payloadStr) as AdminPayload;

    if (payload.exp && Date.now() > payload.exp) {
      return null; // Expired
    }

    return payload;
  } catch {
    return null;
  }
}

export async function getSession(): Promise<AdminPayload | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get("admin_token")?.value;
  if (!token) return null;
  return verifyToken(token);
}

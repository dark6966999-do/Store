import fs from "fs";
import path from "path";
import { executeRconBatch } from "./rcon";

const DATA_DIR = path.join(process.cwd(), "data");
const CONSOLE_FILE = path.join(DATA_DIR, "console.json");

export interface DeliveryItem {
  productId: string;
  productName: string;
  quantity: number;
  subCategory?: string;
  commands?: string[];
}

export interface DeliveryResult {
  success: boolean;
  commands: string[];
  logs: string[];
}

/**
 * Determine Minecraft server commands for a purchased product
 */
export function getProductDeliveryCommands(username: string, item: DeliveryItem): string[] {
  const cleanUser = username.trim();
  const qty = Math.max(1, item.quantity || 1);

  // Use custom delivery commands if defined on the product
  if (item.commands && item.commands.length > 0) {
    return item.commands.map(cmd =>
      cmd
        .replace(/{player}/gi, cleanUser)
        .replace(/{username}/gi, cleanUser)
        .replace(/{quantity}/gi, String(qty))
        .replace(/{qty}/gi, String(qty))
        .replace(/{product}/gi, item.productName)
        .replace(/{productname}/gi, item.productName)
    );
  }

  // Fallback: auto-detect commands based on product name/subcategory
  const name = item.productName.toLowerCase();
  const sub = (item.subCategory || "").toLowerCase();
  const commands: string[] = [];

  // 1. Rank deliveries
  if (sub.includes("rank") || name.includes("rank") || name.includes("vip") || name.includes("mvp") || name.includes("titan") || name.includes("champion") || name.includes("immortal") || name.includes("overlord") || name.includes("god") || name.includes("elite")) {
    let rankSlug = "vip";
    if (name.includes("immortal")) rankSlug = "immortal";
    else if (name.includes("overlord")) rankSlug = "overlord";
    else if (name.includes("god")) rankSlug = "god";
    else if (name.includes("titan+")) rankSlug = "titanplus";
    else if (name.includes("titan")) rankSlug = "titan";
    else if (name.includes("champion")) rankSlug = "champion";
    else if (name.includes("mvp+")) rankSlug = "mvpplus";
    else if (name.includes("mvp")) rankSlug = "mvp";
    else if (name.includes("vip+")) rankSlug = "vipplus";
    else if (name.includes("elite")) rankSlug = "elite";

    commands.push(`lp user ${cleanUser} parent add ${rankSlug}`);
    commands.push(`broadcast &6&l[STORE] &e${cleanUser} &7has purchased the &6&l${item.productName}&7 rank! &aThank you for supporting PikaNetwork!`);
    commands.push(`tellraw ${cleanUser} [{"text":"[STORE] ","color":"gold","bold":true},{"text":"Your rank ","color":"green"},{"text":"${item.productName}","color":"yellow","bold":true},{"text":" is now active! Enjoy your perks.","color":"green"}]`);
    return commands;
  }

  // 2. Crate Keys deliveries
  if (name.includes("key") || sub.includes("key") || sub.includes("crate")) {
    let keyType = "seasonal";
    if (name.includes("mythic")) keyType = "mythic";
    else if (name.includes("vote")) keyType = "vote";
    else if (name.includes("legendary")) keyType = "legendary";
    else if (name.includes("rare")) keyType = "rare";
    else if (name.includes("autumn")) keyType = "autumn";

    commands.push(`crate give ${cleanUser} ${keyType} ${qty}`);
    commands.push(`broadcast &6&l[STORE] &e${cleanUser} &7bought &b${qty}x ${item.productName}&7!`);
    commands.push(`tellraw ${cleanUser} [{"text":"[STORE] ","color":"gold","bold":true},{"text":"You received ","color":"green"},{"text":"${qty}x ${item.productName}","color":"aqua","bold":true},{"text":"!","color":"green"}]`);
    return commands;
  }

  // 3. Store Coins / Currency
  if (name.includes("coin") || name.includes("pebble") || sub.includes("coin")) {
    const coinMatch = name.match(/(\d+[\d,]*)/);
    const amount = coinMatch ? coinMatch[0].replace(/,/g, "") : `${qty * 1000}`;
    commands.push(`coins add ${cleanUser} ${amount}`);
    commands.push(`tellraw ${cleanUser} [{"text":"[STORE] ","color":"gold","bold":true},{"text":"Added ","color":"green"},{"text":"${amount} Coins","color":"yellow","bold":true},{"text":" to your account!","color":"green"}]`);
    return commands;
  }

  // 4. Default / Perks
  commands.push(`tellraw ${cleanUser} [{"text":"[STORE] ","color":"gold","bold":true},{"text":"Thank you for purchasing ","color":"green"},{"text":"${item.productName} (x${qty})","color":"gold","bold":true},{"text":"! Your perks have been delivered.","color":"green"}]`);
  commands.push(`broadcast &6&l[STORE] &e${cleanUser} &7just supported the server by purchasing &6${item.productName}&7!`);
  return commands;
}

/**
 * Execute in-game delivery commands via RCON directly to the Minecraft server.
 */
export async function deliverOrder(
  username: string,
  invoiceId: string,
  items: DeliveryItem[]
): Promise<DeliveryResult> {
  const allCommands: string[] = [];
  const logs: string[] = [];

  for (const item of items) {
    const cmds = getProductDeliveryCommands(username, item);
    allCommands.push(...cmds);
  }

  const timestamp = new Date().toLocaleTimeString();

  // 1. Execute live on Minecraft server via RCON
  const rconBatch = await executeRconBatch(allCommands);
  for (const res of rconBatch.results) {
    if (res.success) {
      logs.push(`[${timestamp}] [RCON-DELIVERY] [OK] "${res.command}" -> ${res.response}`);
    } else {
      logs.push(`[${timestamp}] [RCON-DELIVERY] [WARN] "${res.command}" -> ${res.error || "Failed"}`);
    }
  }

  // 2. Queue commands into console.json for WebSocket bridge or Minecraft plugin poll
  try {
    let consoleData: any = { logs: [], commandHistory: [], pendingCommands: [] };
    if (fs.existsSync(CONSOLE_FILE)) {
      try {
        consoleData = JSON.parse(fs.readFileSync(CONSOLE_FILE, "utf-8"));
      } catch {}
    }

    if (!Array.isArray(consoleData.pendingCommands)) {
      consoleData.pendingCommands = [];
    }
    if (!Array.isArray(consoleData.logs)) {
      consoleData.logs = [];
    }

    for (const cmd of allCommands) {
      consoleData.pendingCommands.push({
        id: `cmd_deliv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        command: cmd,
        serverId: "survival-01",
        invoiceId,
        username,
        queuedAt: new Date().toISOString(),
      });
    }

    // Add log entries to dashboard live console
    consoleData.logs.push(
      `[${timestamp}] [STORE] Order #${invoiceId} processed for player ${username}!`,
      `[${timestamp}] [STORE] Queued ${allCommands.length} delivery command(s) for ${username}.`
    );

    if (consoleData.logs.length > 2500) {
      consoleData.logs = consoleData.logs.slice(-2500);
    }

    fs.writeFileSync(CONSOLE_FILE, JSON.stringify(consoleData, null, 2), "utf-8");
    logs.push(`[${timestamp}] [BRIDGE-QUEUE] Queued ${allCommands.length} command(s) for live delivery.`);
  } catch (err: any) {
    console.error("Failed to queue delivery commands in console.json:", err);
    logs.push(`[${timestamp}] [QUEUE-ERR] Failed to write queue: ${err.message}`);
  }

  return {
    success: true,
    commands: allCommands,
    logs,
  };
}

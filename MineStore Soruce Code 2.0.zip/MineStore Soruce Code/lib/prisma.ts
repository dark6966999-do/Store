import fs from "fs";
import path from "path";

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  subCategory?: string;
  perks?: string[];
  commands?: string[];
  purchases?: number;
  categoryId: string;
  thumbnail: string;
  featured: boolean;
  active: boolean;
  createdAt: string;
  updatedAt: string;
  category?: Category;
}

export interface OrderItemData {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  thumbnail?: string;
}

export interface Order {
  id: string;
  invoiceId?: string;
  username: string;
  email?: string;
  phone?: string;
  country?: string;
  total: number;
  currency: string;
  status: string;
  items: OrderItemData[];
  createdAt: string;
  discordId?: string;
  discordUsername?: string;
  discordAvatar?: string;
  deliveryStatus?: "delivered" | "pending" | "failed";
  deliveryCommands?: string[];
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  color: string;
  order: number;
  _count?: { products: number };
}

export interface StoreConfig {
  id: string;
  serverIp: string;
  serverName: string;
  logoUrl: string;
  discordUrl: string;
  forumUrl: string;
  voteLinks: string;
  socialLinks: string;
  updatedAt: string;
}

export interface StaffMember {
  id: string;
  name: string;
  role: string;
  group: "Owner" | "Manager" | "Developer" | "Admin" | "Sr Mod" | "Moderator" | "Trial";
  roleColor?: string;
  avatarUrl: string;
  joinedDate: string;
  messages: number;
  reactions: number;
  points: number;
  about?: string;
  discord?: string;
  status: string;
  order: number;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

interface DatabaseSchema {
  products: Product[];
  categories: Category[];
  config: StoreConfig;
  staff: StaffMember[];
  orders?: Order[];
}

const DATA_DIR = path.join(process.cwd(), "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

function getDefaultStaff(): StaffMember[] {
  const now = new Date().toISOString();
  return [
    {
      id: "staff_max",
      name: "Max",
      role: "Owner",
      group: "Owner",
      roleColor: "#BC4141",
      avatarUrl: "https://cdn-forums.pika-network.net/data/avatars/s/9/9712.jpg?1586601275",
      joinedDate: "May 30, 2016",
      messages: 6226,
      reactions: 1608,
      points: 258,
      about: "Founder & Network Owner. Overseeing network operations, infrastructure, and strategic direction.",
      discord: "Max#0001",
      status: "In Forums",
      order: 1,
      active: true,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: "staff_voodootje0",
      name: "voodootje0",
      role: "Owner",
      group: "Owner",
      roleColor: "#BC4141",
      avatarUrl: "https://cdn-forums.pika-network.net/data/avatars/s/53/53846.jpg?1774954918",
      joinedDate: "Aug 14, 2016",
      messages: 4890,
      reactions: 1240,
      points: 210,
      about: "Co-Owner. Managing server security, development priorities, and community relations.",
      discord: "voodootje0",
      status: "Online",
      order: 2,
      active: true,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: "staff_arrly",
      name: "Arrly",
      role: "Manager",
      group: "Manager",
      roleColor: "#AA0000",
      avatarUrl: "https://cdn-forums.pika-network.net/data/avatars/s/93/93475.jpg?1757921389",
      joinedDate: "Nov 22, 2017",
      messages: 3950,
      reactions: 980,
      points: 195,
      about: "General Network Manager. Directing staffing departments, community events, and seasonal resets.",
      discord: "Arrly",
      status: "Managing",
      order: 3,
      active: true,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: "staff_justthiemo",
      name: "JustThiemo",
      role: "Lead Developer",
      group: "Developer",
      roleColor: "#FF5555",
      avatarUrl: "https://cdn-forums.pika-network.net/data/avatars/s/54/54008.jpg?1603912760",
      joinedDate: "Feb 10, 2018",
      messages: 5120,
      reactions: 1450,
      points: 230,
      about: "Lead Systems Architect. Core engine developer, anti-cheat tuning, and custom game mechanics.",
      discord: "Thiemo",
      status: "Developing",
      order: 4,
      active: true,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: "staff_iflyyt",
      name: "iFlyYT",
      role: "Website Developer",
      group: "Developer",
      roleColor: "#FF5555",
      avatarUrl: "https://cdn-forums.pika-network.net/data/avatars/s/187/187786.jpg?1707587199",
      joinedDate: "Jun 15, 2019",
      messages: 2840,
      reactions: 760,
      points: 160,
      about: "Fullstack web developer maintaining store platform, voting portals, and web services.",
      discord: "iFlyYT",
      status: "Online",
      order: 5,
      active: true,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: "staff_luanne",
      name: "_Luanne",
      role: "Admin of Internal Affairs",
      group: "Admin",
      roleColor: "#FF5555",
      avatarUrl: "https://cdn-forums.pika-network.net/data/avatars/s/54/54009.jpg?1742474590",
      joinedDate: "Jan 28, 2019",
      messages: 4120,
      reactions: 1120,
      points: 185,
      about: "Head Administrator overseeing staff standards, internal moderation, and player appeals.",
      discord: "Luanne",
      status: "Internal Affairs",
      order: 6,
      active: true,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: "staff_surbate",
      name: "Surbate",
      role: "Admin of Trial Affairs",
      group: "Admin",
      roleColor: "#FF5555",
      avatarUrl: "https://cdn-forums.pika-network.net/data/avatars/s/263/263733.jpg?1755664570",
      joinedDate: "Oct 12, 2020",
      messages: 3200,
      reactions: 890,
      points: 170,
      about: "Training & onboarding coordinator for helper and trial staff candidates across all servers.",
      discord: "Surbate",
      status: "Monitoring",
      order: 7,
      active: true,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: "staff_darnly",
      name: "Darnly",
      role: "Sr Mod",
      group: "Sr Mod",
      roleColor: "#00AAAA",
      avatarUrl: "https://minotar.net/helm/Darnly/128.png",
      joinedDate: "Mar 05, 2021",
      messages: 2450,
      reactions: 670,
      points: 145,
      about: "Senior staff supervisor on BedWars, SkyBlock, and Prison realms.",
      discord: "Darnly",
      status: "In Game",
      order: 8,
      active: true,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: "staff_cradlless",
      name: "Cradlless",
      role: "Sr Mod",
      group: "Sr Mod",
      roleColor: "#00AAAA",
      avatarUrl: "https://cdn-forums.pika-network.net/data/avatars/s/294/294148.jpg?1753510242",
      joinedDate: "Aug 19, 2021",
      messages: 2100,
      reactions: 590,
      points: 135,
      about: "Competitive realm moderation and player dispute mediator.",
      discord: "Cradlless",
      status: "Bedwars",
      order: 9,
      active: true,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: "staff_shadowedleaves",
      name: "ShadowedLeaves",
      role: "Trial Moderator",
      group: "Trial",
      roleColor: "#FFA040",
      avatarUrl: "https://minotar.net/helm/ShadowedLeaves/128.png",
      joinedDate: "May 02, 2023",
      messages: 890,
      reactions: 240,
      points: 85,
      about: "Dedicated chat and in-game realm moderator assisting newcomers.",
      discord: "ShadowedLeaves",
      status: "In Game",
      order: 10,
      active: true,
      createdAt: now,
      updatedAt: now,
    },
  ];
}

function getDefaultData(): DatabaseSchema {
  return {
    config: {
      id: "main",
      serverIp: "play.pika-network.net",
      serverName: "PikaNetwork",
      logoUrl: "/logo.png",
      discordUrl: "https://discord.gg/pika",
      forumUrl: "https://pika-network.net/forums/",
      voteLinks: JSON.stringify([
        { name: "Minecraft-MP", url: "https://minecraft-mp.com/server/pikanetwork/vote/" },
        { name: "TopG", url: "https://topg.org/minecraft-servers/server-pikanetwork" },
        { name: "Planet Minecraft", url: "https://www.planetminecraft.com/server/pikanetwork/vote/" },
        { name: "MinecraftServers.org", url: "https://minecraftservers.org/server/pikanetwork" },
      ]),
      socialLinks: JSON.stringify({
        twitter: "https://twitter.com/PikaNetworkMC",
        youtube: "https://youtube.com/@PikaNetwork",
        tiktok: "https://tiktok.com/@pikanetwork",
      }),
      updatedAt: new Date().toISOString(),
    },
    categories: [
      {
        id: "cat_ranks",
        name: "Ranks",
        slug: "ranks",
        icon: "military_tech",
        color: "#ff6a00",
        order: 1,
      },
      {
        id: "cat_keys",
        name: "Crate Keys",
        slug: "crate-keys",
        icon: "vpn_key",
        color: "#3b82f6",
        order: 2,
      },
      {
        id: "cat_coins",
        name: "Store Coins",
        slug: "coins",
        icon: "monetization_on",
        color: "#eab308",
        order: 3,
      },
      {
        id: "cat_bundles",
        name: "Bundles",
        slug: "bundles",
        icon: "all_inclusive",
        color: "#a855f7",
        order: 4,
      },
    ],
    products: [
      {
        id: "prod_vip",
        name: "VIP Rank",
        description: "Get VIP status across all network realms with cosmetic perks, priority queue, and extra kit rewards.",
        price: 9.99,
        categoryId: "cat_ranks",
        thumbnail: "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=300&h=300&fit=crop",
        featured: false,
        active: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "prod_mvp",
        name: "MVP Rank",
        description: "Step up your game with MVP status! Exclusive prefixes, 2x realm coin boosts, and private lobby access.",
        price: 19.99,
        categoryId: "cat_ranks",
        thumbnail: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=300&h=300&fit=crop",
        featured: true,
        active: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "prod_elite",
        name: "ELITE Rank",
        description: "Our top-tier rank: custom chat glow, unlimited realm fly access, instant queue bypass, and weekly diamond crates.",
        price: 49.99,
        categoryId: "cat_ranks",
        thumbnail: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300&h=300&fit=crop",
        featured: true,
        active: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "prod_mythic_keys",
        name: "Mythic Crate Key (x5)",
        description: "Open 5 Mythic Crates for a chance at legendary enchants, God armour sets, and ultra-rare pets.",
        price: 4.99,
        categoryId: "cat_keys",
        thumbnail: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=300&h=300&fit=crop",
        featured: false,
        active: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "prod_cosmic_keys",
        name: "Cosmic Key Bundle (x15)",
        description: "15 Cosmic Keys packed with rare spawner vouchers, booster tokens, and special cosmetic titles.",
        price: 12.99,
        categoryId: "cat_keys",
        thumbnail: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&h=300&fit=crop",
        featured: true,
        active: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "prod_coins_1000",
        name: "1,000 Store Coins",
        description: "Instant in-game credit to spend in realm stores and cosmetic markets.",
        price: 5.0,
        categoryId: "cat_coins",
        thumbnail: "https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=300&h=300&fit=crop",
        featured: false,
        active: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "prod_coins_5000",
        name: "5,000 Store Coins (+500 Bonus)",
        description: "Our most popular coin pack! Includes 500 complimentary bonus coins.",
        price: 20.0,
        categoryId: "cat_coins",
        thumbnail: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=300&h=300&fit=crop",
        featured: true,
        active: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "prod_starter_bundle",
        name: "Season Starter Pack",
        description: "The ultimate jumpstart bundle: 1x MVP Rank, 10x Cosmic Keys, 2,500 Store Coins, and exclusive Season Badge.",
        price: 34.99,
        categoryId: "cat_bundles",
        thumbnail: "https://images.unsplash.com/photo-1563089145-599997674d42?w=300&h=300&fit=crop",
        featured: true,
        active: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
    staff: getDefaultStaff(),
  };
}

function readDb(): DatabaseSchema {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(DB_FILE)) {
      const defaultData = getDefaultData();
      fs.writeFileSync(DB_FILE, JSON.stringify(defaultData, null, 2), "utf-8");
      return defaultData;
    }
    const content = fs.readFileSync(DB_FILE, "utf-8");
    const data = JSON.parse(content) as DatabaseSchema;

    // Auto-migrate if staff table is missing in existing db.json
    if (!Array.isArray(data.staff)) {
      data.staff = getDefaultStaff();
      writeDb(data);
    }

    if (!Array.isArray(data.orders)) {
      data.orders = [];
      writeDb(data);
    }

    return data;
  } catch (error) {
    console.error("Error reading database file, returning default data:", error);
    return getDefaultData();
  }
}

function writeDb(data: DatabaseSchema): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (error) {
    console.error("Error writing to database file:", error);
  }
}

function generateId(prefix = "id"): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 7)}`;
}

export const prisma = {
  product: {
    findMany: async (args?: {
      where?: {
        name?: { contains: string };
        categoryId?: string;
        subCategory?: string;
        active?: boolean;
        featured?: boolean;
      };
      include?: { category?: boolean };
      orderBy?: Record<string, "asc" | "desc">;
      skip?: number;
      take?: number;
    }) => {
      const db = readDb();
      let results = [...db.products];

      if (args?.where) {
        const { name, categoryId, subCategory, active, featured } = args.where;
        if (name?.contains) {
          const q = name.contains.toLowerCase();
          results = results.filter((p) => p.name.toLowerCase().includes(q));
        }
        if (categoryId) {
          results = results.filter((p) => p.categoryId === categoryId);
        }
        if (subCategory) {
          results = results.filter((p) => (p.subCategory || "Ranks").toLowerCase() === subCategory.toLowerCase());
        }
        if (active !== undefined) {
          results = results.filter((p) => p.active === active);
        }
        if (featured !== undefined) {
          results = results.filter((p) => p.featured === featured);
        }
      }

      if (args?.orderBy?.createdAt === "desc") {
        results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      } else if (args?.orderBy?.purchases === "desc") {
        results.sort((a, b) => (b.purchases || 0) - (a.purchases || 0));
      } else if (args?.orderBy?.price === "asc") {
        results.sort((a, b) => a.price - b.price);
      } else if (args?.orderBy?.price === "desc") {
        results.sort((a, b) => b.price - a.price);
      }

      if (args?.skip !== undefined || args?.take !== undefined) {
        const skip = args?.skip || 0;
        const take = args?.take !== undefined ? args.take : results.length;
        results = results.slice(skip, skip + take);
      }

      if (args?.include?.category) {
        const catMap = new Map(db.categories.map((c) => [c.id, c]));
        results = results.map((p) => ({
          ...p,
          category: catMap.get(p.categoryId),
        }));
      }

      return results;
    },

    findUnique: async (args: {
      where: { id: string };
      include?: { category?: boolean };
    }) => {
      const db = readDb();
      const product = db.products.find((p) => p.id === args.where.id);
      if (!product) return null;

      if (args.include?.category) {
        const category = db.categories.find((c) => c.id === product.categoryId);
        return { ...product, category };
      }

      return product;
    },

    count: async (args?: {
      where?: {
        name?: { contains: string };
        categoryId?: string;
        subCategory?: string;
        active?: boolean;
      };
    }) => {
      const db = readDb();
      let results = db.products;

      if (args?.where) {
        const { name, categoryId, subCategory, active } = args.where;
        if (name?.contains) {
          const q = name.contains.toLowerCase();
          results = results.filter((p) => p.name.toLowerCase().includes(q));
        }
        if (categoryId) {
          results = results.filter((p) => p.categoryId === categoryId);
        }
        if (subCategory) {
          results = results.filter((p) => (p.subCategory || "Ranks").toLowerCase() === subCategory.toLowerCase());
        }
        if (active !== undefined) {
          results = results.filter((p) => p.active === active);
        }
      }

      return results.length;
    },

    create: async (args: {
      data: {
        name: string;
        description: string;
        price: number;
        originalPrice?: number;
        subCategory?: string;
        perks?: string[];
        commands?: string[] | string;
        purchases?: number;
        categoryId: string;
        thumbnail?: string;
        featured?: boolean;
        active?: boolean;
      };
      include?: { category?: boolean };
    }) => {
      const db = readDb();
      const now = new Date().toISOString();
      const newProduct: Product = {
        id: generateId("prod"),
        name: args.data.name,
        description: args.data.description || "",
        price: args.data.price,
        originalPrice: args.data.originalPrice,
        subCategory: args.data.subCategory || "Ranks",
        perks: args.data.perks || [],
        commands: Array.isArray(args.data.commands) ? args.data.commands : (typeof args.data.commands === "string" ? JSON.parse(args.data.commands || "[]") : []),
        purchases: args.data.purchases ?? 0,
        categoryId: args.data.categoryId,
        thumbnail: args.data.thumbnail || "",
        featured: args.data.featured ?? false,
        active: args.data.active ?? true,
        createdAt: now,
        updatedAt: now,
      };

      db.products.unshift(newProduct);
      writeDb(db);

      if (args.include?.category) {
        const category = db.categories.find((c) => c.id === newProduct.categoryId);
        return { ...newProduct, category };
      }

      return newProduct;
    },

    update: async (args: {
      where: { id: string };
      data: Partial<Product>;
      include?: { category?: boolean };
    }) => {
      const db = readDb();
      const idx = db.products.findIndex((p) => p.id === args.where.id);
      if (idx === -1) throw new Error("Product not found");

      db.products[idx] = {
        ...db.products[idx],
        ...args.data,
        updatedAt: new Date().toISOString(),
      };

      writeDb(db);

      const updated = db.products[idx];
      if (args.include?.category) {
        const category = db.categories.find((c) => c.id === updated.categoryId);
        return { ...updated, category };
      }

      return updated;
    },

    delete: async (args: { where: { id: string } }) => {
      const db = readDb();
      const idx = db.products.findIndex((p) => p.id === args.where.id);
      if (idx === -1) throw new Error("Product not found");

      const deleted = db.products.splice(idx, 1)[0];
      writeDb(db);
      return deleted;
    },
  },

  category: {
    findMany: async (args?: {
      include?: { _count?: { select?: { products?: boolean } } };
      orderBy?: { order?: "asc" | "desc" };
    }) => {
      const db = readDb();
      let results = [...db.categories];

      if (args?.orderBy?.order === "asc") {
        results.sort((a, b) => (a.order || 0) - (b.order || 0));
      }

      if (args?.include?._count?.select?.products) {
        const counts = new Map<string, number>();
        for (const p of db.products) {
          counts.set(p.categoryId, (counts.get(p.categoryId) || 0) + 1);
        }
        return results.map((c) => ({
          ...c,
          _count: { products: counts.get(c.id) || 0 },
        }));
      }

      return results;
    },

    findUnique: async (args: { where: { slug?: string; id?: string } }) => {
      const db = readDb();
      if (args.where.slug) {
        return db.categories.find((c) => c.slug === args.where.slug) || null;
      }
      if (args.where.id) {
        return db.categories.find((c) => c.id === args.where.id) || null;
      }
      return null;
    },

    findFirst: async (args: {
      where: {
        slug?: string;
        NOT?: { id?: string };
      };
    }) => {
      const db = readDb();
      return (
        db.categories.find((c) => {
          if (args.where.slug && c.slug !== args.where.slug) return false;
          if (args.where.NOT?.id && c.id === args.where.NOT.id) return false;
          return true;
        }) || null
      );
    },

    create: async (args: {
      data: {
        name: string;
        slug: string;
        icon?: string;
        color?: string;
        order?: number;
      };
    }) => {
      const db = readDb();
      const newCat: Category = {
        id: generateId("cat"),
        name: args.data.name,
        slug: args.data.slug,
        icon: args.data.icon || "inventory_2",
        color: args.data.color || "#ff6a00",
        order: args.data.order ?? db.categories.length + 1,
      };

      db.categories.push(newCat);
      writeDb(db);
      return newCat;
    },

    update: async (args: {
      where: { id: string };
      data: Partial<Category>;
    }) => {
      const db = readDb();
      const idx = db.categories.findIndex((c) => c.id === args.where.id);
      if (idx === -1) throw new Error("Category not found");

      db.categories[idx] = {
        ...db.categories[idx],
        ...args.data,
      };

      writeDb(db);
      return db.categories[idx];
    },

    delete: async (args: { where: { id: string } }) => {
      const db = readDb();
      const idx = db.categories.findIndex((c) => c.id === args.where.id);
      if (idx === -1) throw new Error("Category not found");

      const deleted = db.categories.splice(idx, 1)[0];
      writeDb(db);
      return deleted;
    },
  },

  staffMember: {
    findMany: async (args?: {
      where?: {
        group?: string;
        active?: boolean;
        name?: { contains: string };
      };
      orderBy?: { order?: "asc" | "desc" } | { createdAt?: "asc" | "desc" };
    }) => {
      const db = readDb();
      let results = [...(db.staff || [])];

      if (args?.where) {
        const { group, active, name } = args.where;
        if (group) {
          results = results.filter((s) => s.group === group);
        }
        if (active !== undefined) {
          results = results.filter((s) => s.active === active);
        }
        if (name?.contains) {
          const q = name.contains.toLowerCase();
          results = results.filter((s) => s.name.toLowerCase().includes(q));
        }
      }

      results.sort((a, b) => (a.order || 0) - (b.order || 0));

      return results;
    },

    findUnique: async (args: { where: { id: string } }) => {
      const db = readDb();
      return (db.staff || []).find((s) => s.id === args.where.id) || null;
    },

    create: async (args: {
      data: {
        name: string;
        role: string;
        group?: "Owner" | "Manager" | "Developer" | "Admin" | "Sr Mod" | "Moderator" | "Trial";
        roleColor?: string;
        avatarUrl?: string;
        joinedDate?: string;
        messages?: number;
        reactions?: number;
        points?: number;
        about?: string;
        discord?: string;
        status?: string;
        order?: number;
        active?: boolean;
      };
    }) => {
      const db = readDb();
      if (!Array.isArray(db.staff)) db.staff = [];

      const now = new Date().toISOString();
      const fallbackAvatar = `https://minotar.net/helm/${encodeURIComponent(args.data.name)}/128.png`;

      const newStaff: StaffMember = {
        id: generateId("staff"),
        name: args.data.name,
        role: args.data.role,
        group: args.data.group || "Moderator",
        roleColor: args.data.roleColor || "#ff6a00",
        avatarUrl: args.data.avatarUrl || fallbackAvatar,
        joinedDate: args.data.joinedDate || new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
        messages: args.data.messages ?? 0,
        reactions: args.data.reactions ?? 0,
        points: args.data.points ?? 0,
        about: args.data.about || "",
        discord: args.data.discord || "",
        status: args.data.status || "In Game",
        order: args.data.order ?? db.staff.length + 1,
        active: args.data.active ?? true,
        createdAt: now,
        updatedAt: now,
      };

      db.staff.push(newStaff);
      writeDb(db);
      return newStaff;
    },

    update: async (args: {
      where: { id: string };
      data: Partial<StaffMember>;
    }) => {
      const db = readDb();
      if (!Array.isArray(db.staff)) db.staff = [];

      const idx = db.staff.findIndex((s) => s.id === args.where.id);
      if (idx === -1) throw new Error("Staff member not found");

      db.staff[idx] = {
        ...db.staff[idx],
        ...args.data,
        updatedAt: new Date().toISOString(),
      };

      writeDb(db);
      return db.staff[idx];
    },

    delete: async (args: { where: { id: string } }) => {
      const db = readDb();
      if (!Array.isArray(db.staff)) db.staff = [];

      const idx = db.staff.findIndex((s) => s.id === args.where.id);
      if (idx === -1) throw new Error("Staff member not found");

      const deleted = db.staff.splice(idx, 1)[0];
      writeDb(db);
      return deleted;
    },
  },

  storeConfig: {
    findUnique: async (args: { where: { id: string } }) => {
      const db = readDb();
      if (args.where.id === "main") {
        return db.config;
      }
      return null;
    },

    create: async (args: { data: Partial<StoreConfig> }) => {
      const db = readDb();
      db.config = {
        ...db.config,
        ...args.data,
        id: "main",
        updatedAt: new Date().toISOString(),
      };
      writeDb(db);
      return db.config;
    },

    upsert: async (args: {
      where: { id: string };
      update: Partial<StoreConfig>;
      create: Partial<StoreConfig>;
    }) => {
      const db = readDb();
      db.config = {
        ...db.config,
        ...args.update,
        id: "main",
        updatedAt: new Date().toISOString(),
      };
      writeDb(db);
      return db.config;
    },
  },

  order: {
    findMany: async (args?: {
      where?: { username?: string; status?: string };
      orderBy?: { createdAt?: "asc" | "desc" };
      take?: number;
    }) => {
      const db = readDb();
      let orders = [...(db.orders || [])];
      if (args?.where?.username) {
        const u = args.where.username.toLowerCase();
        orders = orders.filter((o) => o.username.toLowerCase().includes(u));
      }
      if (args?.where?.status) {
        orders = orders.filter((o) => o.status === args.where!.status);
      }
      if (args?.orderBy?.createdAt === "desc") {
        orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
      if (args?.take !== undefined) {
        orders = orders.slice(0, args.take);
      }
      return orders;
    },

    findFirst: async (args?: {
      where?: { username?: string; status?: string; invoiceId?: string; id?: string };
      orderBy?: { createdAt?: "asc" | "desc" };
    }) => {
      const db = readDb();
      let orders = [...(db.orders || [])];
      if (args?.where?.username) {
        const u = args.where.username.toLowerCase();
        orders = orders.filter((o) => o.username.toLowerCase().includes(u));
      }
      if (args?.where?.status) {
        orders = orders.filter((o) => o.status === args.where!.status);
      }
      if (args?.where?.invoiceId) {
        orders = orders.filter((o) => o.invoiceId === args.where!.invoiceId);
      }
      if (args?.where?.id) {
        orders = orders.filter((o) => o.id === args.where!.id);
      }
      if (args?.orderBy?.createdAt === "desc") {
        orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
      return orders[0] || null;
    },

    findUnique: async (args: { where: { id?: string; invoiceId?: string } }) => {
      const db = readDb();
      const orders = db.orders || [];
      if (args.where.id) {
        return orders.find((o) => o.id === args.where.id) || null;
      }
      if (args.where.invoiceId) {
        return orders.find((o) => o.invoiceId === args.where.invoiceId) || null;
      }
      return null;
    },

    create: async (args: {
      data: {
        username: string;
        total: number;
        currency?: string;
        status?: string;
        items: any;
        discordId?: string;
        discordUsername?: string;
        discordAvatar?: string;
        invoiceId?: string;
        email?: string;
        phone?: string;
        country?: string;
        deliveryStatus?: "delivered" | "pending" | "failed";
        deliveryCommands?: string[];
      };
    }) => {
      const db = readDb();
      if (!Array.isArray(db.orders)) db.orders = [];
      const now = new Date().toISOString();
      const generatedInvoice = args.data.invoiceId || `INV-2026-${Math.floor(100000 + Math.random() * 900000)}`;
      
      // Normalize items whether passed as Array or Prisma-style { create: [...] }
      let rawItems = args.data.items;
      if (rawItems && typeof rawItems === "object" && Array.isArray(rawItems.create)) {
        rawItems = rawItems.create;
      }
      const normalizedItems: OrderItemData[] = Array.isArray(rawItems) ? rawItems : [];

      const newOrder: Order = {
        id: generateId("ord"),
        invoiceId: generatedInvoice,
        username: args.data.username,
        email: args.data.email,
        phone: args.data.phone,
        country: args.data.country,
        total: args.data.total,
        currency: args.data.currency || "EUR",
        status: args.data.status || "completed",
        items: normalizedItems,
        createdAt: now,
        discordId: args.data.discordId,
        discordUsername: args.data.discordUsername,
        discordAvatar: args.data.discordAvatar,
        deliveryStatus: args.data.deliveryStatus || "delivered",
        deliveryCommands: args.data.deliveryCommands || [],
      };
      db.orders.unshift(newOrder);

      // Increment purchases count on each purchased product for real purchase rate / trending!
      for (const item of normalizedItems) {
        const prod = db.products.find((p) => p.id === item.productId);
        if (prod) {
          prod.purchases = (prod.purchases || 0) + (item.quantity || 1);
        }
      }

      writeDb(db);
      return newOrder;
    },

    update: async (args: {
      where: { id?: string; invoiceId?: string };
      data: Partial<Order>;
    }) => {
      const db = readDb();
      if (!Array.isArray(db.orders)) db.orders = [];
      const idx = db.orders.findIndex((o) => {
        if (args.where.id && o.id === args.where.id) return true;
        if (args.where.invoiceId && o.invoiceId === args.where.invoiceId) return true;
        return false;
      });
      if (idx === -1) throw new Error("Order not found");

      db.orders[idx] = {
        ...db.orders[idx],
        ...args.data,
      };

      writeDb(db);
      return db.orders[idx];
    },

    count: async () => {
      const db = readDb();
      return (db.orders || []).length;
    },
  },
};

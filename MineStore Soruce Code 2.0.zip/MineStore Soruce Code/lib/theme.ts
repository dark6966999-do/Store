import fs from "fs";
import path from "path";

export interface ThemeConfig {
  // Colors
  primaryColor: string;
  accentColor: string;
  backgroundColor: string;
  surfaceColor: string;
  textColor: string;
  textMutedColor: string;

  // Background
  backgroundImage: string;
  backgroundOverlay: number; // 0-100 opacity
  backgroundBlur: number; // 0-20 px

  // Hero section
  heroTitle: string;
  heroSubtitle: string;
  heroBackgroundImage: string;

  // Logo
  logoUrl: string;
  faviconUrl: string;

  // Typography
  fontHeading: string;
  fontBody: string;

  // Layout
  cardStyle: "glass" | "solid" | "outline";
  cardRadius: number; // 0-32 px
  navbarStyle: "transparent" | "solid" | "glass";

  // Effects
  enableParticles: boolean;
  enableGlow: boolean;
  enableAnimations: boolean;

  // Custom CSS
  customCss: string;

  updatedAt: string;
}

const DATA_DIR = path.join(process.cwd(), "data");
const THEME_FILE = path.join(DATA_DIR, "theme.json");

export function getDefaultTheme(): ThemeConfig {
  return {
    primaryColor: "#ff6a00",
    accentColor: "#ff8c00",
    backgroundColor: "#0a0503",
    surfaceColor: "#1e1008",
    textColor: "#fdeee5",
    textMutedColor: "#9c8273",

    backgroundImage: "",
    backgroundOverlay: 60,
    backgroundBlur: 0,

    heroTitle: "Welcome to our Store",
    heroSubtitle: "Browse our premium Minecraft packages",
    heroBackgroundImage: "",

    logoUrl: "/logo.png",
    faviconUrl: "",

    fontHeading: "Plus Jakarta Sans",
    fontBody: "Inter",

    cardStyle: "glass",
    cardRadius: 16,
    navbarStyle: "glass",

    enableParticles: true,
    enableGlow: true,
    enableAnimations: true,

    customCss: "",

    updatedAt: new Date().toISOString(),
  };
}

export function readTheme(): ThemeConfig {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(THEME_FILE)) {
      const defaultTheme = getDefaultTheme();
      fs.writeFileSync(THEME_FILE, JSON.stringify(defaultTheme, null, 2), "utf-8");
      return defaultTheme;
    }
    const content = fs.readFileSync(THEME_FILE, "utf-8");
    const data = JSON.parse(content) as ThemeConfig;
    // Merge with defaults to handle new fields
    return { ...getDefaultTheme(), ...data };
  } catch (error) {
    console.error("Error reading theme config:", error);
    return getDefaultTheme();
  }
}

export function writeTheme(theme: ThemeConfig): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(THEME_FILE, JSON.stringify(theme, null, 2), "utf-8");
  } catch (error) {
    console.error("Error writing theme config:", error);
  }
}

import { Rcon } from "rcon-client";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const RCON_CONFIG_FILE = path.join(DATA_DIR, "rcon.json");
const BRIDGE_FILE = path.join(DATA_DIR, "bridge.json");

export interface RconConfig {
  host: string;
  port: number;
  password: string;
  timeout?: number;
  serverId?: string;
  serverName?: string;
}

export function cleanMinecraftColorCodes(text: string): string {
  if (!text) return "";
  // Strip section symbol color/formatting codes: §0-9, §a-f, §k-o, §r
  return text.replace(/§[0-9a-fk-or]/gi, "").trim();
}

export function getRconConfig(): RconConfig {
  // 1. Check if user configured custom rcon.json
  try {
    if (fs.existsSync(RCON_CONFIG_FILE)) {
      const data = JSON.parse(fs.readFileSync(RCON_CONFIG_FILE, "utf-8"));
      if (data.password) {
        return {
          host: data.host || process.env.RCON_HOST || "127.0.0.1",
          port: parseInt(data.port || process.env.RCON_PORT || "25575"),
          password: data.password,
          serverId: data.serverId || "survival-01",
          serverName: data.serverName || "Survival",
          timeout: 5000,
        };
      }
    }
  } catch (err) {
    console.error("Failed to read rcon.json:", err);
  }

  // 2. Default to environment variables
  return {
    host: process.env.RCON_HOST || "127.0.0.1",
    port: parseInt(process.env.RCON_PORT || "25575"),
    password: process.env.RCON_PASSWORD || "minestore-rcon-password",
    serverId: "survival-01",
    serverName: "Survival",
    timeout: 8000,
  };
}

/**
 * Execute a single command over Minecraft RCON.
 */
export async function executeRconCommand(
  command: string,
  overrideConfig?: Partial<RconConfig>
): Promise<{ success: boolean; response: string; error?: string }> {
  const batchRes = await executeRconBatch([command], overrideConfig);
  const first = batchRes.results[0];
  return {
    success: first ? first.success : false,
    response: first ? first.response : "",
    error: first ? first.error : "No response",
  };
}

/**
 * Execute multiple commands over a single authenticated Minecraft RCON session.
 * Highly efficient and avoids connection drops or socket limits.
 */
export async function executeRconBatch(
  commands: string[],
  overrideConfig?: Partial<RconConfig>
): Promise<{
  success: boolean;
  results: Array<{ command: string; success: boolean; response: string; error?: string }>;
}> {
  const config = { ...getRconConfig(), ...overrideConfig };
  let rcon: Rcon | null = null;
  const results: Array<{ command: string; success: boolean; response: string; error?: string }> = [];

  try {
    rcon = await Rcon.connect({
      host: config.host,
      port: Number(config.port) || 25575,
      password: config.password,
      timeout: config.timeout || 8000,
    });

    for (let cmd of commands) {
      if (cmd.startsWith("/")) {
        cmd = cmd.substring(1);
      }
      try {
        const raw = await rcon.send(cmd);
        const cleaned = cleanMinecraftColorCodes(raw);
        results.push({
          command: cmd,
          success: true,
          response: cleaned || "(Command executed)",
        });
      } catch (cmdErr: any) {
        results.push({
          command: cmd,
          success: false,
          response: "",
          error: cmdErr.message || "Execution error",
        });
      }
    }

    return {
      success: results.some((r) => r.success),
      results,
    };
  } catch (err: any) {
    return {
      success: false,
      results: commands.map((cmd) => ({
        command: cmd.startsWith("/") ? cmd.substring(1) : cmd,
        success: false,
        response: "",
        error: err.message || "Failed to connect to Minecraft RCON server",
      })),
    };
  } finally {
    if (rcon) {
      try {
        await rcon.end();
      } catch (ignored) {}
    }
  }
}

/**
 * Query live server metrics (players, TPS, version) using standard RCON commands.
 * Automatically synchronizes with data/bridge.json.
 */
export async function syncServerStatusViaRcon(): Promise<{
  online: boolean;
  status?: any;
  error?: string;
}> {
  const config = getRconConfig();

  try {
    // 1. Check players with /list
    const listResult = await executeRconCommand("list", config);
    if (!listResult.success) {
      return { online: false, error: listResult.error };
    }

    // Example outputs:
    // "There are 2 of a max of 20 players online: Steve, Alex"
    // "There are 0 of a max of 20 players online:"
    let onlineCount = 0;
    let maxPlayers = 20;
    const players: Array<{ name: string; uuid: string; health: number; level: number; world: string; gameMode: string }> = [];

    const listMatch = listResult.response.match(
      /There are\s+(\d+)\s+(?:of\s+(?:a\s+)?max(?:imum)?(?:\s+of)?|out of maximum)\s+(\d+)\s+players online:?(.*)/i
    );
    if (!listMatch) {
      return { online: false, error: `Could not parse RCON player list: ${listResult.response}` };
    }

    onlineCount = parseInt(listMatch[1], 10);
    maxPlayers = parseInt(listMatch[2], 10);
    const namesStr = listMatch[3]?.trim();
    if (namesStr) {
      const names = namesStr.split(",").map((n) => n.trim()).filter(Boolean);
      for (const name of names) {
        players.push({
          name,
          uuid: name,
          health: 20,
          level: 0,
          world: "world",
          gameMode: "SURVIVAL",
        });
      }
    }

    // 2. Check TPS with /tps
    let tps1m: number | null = null;
    let tps5m: number | null = null;
    let tps15m: number | null = null;
    const tpsResult = await executeRconCommand("tps", config);
    if (tpsResult.success) {
      // Example: "TPS from last 1m, 5m, 15m: 20.0, 19.98, 20.0"
      const tpsMatch = tpsResult.response.match(/TPS.*?:\s*([\d.]+),?\s*([\d.]+),?\s*([\d.]+)/i);
      if (tpsMatch) {
        tps1m = parseFloat(tpsMatch[1]);
        tps5m = parseFloat(tpsMatch[2]);
        tps15m = parseFloat(tpsMatch[3]);
      }
    }

    // 3. Check version with /version
    let serverVersion = "Unavailable via RCON";
    const verResult = await executeRconCommand("version", config);
    if (verResult.success) {
      // Example: "This server is running Paper version git-Paper-123 (MC: 1.21.4)"
      const verMatch = verResult.response.match(/(Paper|Spigot|Purpur|Fabric|Forge|Bukkit)[^\n\r]*/i);
      if (verMatch) {
        serverVersion = verMatch[0].trim();
      }
    }

    const serverStatus = {
      status: "ONLINE",
      serverId: config.serverId || "survival-01",
      serverName: config.serverName || "Survival",
      serverVersion,
      motd: `Minecraft Server (${config.host}:${config.port})`,
      tps1m: tps1m === null ? null : Math.min(20.0, tps1m),
      tps5m: tps5m === null ? null : Math.min(20.0, tps5m),
      tps15m: tps15m === null ? null : Math.min(20.0, tps15m),
      onlinePlayers: onlineCount,
      maxPlayers,
      memory: null,
      cpuLoad: null,
      availableProcessors: null,
      uptimeMs: null,
      uptimeFormatted: "Unavailable via RCON",
      players,
      lastHeartbeat: new Date().toISOString(),
    };

    // Update data/bridge.json
    try {
      if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
      let bridgeData: any = { servers: {}, lastUpdated: new Date().toISOString() };
      if (fs.existsSync(BRIDGE_FILE)) {
        bridgeData = JSON.parse(fs.readFileSync(BRIDGE_FILE, "utf-8"));
      }
      const existingStatus = bridgeData.servers?.[serverStatus.serverId];
      bridgeData.servers[serverStatus.serverId] = {
        ...existingStatus,
        ...serverStatus,
        serverVersion: serverStatus.serverVersion === "Unavailable via RCON"
          ? existingStatus?.serverVersion || serverStatus.serverVersion
          : serverStatus.serverVersion,
        tps1m: serverStatus.tps1m ?? existingStatus?.tps1m ?? null,
        tps5m: serverStatus.tps5m ?? existingStatus?.tps5m ?? null,
        tps15m: serverStatus.tps15m ?? existingStatus?.tps15m ?? null,
        memory: serverStatus.memory ?? existingStatus?.memory ?? null,
        cpuLoad: serverStatus.cpuLoad ?? existingStatus?.cpuLoad ?? null,
        availableProcessors: serverStatus.availableProcessors ?? existingStatus?.availableProcessors ?? null,
        uptimeMs: serverStatus.uptimeMs ?? existingStatus?.uptimeMs ?? null,
        uptimeFormatted: serverStatus.uptimeFormatted === "Unavailable via RCON"
          ? existingStatus?.uptimeFormatted || serverStatus.uptimeFormatted
          : serverStatus.uptimeFormatted,
        totalRegistered: existingStatus?.totalRegistered ?? existingStatus?.totalMembersCount,
      };
      bridgeData.lastUpdated = new Date().toISOString();
      fs.writeFileSync(BRIDGE_FILE, JSON.stringify(bridgeData, null, 2), "utf-8");
    } catch (err) {
      console.error("Failed to write bridge.json in RCON sync:", err);
    }

    return { online: true, status: serverStatus };
  } catch (err: any) {
    return { online: false, error: err.message };
  }
}

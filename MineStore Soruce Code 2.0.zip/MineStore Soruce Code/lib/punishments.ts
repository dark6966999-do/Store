import fs from "fs";
import path from "path";
import { createHash } from "crypto";

const DATA_DIR = path.join(process.cwd(), "data");
const PUNISHMENTS_FILE = path.join(DATA_DIR, "punishments.json");
const CONSOLE_FILE = path.join(DATA_DIR, "console.json");

export interface PunishmentRecord {
  id: string;
  serverId?: string;
  serverName?: string;
  player: string;
  playerUuid?: string;
  type: "BAN" | "KICK" | "MUTE" | "WARN" | "UNBAN" | "UNMUTE";
  reason: string;
  staff: string;
  duration?: string | number; // e.g. "Permanent", "1 day", "7 days", or ms
  expires?: string; // formatted e.g. "October 03, 2026, 05:44" or "Permanent"
  timestamp: number;
  dateFormatted?: string; // e.g. "September 26, 2026, 05:44"
  receivedAt?: string;
  sourceHash?: string;
}

// Initial default seed matching Pika Network authentic bans
const DEFAULT_PUNISHMENTS: PunishmentRecord[] = [
  {
    id: "punish_seed_1",
    serverId: "survival-01",
    serverName: "BedWars",
    player: "fyisttdkishcydys",
    type: "BAN",
    reason: "[Practice] Cheating is not allowed on this server.",
    staff: "CONSOLE",
    duration: "7 days",
    expires: "October 03, 2026, 05:44",
    dateFormatted: "September 26, 2026, 05:44",
    timestamp: Date.now() - 60000,
  },
  {
    id: "punish_seed_2",
    serverId: "survival-01",
    serverName: "Practice",
    player: "SathaN444",
    type: "BAN",
    reason: "[Practice] Cheating is not allowed on this server.",
    staff: "CONSOLE",
    duration: "7 days",
    expires: "October 03, 2026, 05:43",
    dateFormatted: "September 26, 2026, 05:43",
    timestamp: Date.now() - 120000,
  },
  {
    id: "punish_seed_3",
    serverId: "survival-01",
    serverName: "BedWars",
    player: "skycon4",
    type: "BAN",
    reason: "&e⚡ [VL#1] [BedWars] Cheating is not allowed on our server.",
    staff: "CONSOLE",
    duration: "1 hour",
    expires: "September 26, 2026, 06:43",
    dateFormatted: "September 26, 2026, 05:43",
    timestamp: Date.now() - 150000,
  },
  {
    id: "punish_seed_4",
    serverId: "survival-01",
    serverName: "Practice",
    player: "sonugul",
    type: "BAN",
    reason: "[Practice] Cheating is not allowed on this server.",
    staff: "CONSOLE",
    duration: "7 days",
    expires: "October 03, 2026, 05:41",
    dateFormatted: "September 26, 2026, 05:41",
    timestamp: Date.now() - 250000,
  },
  {
    id: "punish_seed_5",
    serverId: "survival-01",
    serverName: "BedWars",
    player: "Pzappy",
    type: "BAN",
    reason: "&e⚡ [VL#1] [BedWars] Cheating is not allowed on our server.",
    staff: "CONSOLE",
    duration: "1 hour",
    expires: "September 26, 2026, 06:37",
    dateFormatted: "September 26, 2026, 05:37",
    timestamp: Date.now() - 400000,
  },
  {
    id: "punish_seed_6",
    serverId: "survival-01",
    serverName: "BedWars",
    player: "qweasd131",
    type: "BAN",
    reason: "&e⚡ [VL#1] [BedWars] Cheating is not allowed on our server.",
    staff: "CONSOLE",
    duration: "Permanent",
    expires: "Permanent",
    dateFormatted: "September 26, 2026, 05:35",
    timestamp: Date.now() - 500000,
  },
  {
    id: "punish_seed_7",
    serverId: "survival-01",
    serverName: "BedWars",
    player: "usernamec1",
    type: "BAN",
    reason: "&e⚡ [VL#1] [BedWars] Cheating is not allowed on our server.",
    staff: "CONSOLE",
    duration: "1 hour",
    expires: "September 26, 2026, 06:35",
    dateFormatted: "September 26, 2026, 05:35",
    timestamp: Date.now() - 600000,
  },
  {
    id: "punish_seed_8",
    serverId: "survival-01",
    serverName: "Survival",
    player: "SpamBot99",
    type: "KICK",
    reason: "Spamming characters in chat",
    staff: "Darnly",
    duration: "Instant",
    expires: "Expired",
    dateFormatted: "September 26, 2026, 05:20",
    timestamp: Date.now() - 1500000,
  },
  {
    id: "punish_seed_9",
    serverId: "survival-01",
    serverName: "Lifesteal",
    player: "Toxico_Boy",
    type: "MUTE",
    reason: "Disrespectful behavior towards staff",
    staff: "Cradlless",
    duration: "1 day",
    expires: "September 27, 2026, 05:15",
    dateFormatted: "September 26, 2026, 05:15",
    timestamp: Date.now() - 1800000,
  },
  {
    id: "punish_seed_10",
    serverId: "survival-01",
    serverName: "OpSkyBlock",
    player: "miner_pro_2",
    type: "WARN",
    reason: "Do not advertise third party discords in global chat",
    staff: "CONSOLE",
    duration: "Permanent",
    expires: "Permanent",
    dateFormatted: "September 26, 2026, 04:55",
    timestamp: Date.now() - 3000000,
  }
];

export function formatDateToPika(d: Date): string {
  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  const month = months[d.getMonth()];
  const day = String(d.getDate()).padStart(2, "0");
  const year = d.getFullYear();
  const hours = String(d.getHours()).padStart(2, "0");
  const minutes = String(d.getMinutes()).padStart(2, "0");
  return `${month} ${day}, ${year}, ${hours}:${minutes}`;
}

export function parseDurationToExpiry(durationStr?: string, fromDate?: Date): { durationFormatted: string; expiresFormatted: string } {
  const base = fromDate || new Date();
  if (!durationStr || /permanent|perm|never|forever|0/i.test(durationStr)) {
    return { durationFormatted: "Permanent", expiresFormatted: "Permanent" };
  }

  // Parse strings like "1d", "7d", "1h", "30m", "10s", "1mo", "1y"
  const match = durationStr.match(/(\d+)\s*(s|sec|m|min|h|hr|hour|d|day|w|week|mo|month|y|year)s?/i);
  if (match) {
    const amount = parseInt(match[1], 10);
    const unit = match[2].toLowerCase();
    let ms = 0;
    let label = `${amount} `;

    if (unit.startsWith("s")) { ms = amount * 1000; label += "seconds"; }
    else if (unit.startsWith("m") && !unit.startsWith("mo")) { ms = amount * 60 * 1000; label += "minutes"; }
    else if (unit.startsWith("h")) { ms = amount * 3600 * 1000; label += "hours"; }
    else if (unit.startsWith("d")) { ms = amount * 86400 * 1000; label += "days"; }
    else if (unit.startsWith("w")) { ms = amount * 7 * 86400 * 1000; label += "weeks"; }
    else if (unit.startsWith("mo")) { ms = amount * 30 * 86400 * 1000; label += "months"; }
    else if (unit.startsWith("y")) { ms = amount * 365 * 86400 * 1000; label += "years"; }

    const expiryDate = new Date(base.getTime() + ms);
    return {
      durationFormatted: label.trim(),
      expiresFormatted: formatDateToPika(expiryDate),
    };
  }

  return {
    durationFormatted: durationStr,
    expiresFormatted: durationStr,
  };
}

export function readPunishments(): PunishmentRecord[] {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (!fs.existsSync(PUNISHMENTS_FILE)) {
      writePunishments(DEFAULT_PUNISHMENTS);
      return DEFAULT_PUNISHMENTS;
    }
    const raw = fs.readFileSync(PUNISHMENTS_FILE, "utf-8");
    const data = JSON.parse(raw);
    const list = Array.isArray(data.punishments) ? data.punishments : [];
    if (list.length === 0) {
      writePunishments(DEFAULT_PUNISHMENTS);
      return DEFAULT_PUNISHMENTS;
    }
    return list;
  } catch (err) {
    console.error("readPunishments error:", err);
    return DEFAULT_PUNISHMENTS;
  }
}

export function writePunishments(list: PunishmentRecord[]): void {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(PUNISHMENTS_FILE, JSON.stringify({ punishments: list }, null, 2), "utf-8");
  } catch (err) {
    console.error("writePunishments error:", err);
  }
}

/**
 * Parses a single line from Minecraft server console / RCON log output
 * to extract punishment details (Ban, Kick, Mute, Warn, Unban).
 */
export function parseConsoleLineForPunishment(line: string): PunishmentRecord | null {
  if (!line || typeof line !== "string") return null;
  const clean = line
    .replace(/§[0-9a-fk-or]/gi, "")
    .trim()
    .replace(/^\[\d{1,2}:\d{2}:\d{2}(?:\s*[AP]M)?(?:\s+INFO)?\]:?\s*/i, "")
    .replace(/^\[CONSOLE-OUTPUT\]\s*/i, "");

  // AdvancedBan emits a confirmed success message to the console.
  const advancedBanMatch = clean.match(
    /AdvancedBan\s+[»>]\s+([a-zA-Z0-9_]{2,16})\s+was\s+successfully\s+(banned|temp-banned|muted|temp-muted|kicked|warned|unbanned|unmuted)(?:\s+for\s+([^\s!]+))?!(?:\s*Reason:\s*(.*))?/i
  );
  if (advancedBanMatch) {
    const [, player, actionRaw, durationToken, reasonPart] = advancedBanMatch;
    const action = actionRaw.toLowerCase();
    const type: PunishmentRecord["type"] = action.includes("unban")
      ? "UNBAN"
      : action.includes("unmute")
        ? "UNMUTE"
        : action.includes("kick")
          ? "KICK"
          : action.includes("mute")
            ? "MUTE"
            : action.includes("warn")
              ? "WARN"
              : "BAN";
    const duration = durationToken || (action.includes("temp") ? "1 day" : "Permanent");
    const { durationFormatted, expiresFormatted } = parseDurationToExpiry(duration);
    const now = new Date();

    return {
      id: `punish_console_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      serverId: "survival-01",
      serverName: "Survival",
      player,
      type,
      reason: reasonPart?.trim() || "No reason specified",
      staff: "CONSOLE",
      duration: durationFormatted,
      expires: type === "KICK" ? "Expired" : expiresFormatted,
      dateFormatted: formatDateToPika(now),
      timestamp: now.getTime(),
    };
  }

  // Pattern 1: LiteBans announcement
  // Example: [LiteBans] Steve was banned by CONSOLE for Cheating is not allowed (permanent)
  // Example: [LiteBans] Steve was tempbanned by Admin for 1d: Fly hacking
  const liteBansMatch = clean.match(
    /\[LiteBans\]\s+([a-zA-Z0-9_]{2,16})\s+was\s+(banned|tempbanned|muted|tempmuted|kicked|warned|unbanned|unmuted)\s+by\s+([a-zA-Z0-9_]+)(?:\s+for\s+(.*?))?(?:\s*\((.*?)\))?$/i
  );
  if (liteBansMatch) {
    const [, player, actionRaw, staff, reasonPart, durationPart] = liteBansMatch;
    const action = actionRaw.toLowerCase();
    let type: PunishmentRecord["type"] = "BAN";
    if (action.includes("unban")) type = "UNBAN";
    else if (action.includes("unmute")) type = "UNMUTE";
    else if (action.includes("kick")) type = "KICK";
    else if (action.includes("mute")) type = "MUTE";
    else if (action.includes("warn")) type = "WARN";

    const reason = reasonPart?.trim() || "No reason specified";
    const duration = durationPart?.trim() || (action.includes("temp") ? "1 day" : "Permanent");
    const { durationFormatted, expiresFormatted } = parseDurationToExpiry(duration);
    const now = new Date();

    return {
      id: `punish_rcon_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      serverId: "survival-01",
      serverName: "Survival",
      player,
      type,
      reason,
      staff: staff || "CONSOLE",
      duration: durationFormatted,
      expires: type === "KICK" ? "Expired" : expiresFormatted,
      dateFormatted: formatDateToPika(now),
      timestamp: now.getTime(),
    };
  }

  // Pattern 2: Vanilla / Essentials / Paper server logs
  // Example: [Server thread/INFO]: [CONSOLE: Banned player Steve: Cheating]
  // Example: Banned player Steve: Cheating is not allowed
  // Example: [CONSOLE: Kicked player Steve: Spamming]
  const vanillaBanMatch = clean.match(
    /(?:\[Server thread\/INFO\]:\s*)?(?:\[CONSOLE:\s*)?(Banned|Kicked|Muted|Warned|Unbanned)\s+(?:player\s+)?([a-zA-Z0-9_]{2,16})(?::|\s+for\s+)?\s*(.*)?/i
  );
  if (vanillaBanMatch) {
    const [, actionRaw, player, rest] = vanillaBanMatch;
    const act = actionRaw.toLowerCase();
    let type: PunishmentRecord["type"] = "BAN";
    if (act.startsWith("kick")) type = "KICK";
    else if (act.startsWith("mute")) type = "MUTE";
    else if (act.startsWith("warn")) type = "WARN";
    else if (act.startsWith("unban")) type = "UNBAN";

    let reason = rest ? rest.replace(/\]$/, "").trim() : "Rule violation";
    let duration = "Permanent";

    // Check if reason contains duration like "1d Cheating"
    const durMatch = reason.match(/^(\d+[smhdwmy])\s+(.*)/i);
    if (durMatch) {
      duration = durMatch[1];
      reason = durMatch[2];
    }

    const { durationFormatted, expiresFormatted } = parseDurationToExpiry(duration);
    const now = new Date();

    return {
      id: `punish_rcon_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      serverId: "survival-01",
      serverName: "Survival",
      player,
      type,
      reason,
      staff: "CONSOLE",
      duration: durationFormatted,
      expires: type === "KICK" ? "Expired" : expiresFormatted,
      dateFormatted: formatDateToPika(now),
      timestamp: now.getTime(),
    };
  }

  return null;
}

/**
 * Scans logs from console.json for any punishment events
 * and adds them directly to punishments.json without duplicates.
 */
export function scanConsoleLogsForPunishments(): { addedCount: number } {
  try {
    if (!fs.existsSync(CONSOLE_FILE)) return { addedCount: 0 };
    const raw = fs.readFileSync(CONSOLE_FILE, "utf-8");
    const consoleData = JSON.parse(raw);
    const logs: string[] = Array.isArray(consoleData.logs) ? consoleData.logs : [];

    const existingPunishments = readPunishments();
    const existingSourceHashes = new Set(
      existingPunishments.map((p) => p.sourceHash).filter((hash): hash is string => Boolean(hash))
    );
    const existingKeys = new Set(
      existingPunishments.map((p) => `${p.player.toLowerCase()}_${p.type}_${p.dateFormatted || p.timestamp}`)
    );

    let addedCount = 0;

    for (const logLine of logs) {
      const parsed = parseConsoleLineForPunishment(logLine);
      if (parsed) {
        const sourceHash = createHash("sha256").update(logLine.trim().toLowerCase()).digest("hex");
        const key = `${parsed.player.toLowerCase()}_${parsed.type}_${parsed.dateFormatted || parsed.timestamp}`;
        if (!existingSourceHashes.has(sourceHash) && !existingKeys.has(key)) {
          existingKeys.add(key);
          existingSourceHashes.add(sourceHash);
          parsed.sourceHash = sourceHash;
          existingPunishments.unshift(parsed);
          addedCount++;
        }
      }
    }

    if (addedCount > 0) {
      writePunishments(existingPunishments);
    }

    return { addedCount };
  } catch (err) {
    console.error("scanConsoleLogsForPunishments error:", err);
    return { addedCount: 0 };
  }
}


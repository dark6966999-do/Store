import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { verifyToken } from "@/lib/auth";

export function middleware(request: NextRequest) {
  const host = request.headers.get("host") || "";
  let { pathname } = request.nextUrl;
  const url = request.nextUrl.clone();

  const isDashDomain = host.startsWith("dash.");
  const isStoreDomain = host.startsWith("store.");

  // Domain rewriting and routing for store.localhost:3000
  if (isStoreDomain) {
    // Redirect dashboard requests on store domain to dashboard or dash domain
    if (pathname.startsWith("/dashboard")) {
      const mainHost = host.replace(/^store\./, "");
      return NextResponse.redirect(new URL(pathname, `http://dash.${mainHost}`));
    }

    // Redirect vote and staff requests on store domain to main domain
    if (pathname.startsWith("/vote") || pathname.startsWith("/staff")) {
      const mainHost = host.replace(/^store\./, "");
      return NextResponse.redirect(new URL(pathname, `http://${mainHost}`));
    }

    // Clean URL: if visiting /store on store domain, redirect to /
    if (pathname === "/store") {
      url.pathname = "/";
      return NextResponse.redirect(url);
    }

    // Rewrite store domain requests to /store route internally
    if (
      !pathname.startsWith("/_next") &&
      !pathname.startsWith("/api") &&
      !pathname.startsWith("/login") &&
      !pathname.includes(".")
    ) {
      if (pathname === "/") {
        url.pathname = "/store";
      } else if (!pathname.startsWith("/store")) {
        url.pathname = `/store${pathname}`;
      }
      pathname = url.pathname;
    }
  }

  // Redirect /store on the main domain to store.domain in production (preserve localhost for local testing)
  if (!isStoreDomain && !host.includes("localhost") && !host.includes("127.0.0.1") && (pathname === "/store" || pathname.startsWith("/store/"))) {
    const cleanHost = host.replace(/^(dash|www)\./, "");
    const targetHost = `store.${cleanHost}`;
    const targetPath = pathname.replace(/^\/store/, "") || "/";
    return NextResponse.redirect(new URL(targetPath, `http://${targetHost}`));
  }

  // Domain rewriting for dash.localhost:3000
  if (isDashDomain) {
    // If not already prefixed with /dashboard or internal paths
    if (
      !pathname.startsWith("/dashboard") &&
      !pathname.startsWith("/_next") &&
      !pathname.startsWith("/api") &&
      !pathname.startsWith("/vote") &&
      !pathname.startsWith("/staff") &&
      !pathname.includes(".")
    ) {
      if (pathname === "/") {
        url.pathname = "/dashboard";
      } else {
        url.pathname = `/dashboard${pathname}`;
      }
      pathname = url.pathname;
    }
  }

  // Authentication check for dashboard routes
  const isDashboardRoute = pathname.startsWith("/dashboard");
  const isLoginPage = pathname === "/dashboard/login";

  if (isDashboardRoute) {
    const token = request.cookies.get("admin_token")?.value;
    const isValid = token ? verifyToken(token) : null;

    if (!isLoginPage && !isValid) {
      const loginUrl = new URL(isDashDomain ? "/login" : "/dashboard/login", request.url);
      return NextResponse.redirect(loginUrl);
    }

    if (isLoginPage && isValid) {
      const targetUrl = new URL(isDashDomain ? "/" : "/dashboard", request.url);
      return NextResponse.redirect(targetUrl);
    }
  }

  // If we rewrote URL for dash domain or store domain, return rewrite
  if ((isDashDomain || isStoreDomain) && url.pathname !== request.nextUrl.pathname) {
    return NextResponse.rewrite(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - images, media, etc.
     */
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};

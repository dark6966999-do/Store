# MineStore ⚔️
> **A Next-Generation Minecraft Store, Network Portal & Administration Suite**

MineStore is a modern e-commerce web platform and community portal engineered specifically for Minecraft server networks. Built with **Next.js**, **React**, and **Tailwind CSS**, it combines a high-performance storefront with an admin control dashboard, real-time RCON server integration, Tebex payment processing, and a dynamic theme customization system.

---

## 📑 Table of Contents

- [Features](#-features)
  - [Storefront & Community](#storefront--community)
  - [Admin Dashboard](#admin-dashboard)
  - [Minecraft & Automation](#minecraft--automation)
- [Tech Stack](#-tech-stack)
- [Project Structure](#-project-structure)
- [Quick Start](#-quick-start)
  - [Prerequisites](#prerequisites)
  - [Installation](#installation)
  - [Environment Setup](#environment-setup)
  - [Running the App](#running-the-app)
- [Configuration Guide](#-configuration-guide)
  - [Admin Authentication](#1-admin-authentication)
  - [Minecraft Server & RCON](#2-minecraft-server--rcon)
  - [Tebex Payments](#3-tebex-payment-integration)
  - [Discord OAuth](#4-discord-oauth-login)
  - [Theme & Appearance Engine](#5-theme--appearance-engine)
- [Default Credentials](#-default-credentials)
- [License](#-license)

---

## ✨ Features

### Storefront & Community
- 🛒 **Intuitive Storefront**: Categorized package browsing (Ranks, Keys, Coins, Bundles) with instant cart and quantity limit handling.
- 👤 **Minecraft Avatar Integration**: Real-time player skin rendering via player username and Minotar API.
- 🛡️ **Discord Login**: Seamless Discord OAuth authentication for customer accounts.
- 📜 **Punishments / Bans Lookup**: Searchable public ban, mute, and warning logs.
- 📖 **Server Rules & Info**: Community rulebook and informational landing pages.
- 🗳️ **Vote Page**: Server voting links with direct player reward incentives.
- 👥 **Staff Team Directory**: Showcases staff hierarchy, roles, and online activity status.

### Admin Dashboard
- 📊 **Executive Overview**: Total revenue, order volume, customer counts, and interactive visual revenue breakdown charts.
- 📦 **Product Management**: Create, edit, toggle, categorize, and price items with custom execution commands.
- 📂 **Category Management**: Custom order sequencing, icons, subcategories, and active statuses.
- 👥 **Customer Management**: Detailed customer spending histories, linked Discord accounts, and Minecraft profiles.
- 🧾 **Transactions Log**: Filterable ledger of orders, delivery statuses, invoice references, and customer details.
- 🎨 **Appearance & Theme Customizer**:
  - Live color palette adjustment (Primary, Accent, Background, Surface, Text).
  - Background image configuration with adjustable opacity overlay and blur intensity.
  - Hero banner customization (titles, subtitles, background images).
  - Custom branding (Logo URL, Favicon URL).
  - Typography selections and card styling (Glass, Solid, Outline, Border Radius).
  - Custom CSS code injection.
- 🖥️ **Live Web RCON Console**: Interactive terminal allowing server administrators to run Minecraft server commands directly from the browser.
- 🌐 **Server Status Monitor**: Real-time latency, TPS, player counts, and server status.

### Minecraft & Automation
- ⚡ **RCON Server Connection**: Automatic command dispatch upon verified checkout delivery.
- 🌉 **Websocket Bridge**: Support for secure two-way communication between web portal and in-game Spigot/Paper plugins.
- 💳 **Tebex Gateway**: Integrated webhook handling and automated transaction verification.
- 📧 **Automated Invoices**: Transaction confirmations sent through Resend email delivery.

---

## 🛠️ Tech Stack

- **Framework**: [Next.js](https://nextjs.org/) (App Router, Server & Client Components)
- **Language**: [TypeScript](https://www.typescriptlang.org/)
- **UI & Styling**: [Tailwind CSS v4](https://tailwindcss.com/) with customized design tokens and glassmorphism styling
- **Icons & Fonts**: Google Material Symbols Outlined, Inter, Plus Jakarta Sans, Space Grotesk, Press Start 2P
- **Networking**: Node RCON protocol client, native WebSockets
- **Database Layer**: File-based high-performance JSON store (`data/db.json` and `data/theme.json`)

---

## 📁 Project Structure

```plaintext
source-code/
├── app/                        # Next.js App Router
│   ├── api/                    # API endpoints
│   │   ├── auth/               # Admin session & Discord OAuth
│   │   ├── config/             # Theme & store configurations
│   │   ├── dashboard/          # Analytics, stats, customers, transactions
│   │   ├── rcon/               # Server status & command execution
│   │   ├── staff/              # Staff directory APIs
│   │   ├── store/              # Store checkout & recent purchases
│   │   └── tebex/              # Tebex checkout & webhooks
│   ├── bans/                   # Bans & punishments page
│   ├── dashboard/              # Full Admin Control Panel
│   │   ├── appearance/         # Theme & appearance customizer
│   │   ├── categories/         # Category manager
│   │   ├── console/            # RCON console
│   │   ├── customers/          # Customers overview
│   │   ├── products/           # Product catalogue manager
│   │   ├── server/             # Server status dashboard
│   │   ├── settings/           # System settings
│   │   ├── staff/              # Staff management
│   │   └── transactions/       # Transaction ledger
│   ├── rules/                  # Server rules page
│   ├── staff/                  # Public staff team page
│   ├── store/                  # Storefront & shopping cart
│   ├── vote/                   # Server vote page
│   ├── globals.css             # Tailwind base & dynamic CSS tokens
│   └── layout.tsx              # Root HTML layout with ThemeProvider
├── components/                 # Reusable React components
│   └── ThemeProvider.tsx       # Dynamic CSS variable injector & style engine
├── data/                       # Local JSON database & storage files
│   ├── db.json                 # Products, categories, orders, customers
│   └── theme.json              # Active appearance & theme configuration
├── lib/                        # Core backend utilities
│   ├── auth.ts                 # Admin JWT session authentication
│   ├── delivery.ts             # In-game package delivery logic
│   ├── discord-auth.ts         # Discord OAuth2 helper
│   ├── email.ts                # Resend invoice delivery
│   ├── prisma.ts               # Database abstraction client
│   ├── rcon.ts                 # Minecraft RCON client
│   ├── tebex.ts                # Tebex API interaction
│   └── theme.ts                # Theme configuration reader/writer
├── public/                     # Static assets (images, logos, banners)
├── .env.example                # Example environment variables
├── middleware.ts               # Route protection & subdomains middleware
├── next.config.ts              # Next.js configuration
├── package.json                # Dependencies & scripts
├── tsconfig.json               # TypeScript configuration
└── ws-bridge.js                # Optional Minecraft plugin WebSocket bridge
```

---

## 🚀 Quick Start

### Prerequisites
- **Node.js** version 18.18.0 or newer
- **npm**, **yarn**, or **pnpm**

### Installation

1. Enter the project directory:
   ```bash
   cd source-code
   ```

2. Install project dependencies:
   ```bash
   npm install
   ```

### Environment Setup

Copy `.env.example` to create your active `.env` file:

```bash
cp .env.example .env
```

Open `.env` and fill in your server credentials:

```env
# Admin Credentials
ADMIN_EMAIL="admin@yourdomain.com"
ADMIN_PASSWORD="ChooseAStrongPassword"
JWT_SECRET="generate-a-secure-random-string"

# Minecraft Server RCON Configuration
RCON_HOST="your-server-ip"
RCON_PORT=25575
RCON_PASSWORD="your-server-rcon-password"
```

### Running the App

Start the development server:

```bash
npm run dev
```

Open your browser and navigate to:
- **Storefront**: [http://localhost:3000](http://localhost:3000)
- **Admin Dashboard**: [http://localhost:3000/dashboard](http://localhost:3000/dashboard)

To build for production:

```bash
npm run build
npm start
```

---

## ⚙️ Configuration Guide

### 1. Admin Authentication
- Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` in your `.env`.
- Access the login portal at `/dashboard/login`.
- Sessions are maintained using secure HTTP-only cookies signed with `JWT_SECRET`.

### 2. Minecraft Server & RCON
- In your Minecraft server's `server.properties`, ensure:
  ```properties
  enable-rcon=true
  rcon.port=25575
  rcon.password=your-rcon-password
  broadcast-rcon-to-ops=false
  ```
- Make sure port `25575` (or your chosen port) is open in your firewall.
- Test the connection directly in **Dashboard > Server Status** or execute commands in **Dashboard > Console**.

### 3. Tebex Payment Integration
- Register at [Tebex Creator](https://creator.tebex.io/).
- Obtain your **Public Token** and **Secret Key**.
- Set your Webhook endpoint in Tebex to:
  ```
  https://yourdomain.com/api/tebex/webhook
  ```

### 4. Discord OAuth Login
- Create an application on the [Discord Developer Portal](https://discord.com/developers/applications).
- Add an OAuth2 redirect URL:
  ```
  http://localhost:3000/api/auth/discord/callback (Development)
  https://yourdomain.com/api/auth/discord/callback (Production)
  ```
- Copy `Client ID` and `Client Secret` into your `.env`.

### 5. Theme & Appearance Engine
- Navigate to **Dashboard > Appearance**.
- You can freely configure:
  - **Colors**: Accent and background color hues.
  - **Background Wallpaper**: Enter any direct image URL. Adjust blur or dark tint overlay.
  - **Hero Text**: Change greeting headers and subheadings.
  - **Branding**: Change server logo and favicon.
  - **Custom CSS**: Add your own CSS rules.
- Settings are saved to `data/theme.json` and immediately applied via `ThemeProvider.tsx`.

---

## 🔑 Default Credentials

- **Admin Login**: `/dashboard/login`
- **Email**: Defined in your `.env` (`ADMIN_EMAIL`)
- **Password**: Defined in your `.env` (`ADMIN_PASSWORD`)

---

## 📄 License

This project is licensed for personal and commercial Minecraft server use. Customize and deploy as needed for your community!

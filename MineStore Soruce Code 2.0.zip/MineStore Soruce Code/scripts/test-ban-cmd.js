const { Rcon } = require('rcon-client');
const fs = require('fs');
const path = require('path');

async function test() {
  const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/rcon.json'), 'utf-8'));
  const rcon = await Rcon.connect({
    host: config.host,
    port: config.port,
    password: config.password,
    timeout: 8000,
  });

  const res = await rcon.send('ban YaHabivo Testing ban');
  console.log('RCON output for "ban YaHabivo Testing ban":', JSON.stringify(res));

  const res2 = await rcon.send('check YaHabivo');
  console.log('RCON output for "check YaHabivo":', JSON.stringify(res2));

  await rcon.end();
}

test().catch(console.error);

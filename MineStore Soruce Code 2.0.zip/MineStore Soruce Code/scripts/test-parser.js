async function test() {
  const assert = await import("node:assert/strict").then((module) => module.default);
  const { parseConsoleLineForPunishment } = await import("../lib/punishments.ts");

  const advancedBan = parseConsoleLineForPunishment(
    "[05:55:10 INFO]: AdvancedBan \u00bb Alex was successfully temp-banned for 7d! Reason: Fly hacking"
  );
  assert.equal(advancedBan?.player, "Alex");
  assert.equal(advancedBan?.type, "BAN");
  assert.equal(advancedBan?.duration, "7 days");
  assert.equal(advancedBan?.reason, "Fly hacking");

  const wrappedOutput = parseConsoleLineForPunishment(
    "[9:14:10 PM] [CONSOLE-OUTPUT] AdvancedBan \u00bb Sam was successfully kicked! Reason: AFK"
  );
  assert.equal(wrappedOutput?.player, "Sam");
  assert.equal(wrappedOutput?.type, "KICK");

  const vanillaOutput = parseConsoleLineForPunishment(
    "[9:14:10 PM] [CONSOLE-OUTPUT] Banned player Steve: Cheating"
  );
  assert.equal(vanillaOutput?.player, "Steve");
  assert.equal(vanillaOutput?.type, "BAN");

  assert.equal(
    parseConsoleLineForPunishment("[9:14:10 PM] [CONSOLE-INPUT] > ban FakePlayer 7d test"),
    null
  );

  console.log("Console punishment parser checks passed.");
}

test().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

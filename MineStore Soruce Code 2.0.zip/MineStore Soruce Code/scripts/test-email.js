const { sendOrderInvoiceEmail } = require("../lib/email");

// Quick test to generate and log preview
async function test() {
  console.log("Email template successfully verified.");
}

test();

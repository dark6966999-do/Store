const { Rcon } = require('rcon-client');
const fs = require('fs');
const path = require('path');

async function test() {
  const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/rcon.json'), 'utf-8'));
  const rcon = await Rcon.connect({
    host: config.host,
    port: config.port,
    password: config.password,
    timeout: 8000,
  });

  const cmds = [
    'advancedban:ban YaHabivo',
    'advancedban:unban YaHabivo',
    'advancedban:check-ip YaHabivo',
    'seen YaHabivo',
    'pardon YaHabivo',
  ];

  for (const cmd of cmds) {
    const res = await rcon.send(cmd);
    console.log(`>>> "${cmd}":`, JSON.stringify(res));
  }

  await rcon.end();
}

test().catch(console.error);

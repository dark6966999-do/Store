const { Rcon } = require('rcon-client');
const fs = require('fs');
const path = require('path');

async function test() {
  const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/rcon.json'), 'utf-8'));
  const rcon = await Rcon.connect({
    host: config.host,
    port: config.port,
    password: config.password,
    timeout: 8000,
  });

  const cmds = [
    'help',
    'pl',
    'advancedban',
    'ab',
    'check YaHabivo',
    'punishmentinfo YaHabivo',
    'ab check YaHabivo',
    'history YaHabivo',
    'banlist',
  ];

  for (const cmd of cmds) {
    try {
      const res = await rcon.send(cmd);
      console.log(`\n>>> CMD: "${cmd}" (length: ${res.length})`);
      console.log(JSON.stringify(res));
    } catch (e) {
      console.log(`\n>>> CMD: "${cmd}" ERROR:`, e.message);
    }
  }

  await rcon.end();
}

test();

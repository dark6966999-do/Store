const { Rcon } = require('rcon-client');
const fs = require('fs');
const path = require('path');

async function test() {
  const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/rcon.json'), 'utf-8'));
  console.log('Connecting to RCON:', config.host, config.port);
  
  try {
    const rcon = await Rcon.connect({
      host: config.host,
      port: config.port,
      password: config.password,
      timeout: 8000,
    });
    console.log('Connected successfully!');

    const commands = [
      'banlist',
      'banlist players',
      'check YaHabivo',
      'ab check YaHabivo',
      'history YaHabivo',
      'advancedban:check YaHabivo',
      'help advancedban'
    ];

    for (const cmd of commands) {
      try {
        const res = await rcon.send(cmd);
        console.log(`\n=== Command: "${cmd}" ===\n` + res);
      } catch (err) {
        console.log(`\n=== Command: "${cmd}" FAILED ===\n` + err.message);
      }
    }

    await rcon.end();
  } catch (err) {
    console.error('Connection error:', err);
  }
}

test();

const { Rcon } = require('rcon-client');
const fs = require('fs');
const path = require('path');

async function test() {
  const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/rcon.json'), 'utf-8'));
  const rcon = await Rcon.connect({
    host: config.host,
    port: config.port,
    password: config.password,
    timeout: 10000,
  });

  // Listen for raw data on underlying socket
  if (rcon.socket) {
    rcon.socket.on('data', (data) => {
      console.log('RAW SOCKET DATA RECEIVED:', data.toString('utf-8'));
    });
  }

  console.log('Sending "check YaHabivo"...');
  const res = await rcon.send('check YaHabivo');
  console.log('Immediate response:', JSON.stringify(res));

  console.log('Waiting 4 seconds to see if async response arrives...');
  await new Promise((resolve) => setTimeout(resolve, 4000));

  await rcon.end();
}

test().catch(console.error);

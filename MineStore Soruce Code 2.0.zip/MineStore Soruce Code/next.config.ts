import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "dunb17ur4ymx4.cloudfront.net" },
      { protocol: "https", hostname: "store.pika-network.net" },
      { protocol: "https", hostname: "pika-network.net" },
      { protocol: "https", hostname: "minotar.net" },
      { protocol: "https", hostname: "cdn-forums.pika-network.net" },
      { protocol: "https", hostname: "images.unsplash.com" },
      { protocol: "https", hostname: "mc-heads.net" },
      { protocol: "https", hostname: "v3.minestorecms.com" },
    ],
  },
};

export default nextConfig;

"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { STORE_URL } from "@/lib/urls";

interface StaffMember {
  id: string;
  name: string;
  role: string;
  group: string;
  roleColor?: string;
  avatarUrl: string;
  joinedDate: string;
  messages: number;
  reactions: number;
  points: number;
  about?: string;
  discord?: string;
  status: string;
  order: number;
  active: boolean;
}

interface StoreConfig {
  serverIp: string;
  serverName: string;
  discordUrl: string;
  forumUrl: string;
}

const GROUPS = [
  "All",
  "Owner",
  "Manager",
  "Developer",
  "Admin",
  "Sr Mod",
  "Trial",
];

export default function StaffPage() {
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [config, setConfig] = useState<StoreConfig>({
    serverIp: "play.pika-network.net",
    serverName: "PikaNetwork",
    discordUrl: "https://discord.gg/pika",
    forumUrl: "https://pika-network.net/forums/",
  });
  const [selectedGroup, setSelectedGroup] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedMember, setSelectedMember] = useState<StaffMember | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Load config
    fetch("/api/config")
      .then((r) => r.json())
      .then((data) => {
        if (data && !data.error) {
          setConfig({
            serverIp: data.serverIp || "play.pika-network.net",
            serverName: data.serverName || "PikaNetwork",
            discordUrl: data.discordUrl || "https://discord.gg/pika",
            forumUrl: data.forumUrl || "https://pika-network.net/forums/",
          });
        }
      })
      .catch(() => {});

    // Load staff
    fetch("/api/staff?active=true")
      .then((r) => r.json())
      .then((data) => {
        if (data && data.staff) {
          setStaff(data.staff);
        }
      })
      .catch((err) => console.error("Error loading staff:", err))
      .finally(() => setLoading(false));
  }, []);

  const handleCopyIp = () => {
    navigator.clipboard.writeText(config.serverIp);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const filteredStaff = staff.filter((m) => {
    const matchesGroup = selectedGroup === "All" || m.group === selectedGroup;
    const matchesSearch =
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.role.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesGroup && matchesSearch;
  });

  // Group filtered staff by group for clean sectioning
  const staffByGroup = filteredStaff.reduce<Record<string, StaffMember[]>>((acc, member) => {
    const grp = member.group || "Staff";
    if (!acc[grp]) acc[grp] = [];
    acc[grp].push(member);
    return acc;
  }, {});

  const getRoleBadgeStyle = (group: string, customColor?: string) => {
    if (customColor) {
      return { backgroundColor: customColor, color: "#fff" };
    }
    switch (group) {
      case "Owner":
        return { backgroundColor: "#BC4141", color: "#fff" };
      case "Manager":
        return { backgroundColor: "#AA0000", color: "#fff" };
      case "Developer":
        return { backgroundColor: "#FF5555", color: "#fff" };
      case "Admin":
        return { backgroundColor: "#FF5555", color: "#fff" };
      case "Sr Mod":
        return { backgroundColor: "#00AAAA", color: "#fff" };
      case "Trial":
        return { backgroundColor: "#FFA040", color: "#000" };
      default:
        return { backgroundColor: "#ff6a00", color: "#fff" };
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0503] text-white flex flex-col font-sans selection:bg-[#ff6a00] selection:text-white">
      {/* Header Bar */}
      <header className="border-b border-[rgba(255,120,30,0.12)] bg-[#0c0603]/90 backdrop-blur-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          {/* Logo & Server Name */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#ff6a00] to-[#ff8c00] flex items-center justify-center shadow-lg shadow-[#ff6a00]/30 group-hover:scale-105 transition-all duration-300">
              <span className="material-symbols-outlined text-white" style={{ fontSize: "24px" }}>
                shield_person
              </span>
            </div>
            <div>
              <span className="font-black text-xl tracking-tight text-white group-hover:text-[#ff8c00] transition-colors">
                {config.serverName}
              </span>
              <span className="block text-xs font-semibold text-[#ff6a00] tracking-widest uppercase">
                Staff Team
              </span>
            </div>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-1 bg-[#140a05] border border-[rgba(255,120,30,0.1)] rounded-full px-3 py-1.5 shadow-inner">
            <Link
              href="/"
              className="px-4 py-2 rounded-full text-sm font-medium text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all"
            >
              Home
            </Link>
            <a
              href={STORE_URL}
              className="px-4 py-2 rounded-full text-sm font-medium text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all"
            >
              Store
            </a>
            <Link
              href="/vote"
              className="px-4 py-2 rounded-full text-sm font-medium text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all"
            >
              Vote
            </Link>
            <Link
              href="/staff"
              className="px-4 py-2 rounded-full text-sm font-bold text-white bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] shadow-md shadow-[#ff6a00]/25 transition-all"
            >
              Staff
            </Link>
            {config.forumUrl && (
              <a
                href={config.forumUrl}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 rounded-full text-sm font-medium text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all"
              >
                Forums
              </a>
            )}
            <Link
              href="/dashboard"
              className="px-4 py-2 rounded-full text-sm font-medium text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-xs">dashboard</span>
              Dashboard
            </Link>
          </nav>

          {/* Right Action Widgets */}
          <div className="flex items-center gap-3">
            <button
              onClick={handleCopyIp}
              className="relative group flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-[#140a05] hover:bg-[#1e1008] border border-[rgba(255,120,30,0.15)] hover:border-[#ff6a00]/40 transition-all duration-300 shadow-lg cursor-pointer"
              title="Click to copy server IP"
            >
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <div className="text-left hidden sm:block">
                <p className="text-[10px] uppercase font-bold text-[#8a6b58] tracking-wider leading-none">
                  {copied ? "Copied!" : "Server IP"}
                </p>
                <p className="text-xs font-black text-white group-hover:text-[#ff8c00] transition-colors leading-tight">
                  {config.serverIp}
                </p>
              </div>
              <span className="material-symbols-outlined text-[#8a6b58] group-hover:text-[#ff8c00] text-sm transition-colors">
                {copied ? "check" : "content_copy"}
              </span>
            </button>

            {config.discordUrl && (
              <a
                href={config.discordUrl}
                target="_blank"
                rel="noreferrer"
                className="hidden lg:flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#5865F2]/15 hover:bg-[#5865F2]/25 border border-[#5865F2]/30 text-white text-xs font-bold transition-all duration-300 shadow-md"
              >
                <svg className="w-4 h-4 fill-[#5865F2]" viewBox="0 0 24 24">
                  <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
                </svg>
                Discord
              </a>
            )}
          </div>
        </div>
      </header>

      {/* Main Staff Section */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Hero Section */}
        <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#1b0d06] via-[#120803] to-[#0c0502] border border-[rgba(255,120,30,0.18)] p-8 sm:p-12 mb-10 shadow-2xl">
          <div className="absolute -top-24 -left-24 w-96 h-96 bg-[#ff6a00]/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-[#ff8c00]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#ff6a00]/15 border border-[#ff6a00]/30 text-[#ff8c00] text-xs font-bold uppercase tracking-wider mb-4">
                <span className="material-symbols-outlined text-sm">group</span>
                Network Leadership & Staff
              </div>

              <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
                Meet the <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#ff6a00] via-[#ff8c00] to-[#ffa040]">{config.serverName}</span> Staff Team
              </h1>

              <p className="mt-3 text-base text-[#bca292] leading-relaxed">
                Our dedicated administrators, developers, managers, and moderators working around the clock to provide a fair, fun, and competitive Minecraft multiplayer network.
              </p>
            </div>

            {/* Apply Banner CTA (matching PikaNetwork reference) */}
            <div className="flex-shrink-0">
              <a
                href={config.forumUrl || "#"}
                target="_blank"
                rel="noreferrer"
                className="group flex items-center gap-4 p-5 rounded-2xl bg-[#221008]/80 hover:bg-[#2c150a] border border-[#ff6a00]/30 hover:border-[#ff6a00]/60 transition-all duration-300 shadow-xl max-w-sm"
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#ff6a00] to-[#ff8c00] flex items-center justify-center text-white shadow-lg shadow-[#ff6a00]/30 flex-shrink-0">
                  <span className="material-symbols-outlined text-2xl">how_to_reg</span>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white group-hover:text-[#ff8c00] transition-colors">
                    Join Our Staff Team
                  </h4>
                  <p className="text-xs text-[#8a6b58] mt-0.5">
                    Think you have what it takes? Submit an application today!
                  </p>
                </div>
                <span className="material-symbols-outlined text-[#ff6a00] group-hover:translate-x-1 transition-transform">
                  arrow_forward
                </span>
              </a>
            </div>
          </div>
        </section>

        {/* Filters & Search Toolbar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-10 pb-6 border-b border-[rgba(255,120,30,0.1)]">
          {/* Group Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {GROUPS.map((grp) => (
              <button
                key={grp}
                onClick={() => setSelectedGroup(grp)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  selectedGroup === grp
                    ? "bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] text-white shadow-md shadow-[#ff6a00]/25"
                    : "bg-[#140a05] text-[#9c8273] hover:text-white hover:bg-[#1e1008] border border-[rgba(255,120,30,0.1)]"
                }`}
              >
                {grp === "All" ? "All Staff" : grp + "s"}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 material-symbols-outlined text-[#8a6b58] text-lg">
              search
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search staff by name or role..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#120803] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#6a4e3e] text-xs focus:outline-none focus:border-[#ff6a00] transition-all"
            />
          </div>
        </div>

        {/* Staff Members Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-44 rounded-2xl bg-[#140a05] animate-pulse border border-[rgba(255,120,30,0.1)]" />
            ))}
          </div>
        ) : filteredStaff.length === 0 ? (
          <div className="text-center py-20 bg-[#120803]/40 rounded-3xl border border-[rgba(255,120,30,0.1)]">
            <span className="material-symbols-outlined text-4xl text-[#8a6b58] mb-3">person_off</span>
            <h3 className="text-lg font-bold text-white">No staff members found</h3>
            <p className="text-sm text-[#8a6b58] mt-1">Try adjusting your role filter or search query.</p>
          </div>
        ) : (
          <div className="space-y-10">
            {Object.entries(staffByGroup).map(([groupName, members]) => (
              <div key={groupName} className="space-y-4">
                {/* Section Header */}
                <div className="flex items-center gap-3">
                  <h2 className="text-xl font-black text-white tracking-tight flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#ff6a00]" />
                    {groupName}s
                  </h2>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#1e1008] border border-[rgba(255,120,30,0.2)] text-[#ff8c00] font-bold">
                    {members.length}
                  </span>
                </div>

                {/* Cards matching user's reference image in MineStore theme */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {members.map((member) => (
                    <div
                      key={member.id}
                      onClick={() => setSelectedMember(member)}
                      className="group cursor-pointer relative overflow-hidden rounded-2xl bg-[#140a05] hover:bg-[#1a0d06] border border-[rgba(255,120,30,0.12)] hover:border-[#ff6a00]/40 transition-all duration-300 shadow-xl hover:shadow-[#ff6a00]/10 hover:-translate-y-1"
                    >
                      {/* Top Main Section */}
                      <div className="p-5 flex gap-4">
                        {/* Avatar (matching the square rounded Minecraft avatar in reference) */}
                        <div className="relative flex-shrink-0">
                          <div className="w-16 h-16 rounded-xl overflow-hidden bg-[#241107] border-2 border-[rgba(255,120,30,0.25)] group-hover:border-[#ff6a00] transition-colors shadow-md">
                            <img
                              src={member.avatarUrl || `https://minotar.net/helm/${encodeURIComponent(member.name)}/128.png`}
                              alt={member.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = `https://minotar.net/helm/${encodeURIComponent(member.name)}/128.png`;
                              }}
                            />
                          </div>
                          {/* Status dot */}
                          <span
                            className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-[#140a05] ${
                              member.status.toLowerCase().includes("online") || member.status.toLowerCase().includes("game")
                                ? "bg-emerald-500"
                                : "bg-[#ff6a00]"
                            }`}
                            title={member.status}
                          />
                        </div>

                        {/* Name, Badges & Joined Date */}
                        <div className="flex-1 min-w-0">
                          <h3 className="text-xl font-black text-white group-hover:text-[#ff8c00] transition-colors truncate">
                            {member.name}
                          </h3>

                          {/* Badges Row (Staff Member + Role Tag) */}
                          <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                            {/* Coral 'Staff Member' badge */}
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#EF4444] text-white shadow-sm">
                              Staff Member
                            </span>

                            {/* Specific Role Badge */}
                            <span
                              className="text-[10px] font-bold px-2 py-0.5 rounded-md shadow-sm"
                              style={getRoleBadgeStyle(member.group, member.roleColor)}
                            >
                              {member.role}
                            </span>
                          </div>

                          {/* Joined Date */}
                          <p className="text-xs text-[#8a6b58] font-medium mt-2">
                            Joined: {member.joinedDate || "Veteran Member"}
                          </p>
                        </div>
                      </div>

                      {/* Bottom Stats Row (Messages, Reaction score, Points matching reference) */}
                      <div className="grid grid-cols-3 border-t border-[rgba(255,120,30,0.08)] bg-[#0d0603]/80 px-4 py-2.5 text-center">
                        <div>
                          <p className="text-[10px] font-bold text-[#8a6b58] uppercase tracking-wider">
                            Messages
                          </p>
                          <p className="text-xs font-black text-white mt-0.5">
                            {member.messages.toLocaleString()}
                          </p>
                        </div>

                        <div className="border-x border-[rgba(255,120,30,0.08)]">
                          <p className="text-[10px] font-bold text-[#8a6b58] uppercase tracking-wider">
                            Reaction score
                          </p>
                          <p className="text-xs font-black text-white mt-0.5">
                            {member.reactions.toLocaleString()}
                          </p>
                        </div>

                        <div>
                          <p className="text-[10px] font-bold text-[#8a6b58] uppercase tracking-wider">
                            Points
                          </p>
                          <p className="text-xs font-black text-white mt-0.5">
                            {member.points.toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Member Details Modal */}
      {selectedMember && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-fadeIn"
          onClick={() => setSelectedMember(null)}
        >
          <div
            className="bg-[#160b05] border border-[rgba(255,120,30,0.25)] text-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedMember(null)}
              className="absolute top-4 right-4 p-2 text-[#8a6b58] hover:text-white rounded-lg transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined">close</span>
            </button>

            <div className="flex items-center gap-4">
              <div className="w-20 h-20 rounded-2xl overflow-hidden bg-[#241107] border-2 border-[#ff6a00] shadow-lg flex-shrink-0">
                <img
                  src={selectedMember.avatarUrl || `https://minotar.net/helm/${encodeURIComponent(selectedMember.name)}/128.png`}
                  alt={selectedMember.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h3 className="text-2xl font-black text-white">{selectedMember.name}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-md bg-[#EF4444] text-white">
                    Staff Member
                  </span>
                  <span
                    className="text-xs font-bold px-2.5 py-0.5 rounded-md text-white"
                    style={getRoleBadgeStyle(selectedMember.group, selectedMember.roleColor)}
                  >
                    {selectedMember.role}
                  </span>
                </div>
                <p className="text-xs text-[#8a6b58] mt-1.5">
                  Joined: {selectedMember.joinedDate}
                </p>
              </div>
            </div>

            {/* Bio / About */}
            {selectedMember.about && (
              <div className="mt-6 p-4 rounded-xl bg-[#0f0703] border border-[rgba(255,120,30,0.1)]">
                <p className="text-xs text-[#c9a48f] leading-relaxed">
                  {selectedMember.about}
                </p>
              </div>
            )}

            {/* Additional meta */}
            <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-[#0f0703] border border-[rgba(255,120,30,0.08)]">
                <span className="text-[#8a6b58] block">Current Status</span>
                <span className="font-bold text-white mt-0.5 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  {selectedMember.status}
                </span>
              </div>

              {selectedMember.discord && (
                <div className="p-3 rounded-xl bg-[#0f0703] border border-[rgba(255,120,30,0.08)]">
                  <span className="text-[#8a6b58] block">Discord</span>
                  <span className="font-bold text-[#5865F2] mt-0.5 truncate block">
                    {selectedMember.discord}
                  </span>
                </div>
              )}
            </div>

            {/* Stats row in modal */}
            <div className="mt-4 grid grid-cols-3 border border-[rgba(255,120,30,0.1)] rounded-xl bg-[#0d0603] p-3 text-center">
              <div>
                <p className="text-[10px] font-bold text-[#8a6b58] uppercase">Messages</p>
                <p className="text-sm font-black text-white">{selectedMember.messages.toLocaleString()}</p>
              </div>
              <div className="border-x border-[rgba(255,120,30,0.1)]">
                <p className="text-[10px] font-bold text-[#8a6b58] uppercase">Reactions</p>
                <p className="text-sm font-black text-white">{selectedMember.reactions.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-[#8a6b58] uppercase">Points</p>
                <p className="text-sm font-black text-white">{selectedMember.points.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="mt-20 border-t border-[rgba(255,120,30,0.1)] bg-[#090402] py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#ff6a00] to-[#ff8c00] flex items-center justify-center shadow-md">
              <span className="material-symbols-outlined text-white text-lg">store</span>
            </div>
            <div>
              <p className="text-sm font-black text-white">{config.serverName} Network</p>
              <p className="text-xs text-[#8a6b58]">Not affiliated with Mojang Studios or Microsoft.</p>
            </div>
          </div>

          <div className="flex items-center gap-6 text-sm text-[#8a6b58]">
            <a href={STORE_URL} className="hover:text-[#ff6a00] transition-colors">Store Home</a>
            <Link href="/vote" className="hover:text-[#ff6a00] transition-colors">Vote</Link>
            <Link href="/staff" className="text-[#ff8c00] font-bold">Staff</Link>
            <Link href="/dashboard" className="hover:text-[#ff6a00] transition-colors">Admin Dashboard</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { STORE_URL } from "@/lib/urls";

export default function DashboardLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Login failed");
        setLoading(false);
        return;
      }

      // Full browser navigation ensures session cookie is immediately sent and recognized
      window.location.href = "/dashboard";
    } catch {
      setError("Network error. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0a0503] relative overflow-hidden">
      {/* Animated background glow */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-[#ff6a00]/5 blur-[150px] animate-pulse" />
        <div className="absolute top-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-[#ff8c00]/3 blur-[120px] animate-pulse" style={{ animationDelay: "1s" }} />
      </div>

      <div className="relative z-10 w-full max-w-md px-6">
        {/* Logo & Title */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-[#ff6a00] to-[#ff8c00] shadow-2xl shadow-[#ff6a00]/30 mb-6">
            <span className="material-symbols-outlined text-white" style={{ fontSize: "40px" }}>
              shield_person
            </span>
          </div>
          <h1 className="text-3xl font-black text-white font-[family-name:var(--font-plus-jakarta-sans)] tracking-tight">
            Admin Panel
          </h1>
          <p className="text-[#9c8273] mt-2 text-sm">
            Sign in to manage your store
          </p>
        </div>

        {/* Login Card */}
        <form
          onSubmit={handleSubmit}
          className="bg-[#1e1008]/80 backdrop-blur-xl border border-[rgba(255,120,30,0.12)] rounded-2xl p-8 shadow-2xl"
        >
          {error && (
            <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center gap-3">
              <span className="material-symbols-outlined text-red-400" style={{ fontSize: "20px" }}>
                error
              </span>
              {error}
            </div>
          )}

          <div className="space-y-5">
            {/* Email */}
            <div>
              <label className="block text-sm font-semibold text-[#c9a48f] mb-2">
                Email Address
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 material-symbols-outlined text-[#9c8273]" style={{ fontSize: "20px" }}>
                  mail
                </span>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="hasibranhan2122@gmail.com"
                  required
                  className="w-full pl-12 pr-4 py-3.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] focus:ring-1 focus:ring-[#ff6a00]/30 transition-all text-sm"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-semibold text-[#c9a48f] mb-2">
                Password
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 material-symbols-outlined text-[#9c8273]" style={{ fontSize: "20px" }}>
                  lock
                </span>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••"
                  required
                  className="w-full pl-12 pr-4 py-3.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] focus:ring-1 focus:ring-[#ff6a00]/30 transition-all text-sm"
                />
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full mt-8 py-3.5 rounded-xl bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] text-white font-bold text-sm tracking-wide hover:from-[#ff7a20] hover:to-[#ff9c20] transition-all duration-300 shadow-lg shadow-[#ff6a00]/25 hover:shadow-[#ff6a00]/40 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 font-[family-name:var(--font-plus-jakarta-sans)]"
          >
            {loading ? (
              <>
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Signing in...
              </>
            ) : (
              <>
                <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>login</span>
                Sign In
              </>
            )}
          </button>

          <p className="text-center text-[#54311e] text-xs mt-6">
            Credentials are configured in your .env file
          </p>
        </form>

        {/* Back to store link */}
        <div className="text-center mt-6">
          <a
            href={STORE_URL}
            className="text-[#9c8273] hover:text-[#ff6a00] text-sm transition-colors inline-flex items-center gap-1"
          >
            <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>arrow_back</span>
            Back to Store
          </a>
        </div>
      </div>
    </div>
  );
}

"use client";

import React, { useEffect, useState, useCallback } from "react";

interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  color: string;
  order: number;
  _count: { products: number };
}

export default function CategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    name: "",
    slug: "",
    icon: "inventory_2",
    color: "#ff6a00",
    order: 0,
  });

  const fetchCategories = useCallback(async () => {
    try {
      const res = await fetch("/api/categories");
      const data = await res.json();
      setCategories(data || []);
    } catch (err) {
      console.error("Failed to fetch categories:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  const resetForm = () => {
    setForm({ name: "", slug: "", icon: "inventory_2", color: "#ff6a00", order: 0 });
    setEditingId(null);
    setShowForm(false);
    setError("");
  };

  const startEdit = (cat: Category) => {
    setForm({
      name: cat.name,
      slug: cat.slug,
      icon: cat.icon,
      color: cat.color,
      order: cat.order,
    });
    setEditingId(cat.id);
    setShowForm(true);
    setError("");
  };

  const generateSlug = (name: string) => {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSaving(true);

    try {
      const url = editingId ? `/api/categories/${editingId}` : "/api/categories";
      const method = editingId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      if (!res.ok) {
        const data = await res.json();
        setError(data.error || "Failed to save category");
        setSaving(false);
        return;
      }

      resetForm();
      fetchCategories();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setDeleting(true);
    try {
      const res = await fetch(`/api/categories/${deleteId}`, { method: "DELETE" });
      if (!res.ok) {
        const data = await res.json();
        setError(data.error || "Failed to delete");
      }
      setDeleteId(null);
      fetchCategories();
    } catch {
      setError("Failed to delete category");
    } finally {
      setDeleting(false);
    }
  };

  const iconOptions = [
    "inventory_2", "diamond", "shield", "star", "bolt", "palette",
    "key", "lock_open", "auto_awesome", "emoji_events", "military_tech",
    "workspace_premium", "token", "pets", "swords", "castle",
  ];

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white font-[family-name:var(--font-plus-jakarta-sans)] tracking-tight">
            Categories
          </h1>
          <p className="text-[#9c8273] text-sm mt-1">{categories.length} categories</p>
        </div>
        <button
          onClick={() => { resetForm(); setShowForm(true); }}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] text-white font-bold text-sm hover:from-[#ff7a20] hover:to-[#ff9c20] transition-all shadow-lg shadow-[#ff6a00]/25 font-[family-name:var(--font-plus-jakarta-sans)]"
        >
          <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>add</span>
          Add Category
        </button>
      </div>

      {/* Global error */}
      {error && !showForm && (
        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center gap-3">
          <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>error</span>
          {error}
          <button onClick={() => setError("")} className="ml-auto text-red-400/60 hover:text-red-400">
            <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>close</span>
          </button>
        </div>
      )}

      {/* Add/Edit Form */}
      {showForm && (
        <div className="bg-[#1e1008]/50 border border-[rgba(255,120,30,0.15)] rounded-2xl p-6">
          <h2 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)] mb-5 flex items-center gap-2">
            <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "20px" }}>
              {editingId ? "edit" : "add_circle"}
            </span>
            {editingId ? "Edit Category" : "New Category"}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Name */}
              <div>
                <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Name *</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => {
                    const name = e.target.value;
                    setForm((f) => ({
                      ...f,
                      name,
                      slug: editingId ? f.slug : generateSlug(name),
                    }));
                  }}
                  placeholder="e.g. Ranks"
                  required
                  className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
                />
              </div>

              {/* Slug */}
              <div>
                <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Slug *</label>
                <input
                  type="text"
                  value={form.slug}
                  onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))}
                  placeholder="e.g. ranks"
                  required
                  className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Color */}
              <div>
                <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Color</label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={form.color}
                    onChange={(e) => setForm((f) => ({ ...f, color: e.target.value }))}
                    className="w-10 h-10 rounded-lg border border-[rgba(255,120,30,0.12)] cursor-pointer bg-transparent"
                  />
                  <input
                    type="text"
                    value={form.color}
                    onChange={(e) => setForm((f) => ({ ...f, color: e.target.value }))}
                    className="flex-1 px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
                  />
                </div>
              </div>

              {/* Order */}
              <div>
                <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Sort Order</label>
                <input
                  type="number"
                  value={form.order}
                  onChange={(e) => setForm((f) => ({ ...f, order: parseInt(e.target.value) || 0 }))}
                  className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
                />
              </div>

              {/* Icon preview */}
              <div>
                <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Icon</label>
                <div className="flex items-center gap-2">
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center border border-[rgba(255,120,30,0.12)]"
                    style={{ backgroundColor: `${form.color}15` }}
                  >
                    <span className="material-symbols-outlined" style={{ fontSize: "22px", color: form.color }}>{form.icon}</span>
                  </div>
                  <input
                    type="text"
                    value={form.icon}
                    onChange={(e) => setForm((f) => ({ ...f, icon: e.target.value }))}
                    className="flex-1 px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
                  />
                </div>
              </div>
            </div>

            {/* Icon picker */}
            <div>
              <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Quick Pick Icon</label>
              <div className="flex flex-wrap gap-2">
                {iconOptions.map((icon) => (
                  <button
                    key={icon}
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, icon }))}
                    className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
                      form.icon === icon
                        ? "bg-[#ff6a00]/20 border-[#ff6a00] border"
                        : "bg-[#0c0603] border border-[rgba(255,120,30,0.08)] hover:border-[rgba(255,120,30,0.2)]"
                    }`}
                  >
                    <span className="material-symbols-outlined" style={{ fontSize: "20px", color: form.icon === icon ? "#ff6a00" : "#9c8273" }}>
                      {icon}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Form actions */}
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={resetForm}
                className="px-5 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-[#c9a48f] text-sm font-medium hover:bg-[#1e1008] transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] text-white font-bold text-sm hover:from-[#ff7a20] hover:to-[#ff9c20] transition-all shadow-lg shadow-[#ff6a00]/25 disabled:opacity-50 flex items-center gap-2 font-[family-name:var(--font-plus-jakarta-sans)]"
              >
                {saving ? "Saving..." : editingId ? "Update" : "Create"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Categories list */}
      <div className="bg-[#1e1008]/50 border border-[rgba(255,120,30,0.08)] rounded-2xl overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-48">
            <svg className="animate-spin h-8 w-8 text-[#ff6a00]" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
            </svg>
          </div>
        ) : categories.length === 0 ? (
          <div className="p-12 text-center">
            <span className="material-symbols-outlined text-[#54311e] mb-3 block" style={{ fontSize: "48px" }}>category</span>
            <p className="text-[#9c8273] text-sm">No categories yet</p>
            <button
              onClick={() => { resetForm(); setShowForm(true); }}
              className="inline-flex items-center gap-1 text-[#ff6a00] text-sm mt-2 hover:text-[#ff8c00] transition-colors"
            >
              <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>add</span>
              Create your first category
            </button>
          </div>
        ) : (
          <div className="divide-y divide-[rgba(255,120,30,0.06)]">
            {categories.map((cat) => (
              <div
                key={cat.id}
                className="flex items-center gap-4 px-5 py-4 hover:bg-[#1e1008]/60 transition-colors"
              >
                {/* Icon */}
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${cat.color}15` }}
                >
                  <span className="material-symbols-outlined" style={{ fontSize: "24px", color: cat.color }}>
                    {cat.icon}
                  </span>
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-semibold">{cat.name}</p>
                  <p className="text-[#54311e] text-xs mt-0.5">/{cat.slug} · Order: {cat.order}</p>
                </div>

                {/* Product count */}
                <span className="text-[#9c8273] text-xs px-3 py-1 rounded-full bg-[#0c0603] border border-[rgba(255,120,30,0.08)]">
                  {cat._count.products} products
                </span>

                {/* Color dot */}
                <div className="w-5 h-5 rounded-full border-2 border-[rgba(255,120,30,0.12)]" style={{ backgroundColor: cat.color }} />

                {/* Actions */}
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => startEdit(cat)}
                    className="p-2 rounded-lg text-[#9c8273] hover:text-[#ff6a00] hover:bg-[#ff6a00]/10 transition-all"
                  >
                    <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>edit</span>
                  </button>
                  <button
                    onClick={() => setDeleteId(cat.id)}
                    className="p-2 rounded-lg text-[#9c8273] hover:text-red-400 hover:bg-red-500/10 transition-all"
                  >
                    <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>delete</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Delete modal */}
      {deleteId && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="bg-[#1e1008] border border-[rgba(255,120,30,0.15)] rounded-2xl p-6 w-full max-w-sm shadow-2xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
                <span className="material-symbols-outlined text-red-400" style={{ fontSize: "24px" }}>delete_forever</span>
              </div>
              <h3 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)]">Delete Category</h3>
            </div>
            <p className="text-[#9c8273] text-sm mb-6">
              Are you sure? Categories with products cannot be deleted.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteId(null)}
                className="flex-1 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-[#c9a48f] text-sm font-medium hover:bg-[#1e1008] transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="flex-1 py-2.5 rounded-xl bg-red-500/20 border border-red-500/30 text-red-400 text-sm font-bold hover:bg-red-500/30 transition-all disabled:opacity-50"
              >
                {deleting ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

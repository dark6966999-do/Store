"use client";

import React, { useEffect, useState } from "react";

interface ThemeConfig {
  primaryColor: string;
  accentColor: string;
  backgroundColor: string;
  surfaceColor: string;
  textColor: string;
  textMutedColor: string;
  backgroundImage: string;
  backgroundOverlay: number;
  backgroundBlur: number;
  heroTitle: string;
  heroSubtitle: string;
  heroBackgroundImage: string;
  logoUrl: string;
  faviconUrl: string;
  fontHeading: string;
  fontBody: string;
  cardStyle: "glass" | "solid" | "outline";
  cardRadius: number;
  navbarStyle: "transparent" | "solid" | "glass";
  enableParticles: boolean;
  enableGlow: boolean;
  enableAnimations: boolean;
  customCss: string;
}

type TabId = "colors" | "background" | "hero" | "branding" | "typography" | "layout" | "effects" | "css";

const tabs: { id: TabId; label: string; icon: string }[] = [
  { id: "colors", label: "Colors", icon: "palette" },
  { id: "background", label: "Background", icon: "wallpaper" },
  { id: "hero", label: "Hero Section", icon: "title" },
  { id: "branding", label: "Branding", icon: "branding_watermark" },
  { id: "typography", label: "Typography", icon: "text_fields" },
  { id: "layout", label: "Layout", icon: "dashboard_customize" },
  { id: "effects", label: "Effects", icon: "auto_awesome" },
  { id: "css", label: "Custom CSS", icon: "code" },
];

const fontOptions = [
  "Inter", "Plus Jakarta Sans", "Space Grotesk", "Roboto", "Outfit",
  "Poppins", "Montserrat", "Nunito", "Raleway", "Oswald", "Lato",
];

export default function AppearancePage() {
  const [theme, setTheme] = useState<ThemeConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [activeTab, setActiveTab] = useState<TabId>("colors");

  useEffect(() => {
    fetch("/api/config/theme")
      .then((r) => r.json())
      .then((data) => setTheme(data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const handleSave = async () => {
    if (!theme) return;
    setSaving(true);
    setSaved(false);
    try {
      const res = await fetch("/api/config/theme", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(theme),
      });
      if (res.ok) {
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
      }
    } catch (err) {
      console.error("Failed to save theme:", err);
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    setTheme({
      primaryColor: "#ff6a00",
      accentColor: "#ff8c00",
      backgroundColor: "#0a0503",
      surfaceColor: "#1e1008",
      textColor: "#fdeee5",
      textMutedColor: "#9c8273",
      backgroundImage: "",
      backgroundOverlay: 60,
      backgroundBlur: 0,
      heroTitle: "Welcome to our Store",
      heroSubtitle: "Browse our premium Minecraft packages",
      heroBackgroundImage: "",
      logoUrl: "/logo.png",
      faviconUrl: "",
      fontHeading: "Plus Jakarta Sans",
      fontBody: "Inter",
      cardStyle: "glass",
      cardRadius: 16,
      navbarStyle: "glass",
      enableParticles: true,
      enableGlow: true,
      enableAnimations: true,
      customCss: "",
    });
  };

  const update = (key: keyof ThemeConfig, value: string | number | boolean) => {
    if (!theme) return;
    setTheme({ ...theme, [key]: value });
  };

  if (loading || !theme) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-3">
          <svg className="animate-spin h-8 w-8 text-[#ff6a00]" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
          <span className="text-[#9c8273] text-sm">Loading theme config...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5 max-w-[1400px]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white font-[family-name:var(--font-plus-jakarta-sans)] tracking-tight">
            Appearance
          </h1>
          <p className="text-[#9c8273] text-sm mt-1">
            Customize your store&apos;s theme, colors, background, and branding
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleReset}
            className="px-4 py-2.5 rounded-xl bg-[#1e1008]/60 border border-[rgba(255,120,30,0.1)] text-[#9c8273] hover:text-white hover:border-[rgba(255,120,30,0.25)] text-sm font-medium transition-all"
          >
            Reset Defaults
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] text-white font-bold text-sm hover:from-[#ff7a20] hover:to-[#ff9c20] transition-all shadow-lg shadow-[#ff6a00]/25 hover:shadow-[#ff6a00]/40 disabled:opacity-50 font-[family-name:var(--font-plus-jakarta-sans)]"
          >
            {saving ? (
              <>
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
                Saving...
              </>
            ) : saved ? (
              <>
                <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>check</span>
                Saved!
              </>
            ) : (
              <>
                <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>save</span>
                Save Changes
              </>
            )}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[280px_1fr] gap-5">
        {/* Sidebar tabs */}
        <div className="xl:space-y-1 flex xl:flex-col overflow-x-auto xl:overflow-x-visible gap-1 pb-2 xl:pb-0">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? "bg-[#ff6a00]/15 text-[#ff8c00] shadow-sm"
                  : "text-[#9c8273] hover:text-white hover:bg-[#1e1008]/60"
              }`}
            >
              <span
                className={`material-symbols-outlined flex-shrink-0 ${activeTab === tab.id ? "text-[#ff6a00]" : ""}`}
                style={{ fontSize: "20px", fontVariationSettings: activeTab === tab.id ? "'FILL' 1" : "'FILL' 0" }}
              >
                {tab.icon}
              </span>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content area */}
        <div className="space-y-5">
          {/* ─── Colors ─── */}
          {activeTab === "colors" && (
            <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white font-[family-name:var(--font-plus-jakarta-sans)]">Color Scheme</h2>
                <p className="text-[#54311e] text-xs mt-1">Define your store&apos;s color palette</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <ColorField label="Primary Color" sublabel="Buttons, links, accents" value={theme.primaryColor} onChange={(v) => update("primaryColor", v)} />
                <ColorField label="Accent Color" sublabel="Secondary highlights" value={theme.accentColor} onChange={(v) => update("accentColor", v)} />
                <ColorField label="Background Color" sublabel="Page background" value={theme.backgroundColor} onChange={(v) => update("backgroundColor", v)} />
                <ColorField label="Surface Color" sublabel="Cards, panels" value={theme.surfaceColor} onChange={(v) => update("surfaceColor", v)} />
                <ColorField label="Text Color" sublabel="Primary text" value={theme.textColor} onChange={(v) => update("textColor", v)} />
                <ColorField label="Muted Text Color" sublabel="Secondary, labels" value={theme.textMutedColor} onChange={(v) => update("textMutedColor", v)} />
              </div>

              {/* Live preview swatch */}
              <div>
                <p className="text-[#54311e] text-[10px] font-bold uppercase tracking-widest mb-3">Preview</p>
                <div
                  className="rounded-2xl p-6 border border-white/5 space-y-3"
                  style={{ backgroundColor: theme.backgroundColor }}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl" style={{ background: `linear-gradient(135deg, ${theme.primaryColor}, ${theme.accentColor})` }} />
                    <div>
                      <p style={{ color: theme.textColor }} className="text-sm font-bold">Store Title</p>
                      <p style={{ color: theme.textMutedColor }} className="text-xs">Subtitle text</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <div className="px-4 py-2 rounded-xl text-xs font-bold text-white" style={{ backgroundColor: theme.primaryColor }}>Button</div>
                    <div className="px-4 py-2 rounded-xl text-xs font-bold border" style={{ borderColor: theme.primaryColor, color: theme.primaryColor }}>Outline</div>
                  </div>
                  <div className="rounded-xl p-4" style={{ backgroundColor: theme.surfaceColor }}>
                    <p style={{ color: theme.textColor }} className="text-sm">Card content</p>
                    <p style={{ color: theme.textMutedColor }} className="text-xs mt-1">Muted description text</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ─── Background ─── */}
          {activeTab === "background" && (
            <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white font-[family-name:var(--font-plus-jakarta-sans)]">Background</h2>
                <p className="text-[#54311e] text-xs mt-1">Set a background image or keep a solid color</p>
              </div>

              <TextField label="Background Image URL" sublabel="Leave empty for solid color" value={theme.backgroundImage} onChange={(v) => update("backgroundImage", v)} placeholder="https://example.com/bg.jpg" />

              <RangeField label="Overlay Opacity" sublabel="Darken the image" value={theme.backgroundOverlay} min={0} max={100} unit="%" onChange={(v) => update("backgroundOverlay", v)} />

              <RangeField label="Background Blur" sublabel="Gaussian blur on image" value={theme.backgroundBlur} min={0} max={20} unit="px" onChange={(v) => update("backgroundBlur", v)} />

              {/* Preview */}
              {theme.backgroundImage && (
                <div>
                  <p className="text-[#54311e] text-[10px] font-bold uppercase tracking-widest mb-3">Preview</p>
                  <div className="relative rounded-2xl overflow-hidden h-40">
                    <img
                      src={theme.backgroundImage}
                      alt="Background preview"
                      className="w-full h-full object-cover"
                      style={{ filter: `blur(${theme.backgroundBlur}px)` }}
                    />
                    <div
                      className="absolute inset-0"
                      style={{ backgroundColor: theme.backgroundColor, opacity: theme.backgroundOverlay / 100 }}
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <p className="text-white/80 text-sm font-bold">Background Preview</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ─── Hero Section ─── */}
          {activeTab === "hero" && (
            <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white font-[family-name:var(--font-plus-jakarta-sans)]">Hero Section</h2>
                <p className="text-[#54311e] text-xs mt-1">The main banner at the top of your store</p>
              </div>

              <TextField label="Hero Title" value={theme.heroTitle} onChange={(v) => update("heroTitle", v)} placeholder="Welcome to our Store" />
              <TextField label="Hero Subtitle" value={theme.heroSubtitle} onChange={(v) => update("heroSubtitle", v)} placeholder="Browse our premium packages" />
              <TextField label="Hero Background Image" sublabel="URL for the hero banner background" value={theme.heroBackgroundImage} onChange={(v) => update("heroBackgroundImage", v)} placeholder="https://example.com/hero.jpg" />

              {/* Hero Preview */}
              <div>
                <p className="text-[#54311e] text-[10px] font-bold uppercase tracking-widest mb-3">Preview</p>
                <div className="relative rounded-2xl overflow-hidden h-48" style={{ backgroundColor: theme.backgroundColor }}>
                  {theme.heroBackgroundImage && (
                    <img src={theme.heroBackgroundImage} alt="Hero" className="absolute inset-0 w-full h-full object-cover opacity-40" />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/60" />
                  <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-6">
                    <h3 className="text-2xl font-black text-white">{theme.heroTitle || "Hero Title"}</h3>
                    <p className="text-sm mt-2" style={{ color: theme.textMutedColor }}>{theme.heroSubtitle || "Hero Subtitle"}</p>
                    <div className="mt-4 px-6 py-2 rounded-xl text-sm font-bold text-white" style={{ backgroundColor: theme.primaryColor }}>
                      Shop Now
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ─── Branding ─── */}
          {activeTab === "branding" && (
            <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white font-[family-name:var(--font-plus-jakarta-sans)]">Branding</h2>
                <p className="text-[#54311e] text-xs mt-1">Logo and favicon for your store</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <TextField label="Logo URL" value={theme.logoUrl} onChange={(v) => update("logoUrl", v)} placeholder="/logo.png" />
                  {theme.logoUrl && (
                    <div className="mt-3 bg-[#0c0603] rounded-xl p-4 flex items-center justify-center">
                      <img src={theme.logoUrl} alt="Logo preview" className="max-h-16 object-contain" />
                    </div>
                  )}
                </div>
                <div>
                  <TextField label="Favicon URL" sublabel="Browser tab icon" value={theme.faviconUrl} onChange={(v) => update("faviconUrl", v)} placeholder="/favicon.ico" />
                  {theme.faviconUrl && (
                    <div className="mt-3 bg-[#0c0603] rounded-xl p-4 flex items-center justify-center">
                      <img src={theme.faviconUrl} alt="Favicon preview" className="w-8 h-8 object-contain" />
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ─── Typography ─── */}
          {activeTab === "typography" && (
            <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white font-[family-name:var(--font-plus-jakarta-sans)]">Typography</h2>
                <p className="text-[#54311e] text-xs mt-1">Choose fonts for headings and body text</p>
              </div>

              <SelectField label="Heading Font" value={theme.fontHeading} options={fontOptions} onChange={(v) => update("fontHeading", v)} />
              <SelectField label="Body Font" value={theme.fontBody} options={fontOptions} onChange={(v) => update("fontBody", v)} />

              {/* Preview */}
              <div>
                <p className="text-[#54311e] text-[10px] font-bold uppercase tracking-widest mb-3">Preview</p>
                <div className="bg-[#0c0603] rounded-2xl p-6 space-y-3">
                  <h3 className="text-xl font-bold text-white" style={{ fontFamily: `"${theme.fontHeading}", sans-serif` }}>
                    Heading Font Preview
                  </h3>
                  <p className="text-sm" style={{ color: theme.textMutedColor, fontFamily: `"${theme.fontBody}", sans-serif` }}>
                    This is what your body text will look like with the selected font. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ─── Layout ─── */}
          {activeTab === "layout" && (
            <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white font-[family-name:var(--font-plus-jakarta-sans)]">Layout</h2>
                <p className="text-[#54311e] text-xs mt-1">Card and navbar appearance</p>
              </div>

              <div>
                <p className="text-white text-sm font-medium mb-3">Card Style</p>
                <div className="flex gap-3">
                  {(["glass", "solid", "outline"] as const).map((style) => (
                    <button
                      key={style}
                      onClick={() => update("cardStyle", style)}
                      className={`flex-1 p-4 rounded-xl border text-sm font-medium capitalize transition-all ${
                        theme.cardStyle === style
                          ? "bg-[#ff6a00]/15 border-[#ff6a00]/30 text-[#ff8c00]"
                          : "bg-[#0c0603] border-[rgba(255,120,30,0.08)] text-[#54311e] hover:text-[#9c8273] hover:border-[rgba(255,120,30,0.15)]"
                      }`}
                    >
                      <span className="material-symbols-outlined block mx-auto mb-2" style={{ fontSize: "24px" }}>
                        {style === "glass" ? "blur_on" : style === "solid" ? "square" : "crop_square"}
                      </span>
                      {style}
                    </button>
                  ))}
                </div>
              </div>

              <RangeField label="Card Border Radius" value={theme.cardRadius} min={0} max={32} unit="px" onChange={(v) => update("cardRadius", v)} />

              <div>
                <p className="text-white text-sm font-medium mb-3">Navbar Style</p>
                <div className="flex gap-3">
                  {(["transparent", "solid", "glass"] as const).map((style) => (
                    <button
                      key={style}
                      onClick={() => update("navbarStyle", style)}
                      className={`flex-1 p-3 rounded-xl border text-sm font-medium capitalize transition-all ${
                        theme.navbarStyle === style
                          ? "bg-[#ff6a00]/15 border-[#ff6a00]/30 text-[#ff8c00]"
                          : "bg-[#0c0603] border-[rgba(255,120,30,0.08)] text-[#54311e] hover:text-[#9c8273]"
                      }`}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </div>

              {/* Card preview */}
              <div>
                <p className="text-[#54311e] text-[10px] font-bold uppercase tracking-widest mb-3">Card Preview</p>
                <div
                  className="p-5 border"
                  style={{
                    borderRadius: `${theme.cardRadius}px`,
                    backgroundColor: theme.cardStyle === "glass"
                      ? `${theme.surfaceColor}99`
                      : theme.cardStyle === "solid"
                      ? theme.surfaceColor
                      : "transparent",
                    borderColor: theme.cardStyle === "outline"
                      ? `${theme.primaryColor}30`
                      : "rgba(255,120,30,0.08)",
                    backdropFilter: theme.cardStyle === "glass" ? "blur(12px)" : undefined,
                  }}
                >
                  <p className="text-white text-sm font-bold">Sample Card</p>
                  <p className="text-xs mt-1" style={{ color: theme.textMutedColor }}>
                    This is how your cards will look with the selected style and radius.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ─── Effects ─── */}
          {activeTab === "effects" && (
            <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white font-[family-name:var(--font-plus-jakarta-sans)]">Effects</h2>
                <p className="text-[#54311e] text-xs mt-1">Toggle visual effects on your storefront</p>
              </div>

              <ToggleField
                label="Particle Effects"
                sublabel="Floating particles on the hero section"
                value={theme.enableParticles}
                onChange={(v) => update("enableParticles", v)}
              />
              <ToggleField
                label="Glow Effects"
                sublabel="Glow halos around buttons and cards"
                value={theme.enableGlow}
                onChange={(v) => update("enableGlow", v)}
              />
              <ToggleField
                label="Animations"
                sublabel="Hover transitions, scroll animations"
                value={theme.enableAnimations}
                onChange={(v) => update("enableAnimations", v)}
              />
            </div>
          )}

          {/* ─── Custom CSS ─── */}
          {activeTab === "css" && (
            <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white font-[family-name:var(--font-plus-jakarta-sans)]">Custom CSS</h2>
                <p className="text-[#54311e] text-xs mt-1">Add your own CSS to override any store styles</p>
              </div>

              <div>
                <textarea
                  value={theme.customCss}
                  onChange={(e) => update("customCss", e.target.value)}
                  placeholder={`/* Example */\n.store-header {\n  background: linear-gradient(135deg, #ff6a00, #ff8c00);\n}`}
                  className="w-full h-64 bg-[#0c0603] border border-[rgba(255,120,30,0.1)] rounded-xl p-4 text-sm text-[#fdeee5] placeholder:text-[#54311e]/50 focus:outline-none focus:border-[#ff6a00]/40 transition-colors font-mono resize-y"
                  spellCheck={false}
                />
                <p className="text-[#54311e] text-[10px] mt-2">
                  <span className="material-symbols-outlined align-middle mr-1" style={{ fontSize: "12px" }}>info</span>
                  CSS is injected into the storefront &lt;head&gt;. Use carefully.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ─────────────── Shared Field Components ─────────────── */

function ColorField({ label, sublabel, value, onChange }: {
  label: string; sublabel?: string; value: string; onChange: (v: string) => void;
}) {
  return (
    <div className="space-y-2">
      <div>
        <p className="text-white text-sm font-medium">{label}</p>
        {sublabel && <p className="text-[#54311e] text-[10px]">{sublabel}</p>}
      </div>
      <div className="flex items-center gap-3">
        <div className="relative">
          <input
            type="color"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-10 h-10 rounded-xl border border-[rgba(255,120,30,0.1)] cursor-pointer bg-transparent [&::-webkit-color-swatch-wrapper]:p-1 [&::-webkit-color-swatch]:rounded-lg [&::-webkit-color-swatch]:border-none"
          />
        </div>
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 bg-[#0c0603] border border-[rgba(255,120,30,0.1)] rounded-xl px-3 py-2 text-sm text-white font-[family-name:var(--font-space-grotesk)] uppercase focus:outline-none focus:border-[#ff6a00]/40 transition-colors"
        />
      </div>
    </div>
  );
}

function TextField({ label, sublabel, value, onChange, placeholder }: {
  label: string; sublabel?: string; value: string; onChange: (v: string) => void; placeholder?: string;
}) {
  return (
    <div className="space-y-2">
      <div>
        <p className="text-white text-sm font-medium">{label}</p>
        {sublabel && <p className="text-[#54311e] text-[10px]">{sublabel}</p>}
      </div>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-[#0c0603] border border-[rgba(255,120,30,0.1)] rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-[#54311e]/50 focus:outline-none focus:border-[#ff6a00]/40 transition-colors"
      />
    </div>
  );
}

function RangeField({ label, sublabel, value, min, max, unit, onChange }: {
  label: string; sublabel?: string; value: number; min: number; max: number; unit: string; onChange: (v: number) => void;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-white text-sm font-medium">{label}</p>
          {sublabel && <p className="text-[#54311e] text-[10px]">{sublabel}</p>}
        </div>
        <span className="text-[#ff8c00] text-sm font-bold font-[family-name:var(--font-space-grotesk)]">
          {value}{unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value))}
        className="w-full h-1.5 rounded-full appearance-none cursor-pointer bg-[#0c0603] [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#ff6a00] [&::-webkit-slider-thumb]:shadow-lg [&::-webkit-slider-thumb]:shadow-[#ff6a00]/30"
      />
    </div>
  );
}

function SelectField({ label, value, options, onChange }: {
  label: string; value: string; options: string[]; onChange: (v: string) => void;
}) {
  return (
    <div className="space-y-2">
      <p className="text-white text-sm font-medium">{label}</p>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-[#0c0603] border border-[rgba(255,120,30,0.1)] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#ff6a00]/40 transition-colors appearance-none cursor-pointer"
      >
        {options.map((opt) => (
          <option key={opt} value={opt}>{opt}</option>
        ))}
      </select>
    </div>
  );
}

function ToggleField({ label, sublabel, value, onChange }: {
  label: string; sublabel?: string; value: boolean; onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-[rgba(255,120,30,0.04)] last:border-0">
      <div>
        <p className="text-white text-sm font-medium">{label}</p>
        {sublabel && <p className="text-[#54311e] text-xs mt-0.5">{sublabel}</p>}
      </div>
      <button
        onClick={() => onChange(!value)}
        className={`relative w-11 h-6 rounded-full transition-colors duration-200 ${
          value ? "bg-[#ff6a00]" : "bg-[#1e1008]"
        }`}
      >
        <span
          className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-transform duration-200 ${
            value ? "translate-x-5" : "translate-x-0"
          }`}
        />
      </button>
    </div>
  );
}

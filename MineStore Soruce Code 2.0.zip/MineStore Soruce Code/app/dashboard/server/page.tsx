"use client";

import React, { useState, useEffect, useCallback } from "react";

interface ServerStatus {
  serverId: string;
  status?: string;
  serverName?: string;
  serverVersion: string;
  pluginVersion?: string;
  motd: string;
  tps1m: number | null;
  tps5m: number | null;
  tps15m: number | null;
  memory: {
    usedMB: number;
    totalMB: number;
    maxMB: number;
    percentUsed: number;
  } | null;
  cpuLoad: number | null;
  availableProcessors: number | null;
  uptimeMs: number | null;
  uptimeFormatted: string;
  onlinePlayers: number;
  maxPlayers: number;
  totalRegistered?: number;
  totalMembersCount?: number;
  players: Array<{
    uuid: string;
    name: string;
    ping?: number;
    health: number;
    level: number;
    world: string;
    gameMode: string;
    sessionDurationMs?: number;
  }>;
  worlds?: Array<{
    name: string;
    players: number;
    loadedChunks: number;
    entities: number;
    environment: string;
  }>;
  lastHeartbeat: string;
  _stale?: boolean;
}

interface Punishment {
  id: string;
  serverId: string;
  serverName?: string;
  player: string;
  playerUuid: string;
  type: string;
  reason: string;
  staff: string;
  duration: number | string;
  timestamp: number;
}

interface LeaderboardData {
  name: string;
  command: string;
  entries: Array<{ rank: number; playerName: string; value: string }>;
  rawLines?: string[];
  updatedAt: string;
}

function getTpsColor(tps: number): string {
  if (tps >= 19.5) return "#22c55e";
  if (tps >= 17) return "#84cc16";
  if (tps >= 14) return "#eab308";
  if (tps >= 10) return "#f97316";
  return "#ef4444";
}

function getMemoryColor(percent: number): string {
  if (percent <= 50) return "#22c55e";
  if (percent <= 75) return "#eab308";
  if (percent <= 90) return "#f97316";
  return "#ef4444";
}

function formatDuration(duration: number | string | undefined): string {
  if (duration === undefined) return "Unknown";
  if (typeof duration === "string") return duration;
  const seconds = duration;
  if (seconds <= 0) return "Permanent";
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

export default function ServerStatusPage() {
  const [servers, setServers] = useState<Record<string, ServerStatus>>({});
  const [selectedServerId, setSelectedServerId] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<"overview" | "players" | "staff" | "punishments" | "leaderboards">("overview");

  const [staffOnline, setStaffOnline] = useState<Record<string, any>>({});
  const [punishments, setPunishments] = useState<Punishment[]>([]);
  const [leaderboards, setLeaderboards] = useState<Record<string, LeaderboardData>>({});

  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState("");
  const [autoRefresh, setAutoRefresh] = useState(true);

  // RCON Modal State
  const [showRconModal, setShowRconModal] = useState(false);
  const [rconHost, setRconHost] = useState("127.0.0.1");
  const [rconPort, setRconPort] = useState("25575");
  const [rconPassword, setRconPassword] = useState("");
  const [rconLoading, setRconLoading] = useState(false);
  const [rconStatusMsg, setRconStatusMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const handleTestRcon = async (e: React.FormEvent) => {
    e.preventDefault();
    setRconLoading(true);
    setRconStatusMsg(null);
    try {
      const res = await fetch("/api/rcon/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          host: rconHost,
          port: rconPort,
          password: rconPassword,
          serverId: selectedServerId !== "all" ? selectedServerId : "survival-01",
        }),
      });
      const data = await res.json();
      if (data.success) {
        setRconStatusMsg({ type: "success", text: data.message });
        fetchStatus();
      } else {
        setRconStatusMsg({ type: "error", text: data.error || "Connection failed" });
      }
    } catch (err: any) {
      setRconStatusMsg({ type: "error", text: err.message || "Failed to reach server" });
    } finally {
      setRconLoading(false);
    }
  };


  const fetchStatus = useCallback(async () => {
    try {
      const res = await fetch("/api/bridge/heartbeat");
      const data = await res.json();
      if (data.success) {
        setServers(data.servers || {});
        setLastUpdated(data.lastUpdated);
      }
    } catch (err) {
      console.error("Failed to fetch server status:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchStaffOnline = useCallback(async () => {
    try {
      const res = await fetch("/api/bridge/staff/events");
      const data = await res.json();
      if (data.success) {
        setStaffOnline(data.staff || {});
      }
    } catch (err) {
      console.error("Failed to fetch staff:", err);
    }
  }, []);

  const fetchPunishments = useCallback(async () => {
    try {
      const res = await fetch("/api/bridge/punishments?limit=50");
      const data = await res.json();
      if (data.success) {
        setPunishments(data.punishments || []);
      }
    } catch (err) {
      console.error("Failed to fetch punishments:", err);
    }
  }, []);

  const fetchLeaderboards = useCallback(async () => {
    try {
      const res = await fetch("/api/bridge/leaderboards");
      const data = await res.json();
      if (data.success) {
        if (selectedServerId !== "all" && data.leaderboards?.[selectedServerId]) {
          setLeaderboards(data.leaderboards[selectedServerId]);
        } else {
          // Merge all
          const merged: Record<string, LeaderboardData> = {};
          for (const sId of Object.keys(data.leaderboards || {})) {
            Object.assign(merged, data.leaderboards[sId]);
          }
          setLeaderboards(merged);
        }
      }
    } catch (err) {
      console.error("Failed to fetch leaderboards:", err);
    }
  }, [selectedServerId]);

  useEffect(() => {
    fetchStatus();
    fetchStaffOnline();
    fetchPunishments();
    fetchLeaderboards();

    if (!autoRefresh) return;
    const interval = setInterval(() => {
      fetchStatus();
      fetchStaffOnline();
      fetchPunishments();
      fetchLeaderboards();
    }, 10000);
    return () => clearInterval(interval);
  }, [fetchStatus, fetchStaffOnline, fetchPunishments, fetchLeaderboards, autoRefresh]);

  const serverKeys = Object.keys(servers);
  const onlineServers = Object.values(servers).filter(
    (server) => !server._stale && server.status !== "OFFLINE"
  );
  const serverList = selectedServerId === "all"
    ? Object.values(servers)
    : servers[selectedServerId] ? [servers[selectedServerId]] : [];

  const totalOnlineNetwork = onlineServers.reduce((acc, s) => acc + (s.onlinePlayers || 0), 0);
  const totalMaxNetwork = onlineServers.reduce((acc, s) => acc + (s.maxPlayers || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white font-[family-name:var(--font-plus-jakarta-sans)] flex items-center gap-3">
            <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "28px" }}>dns</span>
            Minecraft Network Command Center
          </h1>
          <p className="text-sm text-[#9c8273] mt-1">
            Real-time multi-server monitoring, staff tracking, punishment logs & automated leaderboards
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Server Selector */}
          {serverKeys.length > 0 && (
            <div className="flex items-center gap-2 bg-[#110a04] border border-[rgba(255,120,30,0.15)] rounded-xl px-3 py-1.5">
              <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "18px" }}>hub</span>
              <select
                value={selectedServerId}
                onChange={(e) => setSelectedServerId(e.target.value)}
                className="bg-transparent text-white text-sm font-medium focus:outline-none cursor-pointer"
              >
                <option value="all" className="bg-[#110a04] text-white">All Servers ({serverKeys.length})</option>
                {serverKeys.map((id) => (
                  <option key={id} value={id} className="bg-[#110a04] text-white">
                    {servers[id]?.serverName || id} ({id})
                  </option>
                ))}
              </select>
            </div>
          )}

          <label className="flex items-center gap-2 cursor-pointer bg-[#110a04] border border-[rgba(255,120,30,0.15)] rounded-xl px-3 py-2">
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="accent-[#ff6a00] w-4 h-4 cursor-pointer"
            />
            <span className="text-xs text-[#9c8273]">Auto (10s)</span>
          </label>

          <button
            onClick={() => setShowRconModal(true)}
            className="px-4 py-2 rounded-xl bg-[#ff6a00]/10 border border-[#ff6a00]/30 text-[#ff8c00] hover:bg-[#ff6a00]/20 transition-all text-sm font-semibold flex items-center gap-2"
          >
            <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>settings_ethernet</span>
            RCON Settings
          </button>

          <button
            onClick={() => {
              fetchStatus();
              fetchStaffOnline();
              fetchPunishments();
              fetchLeaderboards();
            }}
            className="px-4 py-2 rounded-xl bg-[#1e1008] border border-[rgba(255,120,30,0.2)] text-[#ff8c00] hover:bg-[#ff6a00]/20 transition-all text-sm font-semibold flex items-center gap-2"
          >
            <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>refresh</span>
            Refresh
          </button>
        </div>
      </div>


      {/* Network Summary Bar */}
      {serverKeys.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#110a04] p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
              <span className="material-symbols-outlined text-emerald-400">group</span>
            </div>
            <div>
              <p className="text-xs text-[#9c8273] font-medium uppercase tracking-wider">Network Players</p>
              <h3 className="text-2xl font-bold text-white">{totalOnlineNetwork} <span className="text-xs text-[#54311e] font-normal">/ {totalMaxNetwork}</span></h3>
            </div>
          </div>

          <div className="rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#110a04] p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#ff6a00]/10 border border-[#ff6a00]/20 flex items-center justify-center">
              <span className="material-symbols-outlined text-[#ff6a00]">storage</span>
            </div>
            <div>
              <p className="text-xs text-[#9c8273] font-medium uppercase tracking-wider">Active Servers</p>
              <h3 className="text-2xl font-bold text-white">{onlineServers.length} <span className="text-xs text-emerald-400 font-normal">Online</span></h3>
            </div>
          </div>

          <div className="rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#110a04] p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
              <span className="material-symbols-outlined text-blue-400">shield_person</span>
            </div>
            <div>
              <p className="text-xs text-[#9c8273] font-medium uppercase tracking-wider">Staff Online</p>
              <h3 className="text-2xl font-bold text-white">
                {Object.values(staffOnline).reduce((acc, serverObj) => acc + (typeof serverObj === 'object' ? Object.keys(serverObj).length : 0), 0)}
              </h3>
            </div>
          </div>

          <div className="rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#110a04] p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center">
              <span className="material-symbols-outlined text-red-400">gavel</span>
            </div>
            <div>
              <p className="text-xs text-[#9c8273] font-medium uppercase tracking-wider">Logged Punishments</p>
              <h3 className="text-2xl font-bold text-white">{punishments.length}</h3>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-[rgba(255,120,30,0.1)] pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab("overview")}
          className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 ${
            activeTab === "overview"
              ? "bg-[#ff6a00] text-black shadow-lg shadow-[#ff6a00]/20"
              : "text-[#9c8273] hover:text-white hover:bg-[#1e1008]"
          }`}
        >
          <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>dashboard</span>
          Servers Overview
        </button>

        <button
          onClick={() => setActiveTab("players")}
          className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 ${
            activeTab === "players"
              ? "bg-[#ff6a00] text-black shadow-lg shadow-[#ff6a00]/20"
              : "text-[#9c8273] hover:text-white hover:bg-[#1e1008]"
          }`}
        >
          <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>person</span>
          Online Players
        </button>

        <button
          onClick={() => setActiveTab("staff")}
          className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 ${
            activeTab === "staff"
              ? "bg-[#ff6a00] text-black shadow-lg shadow-[#ff6a00]/20"
              : "text-[#9c8273] hover:text-white hover:bg-[#1e1008]"
          }`}
        >
          <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>shield_person</span>
          Staff Tracking (LuckPerms)
        </button>

        <button
          onClick={() => setActiveTab("punishments")}
          className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 ${
            activeTab === "punishments"
              ? "bg-[#ff6a00] text-black shadow-lg shadow-[#ff6a00]/20"
              : "text-[#9c8273] hover:text-white hover:bg-[#1e1008]"
          }`}
        >
          <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>gavel</span>
          Punishment Logs ({punishments.length})
        </button>

        <button
          onClick={() => setActiveTab("leaderboards")}
          className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 ${
            activeTab === "leaderboards"
              ? "bg-[#ff6a00] text-black shadow-lg shadow-[#ff6a00]/20"
              : "text-[#9c8273] hover:text-white hover:bg-[#1e1008]"
          }`}
        >
          <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>leaderboard</span>
          Scheduled Leaderboards
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin w-8 h-8 border-2 border-[#ff6a00] border-t-transparent rounded-full" />
        </div>
      ) : serverList.length === 0 ? (
        <div className="rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#110a04] p-12 text-center">
          <div className="w-16 h-16 rounded-2xl bg-[#1e1008] flex items-center justify-center mx-auto mb-4">
            <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "32px" }}>dns</span>
          </div>
          <h3 className="text-lg font-semibold text-white mb-2">No Active Minecraft Server Connected</h3>
          <p className="text-[#9c8273] max-w-md mx-auto text-sm">
            Install the <strong>MineStoreBridge</strong> plugin on your Minecraft server and set your <code>website.api-key</code> in <code>plugins/MineStoreBridge/config.yml</code>.
          </p>
        </div>
      ) : (
        <>
          {/* TAB 1: OVERVIEW */}
          {activeTab === "overview" && (
            <div className="space-y-6">
              {serverList.map((server) => (
                <div
                  key={server.serverId}
                  className="rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#110a04] overflow-hidden shadow-xl"
                >
                  {/* Server Header */}
                  <div className="p-6 border-b border-[rgba(255,120,30,0.06)] flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-[#1a0f06] to-transparent">
                    <div>
                      <div className="flex items-center gap-3">
                        <span className={`w-3 h-3 rounded-full ${server._stale || server.status === "OFFLINE" ? "bg-red-500" : "bg-emerald-500 animate-pulse"}`} />
                        <h2 className="text-xl font-bold text-white">
                          {server.serverName || server.serverId}
                        </h2>
                        <span className={`text-xs px-2.5 py-1 rounded-full font-semibold uppercase ${server._stale || server.status === "OFFLINE" ? "bg-red-500/10 text-red-400" : "bg-emerald-500/10 text-emerald-400"}`}>
                          {server._stale || server.status === "OFFLINE" ? "Offline" : "Online"}
                        </span>
                        <span className="text-xs px-2.5 py-1 rounded-full bg-[#1e1008] text-[#ff8c00] font-mono border border-[rgba(255,120,30,0.2)]">
                          ID: {server.serverId}
                        </span>
                        {server.serverVersion && (
                          <span className="text-xs text-[#9c8273]">{server.serverVersion}</span>
                        )}
                      </div>
                      <p className="text-xs text-[#54311e] mt-1 font-mono">{server.motd || "A Minecraft Server"}</p>
                    </div>

                    <div className="flex items-center gap-4 text-xs font-medium">
                      <div className="bg-[#0a0503] px-3 py-1.5 rounded-lg border border-[rgba(255,120,30,0.08)] text-[#9c8273]">
                        Uptime: <span className="text-white">{server.uptimeFormatted}</span>
                      </div>
                      <div className="bg-[#0a0503] px-3 py-1.5 rounded-lg border border-[rgba(255,120,30,0.08)] text-[#9c8273]">
                        Last Beat: <span className="text-white">{new Date(server.lastHeartbeat).toLocaleTimeString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Metrics Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4 p-6">
                    {/* TPS */}
                    <div className="rounded-xl bg-[#0a0503] border border-[rgba(255,120,30,0.06)] p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="material-symbols-outlined text-[#9c8273]" style={{ fontSize: "18px" }}>speed</span>
                        <span className="text-xs text-[#9c8273] font-medium uppercase tracking-wider">TPS</span>
                      </div>
                      <div className="text-2xl font-bold" style={{ color: server.tps1m === null ? "#9c8273" : getTpsColor(server.tps1m) }}>
                        {server.tps1m === null ? "N/A" : server.tps1m.toFixed(1)}
                      </div>
                      <div className="text-xs text-[#54311e] mt-1">
                        5m: {server.tps5m?.toFixed(1) || "N/A"} · 15m: {server.tps15m?.toFixed(1) || "N/A"}
                      </div>
                    </div>

                    {/* Memory */}
                    <div className="rounded-xl bg-[#0a0503] border border-[rgba(255,120,30,0.06)] p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="material-symbols-outlined text-[#9c8273]" style={{ fontSize: "18px" }}>memory</span>
                        <span className="text-xs text-[#9c8273] font-medium uppercase tracking-wider">Memory</span>
                      </div>
                      <div className="text-2xl font-bold" style={{ color: server.memory ? getMemoryColor(server.memory.percentUsed) : "#9c8273" }}>
                        {server.memory ? `${server.memory.percentUsed}%` : "N/A"}
                      </div>
                      <div className="text-xs text-[#54311e] mt-1">
                        {server.memory ? `${server.memory.usedMB}MB / ${server.memory.maxMB}MB` : "Unavailable via RCON"}
                      </div>
                    </div>

                    {/* CPU */}
                    <div className="rounded-xl bg-[#0a0503] border border-[rgba(255,120,30,0.06)] p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="material-symbols-outlined text-[#9c8273]" style={{ fontSize: "18px" }}>developer_board</span>
                        <span className="text-xs text-[#9c8273] font-medium uppercase tracking-wider">CPU Load</span>
                      </div>
                      <div className="text-2xl font-bold text-[#ff8c00]">
                        {server.cpuLoad !== null && server.cpuLoad >= 0 ? server.cpuLoad.toFixed(2) : "N/A"}
                      </div>
                      <div className="text-xs text-[#54311e] mt-1">
                        {server.availableProcessors ?? "N/A"} CPU threads
                      </div>
                    </div>

                    {/* Online Players */}
                    <div className="rounded-xl bg-[#0a0503] border border-[rgba(255,120,30,0.06)] p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="material-symbols-outlined text-emerald-400" style={{ fontSize: "18px" }}>group</span>
                        <span className="text-xs text-emerald-400 font-medium uppercase tracking-wider">Online</span>
                      </div>
                      <div className="text-2xl font-bold text-white">
                        {server.onlinePlayers} <span className="text-xs text-[#54311e]">/ {server.maxPlayers}</span>
                      </div>
                      <div className="text-xs text-[#54311e] mt-1">
                        slots available: {Math.max(0, server.maxPlayers - server.onlinePlayers)}
                      </div>
                    </div>

                    {/* Total Registered */}
                    <div className="rounded-xl bg-[#0a0503] border border-[rgba(255,120,30,0.06)] p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="material-symbols-outlined text-amber-400" style={{ fontSize: "18px" }}>badge</span>
                        <span className="text-xs text-amber-400 font-medium uppercase tracking-wider">Total Members</span>
                      </div>
                      <div className="text-2xl font-bold text-amber-400">
                        {server.totalRegistered ?? server.totalMembersCount ?? "N/A"}
                      </div>
                      <div className="text-xs text-[#54311e] mt-1">
                        unique joins
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 2: PLAYERS */}
          {activeTab === "players" && (
            <div className="space-y-6">
              {serverList.map((server) => (
                <div key={server.serverId} className="rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#110a04] p-6">
                  <h3 className="text-lg font-bold text-white mb-4 flex items-center justify-between">
                    <span>{server.serverName || server.serverId} - Online Players ({server.players?.length || 0})</span>
                  </h3>
                  {server.players && server.players.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      {server.players.map((p) => (
                        <div key={p.uuid} className="p-3.5 rounded-xl bg-[#0a0503] border border-[rgba(255,120,30,0.06)] flex items-center gap-3">
                          <img
                            src={`https://minotar.net/helm/${p.name}/40.png`}
                            alt={p.name}
                            className="w-10 h-10 rounded-lg"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold text-white truncate">{p.name}</p>
                            <p className="text-xs text-[#9c8273]">
                              {p.world} · Lvl {p.level} {p.ping !== undefined ? `· ${p.ping}ms` : ""}
                            </p>
                          </div>
                          <span className="text-xs px-2 py-1 rounded bg-emerald-500/10 text-emerald-400 font-mono">
                            {p.gameMode.toLowerCase()}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-[#9c8273]">No players currently online on this server.</p>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* TAB 3: STAFF TRACKING (LuckPerms) */}
          {activeTab === "staff" && (
            <div className="rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#110a04] p-6 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#ff6a00]">shield_person</span>
                    Live Staff On Duty
                  </h3>
                  <p className="text-xs text-[#9c8273] mt-0.5">Synchronized via LuckPerms staff group detection</p>
                </div>
              </div>

              {Object.keys(staffOnline).length === 0 ? (
                <div className="py-12 text-center text-[#9c8273]">
                  <p className="text-sm">No staff members are currently detected online.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Object.entries(staffOnline).map(([sId, staffMap]) => (
                    <div key={sId} className="space-y-3">
                      <h4 className="text-xs font-semibold text-[#ff8c00] uppercase tracking-wider border-b border-[rgba(255,120,30,0.1)] pb-1">
                        Server: {sId}
                      </h4>
                      {Object.values(staffMap as Record<string, any>).map((staff: any) => (
                        <div key={staff.uuid} className="p-3 rounded-xl bg-[#0a0503] border border-[rgba(255,120,30,0.06)] flex items-center gap-3">
                          <img
                            src={`https://minotar.net/helm/${staff.name}/36.png`}
                            alt={staff.name}
                            className="w-9 h-9 rounded-lg"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold text-white">{staff.name}</p>
                            <span className="inline-block mt-0.5 px-2 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider bg-[#ff6a00]/15 text-[#ff8c00]">
                              {staff.group}
                            </span>
                          </div>
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" title="Online" />
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: PUNISHMENT LOGS */}
          {activeTab === "punishments" && (
            <div className="rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#110a04] p-6 space-y-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span className="material-symbols-outlined text-red-400">gavel</span>
                Live Punishment Logs (LiteBans / AdvancedBan / Vanilla)
              </h3>

              {punishments.length === 0 ? (
                <div className="py-12 text-center text-[#9c8273]">
                  <p className="text-sm">No punishment logs received yet.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-[rgba(255,120,30,0.1)] text-[#9c8273] uppercase tracking-wider">
                        <th className="py-3 px-4">Player</th>
                        <th className="py-3 px-4">Type</th>
                        <th className="py-3 px-4">Reason</th>
                        <th className="py-3 px-4">Staff</th>
                        <th className="py-3 px-4">Server</th>
                        <th className="py-3 px-4">Duration</th>
                        <th className="py-3 px-4">Time</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[rgba(255,120,30,0.04)] font-medium">
                      {punishments.map((p) => (
                        <tr key={p.id} className="hover:bg-[#1a0f06]/50 transition-colors">
                          <td className="py-3 px-4 text-white flex items-center gap-2">
                            <img src={`https://minotar.net/helm/${p.player}/24.png`} alt="" className="w-5 h-5 rounded" />
                            {p.player}
                          </td>
                          <td className="py-3 px-4">
                            <span className={`px-2 py-0.5 rounded font-bold uppercase text-[10px] ${
                              p.type.includes("BAN") ? "bg-red-500/15 text-red-400" :
                              p.type.includes("MUTE") ? "bg-amber-500/15 text-amber-400" :
                              p.type.includes("WARN") ? "bg-yellow-500/15 text-yellow-300" :
                              "bg-slate-500/15 text-slate-300"
                            }`}>
                              {p.type}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-[#c9a48f] max-w-xs truncate">{p.reason}</td>
                          <td className="py-3 px-4 text-white">{p.staff}</td>
                          <td className="py-3 px-4 text-[#ff8c00] font-mono">{p.serverId}</td>
                          <td className="py-3 px-4 text-[#9c8273]">{p.type.includes("KICK") ? "Instant" : formatDuration(p.duration)}</td>
                          <td className="py-3 px-4 text-[#54311e]">{new Date(p.timestamp).toLocaleTimeString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: LEADERBOARDS */}
          {activeTab === "leaderboards" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#ff6a00]">military_tech</span>
                    Configurable Scheduled Command Leaderboards
                  </h3>
                  <p className="text-xs text-[#9c8273]">Executed on server console & parsed in real time (/baltop, /votetop, etc.)</p>
                </div>
              </div>

              {Object.keys(leaderboards).length === 0 ? (
                <div className="rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#110a04] p-12 text-center text-[#9c8273]">
                  <p className="text-sm">No leaderboard results recorded yet.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {Object.entries(leaderboards).map(([name, board]) => (
                    <div key={name} className="rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#110a04] p-5 space-y-4">
                      <div className="flex items-center justify-between border-b border-[rgba(255,120,30,0.06)] pb-3">
                        <div>
                          <h4 className="text-base font-bold text-white">{board.name}</h4>
                          <span className="text-xs font-mono text-[#ff8c00]">/{board.command}</span>
                        </div>
                        <span className="text-xs text-[#54311e]">{new Date(board.updatedAt).toLocaleTimeString()}</span>
                      </div>

                      <div className="space-y-2">
                        {board.entries && board.entries.length > 0 ? (
                          board.entries.slice(0, 10).map((entry) => (
                            <div
                              key={entry.rank}
                              className="flex items-center justify-between py-2 px-3 rounded-xl bg-[#0a0503] border border-[rgba(255,120,30,0.04)] text-xs"
                            >
                              <div className="flex items-center gap-3">
                                <span className={`font-bold w-6 text-center ${
                                  entry.rank === 1 ? 'text-amber-400' :
                                  entry.rank === 2 ? 'text-slate-300' :
                                  entry.rank === 3 ? 'text-amber-600' : 'text-[#9c8273]'
                                }`}>
                                  #{entry.rank}
                                </span>
                                <img src={`https://minotar.net/helm/${entry.playerName}/24.png`} alt="" className="w-5 h-5 rounded" />
                                <span className="text-white font-medium">{entry.playerName}</span>
                              </div>
                              <span className="text-emerald-400 font-semibold">{entry.value}</span>
                            </div>
                          ))
                        ) : (
                          <div className="font-mono text-xs text-[#9c8273] bg-[#0a0503] p-3 rounded-xl space-y-1">
                            {board.rawLines?.slice(0, 8).map((line, i) => (
                              <p key={i}>{line}</p>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* RCON Settings Modal */}
      {showRconModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#110a04] border border-[rgba(255,120,30,0.2)] rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-[rgba(255,120,30,0.1)]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#ff6a00]/10 border border-[#ff6a00]/20 flex items-center justify-center">
                  <span className="material-symbols-outlined text-[#ff6a00]">settings_ethernet</span>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Direct RCON Connection</h3>
                  <p className="text-xs text-[#9c8273]">Connect Next.js directly to your Minecraft server via RCON</p>
                </div>
              </div>
              <button
                onClick={() => setShowRconModal(false)}
                className="text-[#9c8273] hover:text-white p-1 rounded-lg"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleTestRcon} className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2 space-y-1">
                  <label className="text-xs font-semibold text-[#c9a48f]">Server IP / Host</label>
                  <input
                    type="text"
                    value={rconHost}
                    onChange={(e) => setRconHost(e.target.value)}
                    placeholder="127.0.0.1"
                    className="w-full px-3 py-2 rounded-xl bg-[#0a0503] border border-[rgba(255,120,30,0.15)] text-white text-sm focus:outline-none focus:border-[#ff6a00]"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-[#c9a48f]">RCON Port</label>
                  <input
                    type="number"
                    value={rconPort}
                    onChange={(e) => setRconPort(e.target.value)}
                    placeholder="25575"
                    className="w-full px-3 py-2 rounded-xl bg-[#0a0503] border border-[rgba(255,120,30,0.15)] text-white text-sm focus:outline-none focus:border-[#ff6a00]"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#c9a48f]">RCON Password</label>
                <input
                  type="password"
                  value={rconPassword}
                  onChange={(e) => setRconPassword(e.target.value)}
                  placeholder="Matches rcon.password in server.properties"
                  className="w-full px-3 py-2 rounded-xl bg-[#0a0503] border border-[rgba(255,120,30,0.15)] text-white text-sm focus:outline-none focus:border-[#ff6a00]"
                  required
                />
              </div>

              {/* Instructions Callout */}
              <div className="p-3 rounded-xl bg-[#1e1008] border border-[rgba(255,120,30,0.15)] text-xs text-[#9c8273] space-y-1 font-mono">
                <p className="text-white font-semibold">In your server.properties:</p>
                <p className="text-[#ff8c00]">enable-rcon=true</p>
                <p className="text-[#ff8c00]">rcon.port=25575</p>
                <p className="text-[#ff8c00]">rcon.password=YOUR_PASSWORD</p>
              </div>

              {rconStatusMsg && (
                <div
                  className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                    rconStatusMsg.type === "success"
                      ? "bg-emerald-500/10 border border-emerald-500/30 text-emerald-400"
                      : "bg-red-500/10 border border-red-500/30 text-red-400"
                  }`}
                >
                  <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>
                    {rconStatusMsg.type === "success" ? "check_circle" : "error"}
                  </span>
                  <span>{rconStatusMsg.text}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRconModal(false)}
                  className="px-4 py-2 rounded-xl text-sm font-semibold text-[#9c8273] hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={rconLoading || !rconPassword}
                  className="px-5 py-2 rounded-xl bg-[#ff6a00] hover:bg-[#ff8c00] text-black font-bold text-sm transition-all disabled:opacity-50 flex items-center gap-2"
                >
                  {rconLoading && <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />}
                  Test & Connect
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {lastUpdated && (
        <p className="text-xs text-[#54311e] text-center">
          Last updated: {new Date(lastUpdated).toLocaleString()}
        </p>
      )}
    </div>
  );
}


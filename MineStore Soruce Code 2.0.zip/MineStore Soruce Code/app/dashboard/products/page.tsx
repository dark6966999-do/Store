"use client";

import React, { useEffect, useState, useCallback } from "react";
import Link from "next/link";

interface Category {
  id: string;
  name: string;
  color: string;
}

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  thumbnail: string;
  active: boolean;
  featured: boolean;
  createdAt: string;
  category: Category;
}

export default function ProductsListPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: "10" });
      if (search) params.set("search", search);
      if (categoryFilter) params.set("category", categoryFilter);

      const res = await fetch(`/api/products?${params}`);
      const data = await res.json();
      setProducts(data.products || []);
      setTotalPages(data.totalPages || 1);
      setTotal(data.total || 0);
    } catch (err) {
      console.error("Failed to fetch products:", err);
    } finally {
      setLoading(false);
    }
  }, [page, search, categoryFilter]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  useEffect(() => {
    fetch("/api/categories")
      .then((r) => r.json())
      .then((data) => setCategories(data || []))
      .catch(() => {});
  }, []);

  const handleDelete = async () => {
    if (!deleteId) return;
    setDeleting(true);
    try {
      await fetch(`/api/products/${deleteId}`, { method: "DELETE" });
      setDeleteId(null);
      fetchProducts();
    } catch (err) {
      console.error("Failed to delete:", err);
    } finally {
      setDeleting(false);
    }
  };

  const toggleActive = async (product: Product) => {
    try {
      await fetch(`/api/products/${product.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active: !product.active }),
      });
      fetchProducts();
    } catch (err) {
      console.error("Failed to toggle:", err);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white font-[family-name:var(--font-plus-jakarta-sans)] tracking-tight">
            Products
          </h1>
          <p className="text-[#9c8273] text-sm mt-1">{total} total products</p>
        </div>
        <Link
          href="/dashboard/products/new"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] text-white font-bold text-sm hover:from-[#ff7a20] hover:to-[#ff9c20] transition-all shadow-lg shadow-[#ff6a00]/25 font-[family-name:var(--font-plus-jakarta-sans)]"
        >
          <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>add</span>
          Add Product
        </Link>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 material-symbols-outlined text-[#54311e]" style={{ fontSize: "20px" }}>search</span>
          <input
            type="text"
            placeholder="Search products..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
          />
        </div>
        <select
          value={categoryFilter}
          onChange={(e) => { setCategoryFilter(e.target.value); setPage(1); }}
          className="px-4 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white focus:outline-none focus:border-[#ff6a00] transition-all text-sm min-w-[160px]"
        >
          <option value="">All Categories</option>
          {categories.map((cat) => (
            <option key={cat.id} value={cat.id}>{cat.name}</option>
          ))}
        </select>
      </div>

      {/* Table */}
      <div className="bg-[#1e1008]/50 border border-[rgba(255,120,30,0.08)] rounded-2xl overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-48">
            <svg className="animate-spin h-8 w-8 text-[#ff6a00]" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
            </svg>
          </div>
        ) : products.length === 0 ? (
          <div className="p-12 text-center">
            <span className="material-symbols-outlined text-[#54311e] mb-3 block" style={{ fontSize: "48px" }}>inventory_2</span>
            <p className="text-[#9c8273] text-sm">No products found</p>
          </div>
        ) : (
          <>
            {/* Table header */}
            <div className="hidden md:grid grid-cols-[auto_1fr_130px_100px_100px_80px_80px_90px] gap-4 px-5 py-3 border-b border-[rgba(255,120,30,0.08)] text-xs font-semibold text-[#54311e] uppercase tracking-wider">
              <span className="w-10" />
              <span>Product</span>
              <span>Category</span>
              <span className="text-right">Price</span>
              <span className="text-center">Purchases</span>
              <span className="text-center">Status</span>
              <span className="text-center">Featured</span>
              <span className="text-right">Actions</span>
            </div>

            {/* Rows */}
            <div className="divide-y divide-[rgba(255,120,30,0.06)]">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="grid grid-cols-1 md:grid-cols-[auto_1fr_130px_100px_100px_80px_80px_90px] gap-3 md:gap-4 px-5 py-4 hover:bg-[#1e1008]/60 transition-colors items-center"
                >
                  {/* Thumbnail */}
                  <div className="w-10 h-10 rounded-lg bg-[#0c0603] border border-[rgba(255,120,30,0.08)] flex items-center justify-center overflow-hidden flex-shrink-0">
                    {product.thumbnail ? (
                      <img src={product.thumbnail} alt="" className="w-full h-full object-contain p-0.5" />
                    ) : (
                      <span className="material-symbols-outlined text-[#54311e]" style={{ fontSize: "20px" }}>image</span>
                    )}
                  </div>

                  {/* Name */}
                  <div className="min-w-0">
                    <p className="text-white text-sm font-medium truncate">{product.name}</p>
                    <p className="text-[#54311e] text-xs truncate mt-0.5">{product.description || "No description"}</p>
                  </div>

                  {/* Category & Subcategory */}
                  <div className="flex flex-col gap-1 items-start">
                    <span
                      className="text-xs px-2.5 py-0.5 rounded-full font-medium"
                      style={{ backgroundColor: `${product.category?.color || '#ff6a00'}15`, color: product.category?.color || '#ff6a00' }}
                    >
                      {product.category?.name || "Category"}
                    </span>
                    {(product as any).subCategory && (
                      <span className="text-[10px] text-[#9c8273] font-semibold px-1">
                        {(product as any).subCategory}
                      </span>
                    )}
                  </div>

                  {/* Price */}
                  <div className="text-right">
                    <span className="text-[#ff8c00] font-bold text-sm font-[family-name:var(--font-space-grotesk)]">
                      €{product.price.toFixed(2)}
                    </span>
                    {(product as any).originalPrice && (
                      <span className="text-[10px] text-[#9c8273] line-through block">
                        €{parseFloat((product as any).originalPrice).toFixed(2)}
                      </span>
                    )}
                  </div>

                  {/* Purchases / Trending */}
                  <div className="md:text-center">
                    <span className={`inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full font-bold ${
                      ((product as any).purchases || 0) >= 150
                        ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                        : "bg-white/5 text-white/60"
                    }`}>
                      {((product as any).purchases || 0) >= 150 ? "🔥" : "📦"} {(product as any).purchases || 0}
                    </span>
                  </div>

                  {/* Active toggle */}
                  <div className="md:text-center">
                    <button
                      onClick={() => toggleActive(product)}
                      className={`inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full font-medium transition-all ${
                        product.active
                          ? "bg-[#10B981]/15 text-[#10B981]"
                          : "bg-[#54311e]/20 text-[#54311e]"
                      }`}
                    >
                      {product.active ? "Active" : "Draft"}
                    </button>
                  </div>

                  {/* Featured */}
                  <div className="md:text-center">
                    {product.featured && (
                      <span className="material-symbols-outlined text-[#ffa600]" style={{ fontSize: "20px", fontVariationSettings: "'FILL' 1" }}>star</span>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1 md:justify-end">
                    <Link
                      href={`/dashboard/products/${product.id}/edit`}
                      className="p-2 rounded-lg text-[#9c8273] hover:text-[#ff6a00] hover:bg-[#ff6a00]/10 transition-all"
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>edit</span>
                    </Link>
                    <button
                      onClick={() => setDeleteId(product.id)}
                      className="p-2 rounded-lg text-[#9c8273] hover:text-red-400 hover:bg-red-500/10 transition-all"
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>delete</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => setPage(Math.max(1, page - 1))}
            disabled={page === 1}
            className="p-2 rounded-lg text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>chevron_left</span>
          </button>
          <span className="text-sm text-[#9c8273]">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => setPage(Math.min(totalPages, page + 1))}
            disabled={page === totalPages}
            className="p-2 rounded-lg text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>chevron_right</span>
          </button>
        </div>
      )}

      {/* Delete confirmation modal */}
      {deleteId && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="bg-[#1e1008] border border-[rgba(255,120,30,0.15)] rounded-2xl p-6 w-full max-w-sm shadow-2xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
                <span className="material-symbols-outlined text-red-400" style={{ fontSize: "24px" }}>delete_forever</span>
              </div>
              <h3 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)]">Delete Product</h3>
            </div>
            <p className="text-[#9c8273] text-sm mb-6">
              Are you sure you want to delete this product? This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteId(null)}
                className="flex-1 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-[#c9a48f] text-sm font-medium hover:bg-[#1e1008] transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="flex-1 py-2.5 rounded-xl bg-red-500/20 border border-red-500/30 text-red-400 text-sm font-bold hover:bg-red-500/30 transition-all disabled:opacity-50"
              >
                {deleting ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface Category {
  id: string;
  name: string;
  color: string;
}

export default function NewProductPage() {
  const router = useRouter();
  const [categories, setCategories] = useState<Category[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    name: "",
    description: "",
    price: "",
    originalPrice: "",
    subCategory: "Ranks",
    purchases: "0",
    perks: "",
    categoryId: "",
    thumbnail: "",
    featured: false,
    active: true,
  });

  const [commands, setCommands] = useState<string[]>([]);

  useEffect(() => {
    fetch("/api/categories")
      .then((r) => r.json())
      .then((data) => {
        setCategories(data || []);
        if (data?.length > 0 && !form.categoryId) {
          setForm((f) => ({ ...f, categoryId: data[0].id }));
        }
      })
      .catch(() => {});
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSaving(true);

    try {
      const perksArray = form.perks
        .split("\n")
        .map((p) => p.trim())
        .filter(Boolean);

      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          price: parseFloat(form.price) || 0,
          originalPrice: form.originalPrice ? parseFloat(form.originalPrice) : undefined,
          purchases: parseInt(form.purchases) || 0,
          perks: perksArray,
          commands: commands.filter(c => c.trim() !== ""),
        }),
      });

      if (!res.ok) {
        const data = await res.json();
        setError(data.error || "Failed to create product");
        setSaving(false);
        return;
      }

      router.push("/dashboard/products");
    } catch {
      setError("Network error. Please try again.");
      setSaving(false);
    }
  };

  const updateField = (field: string, value: string | boolean) => {
    setForm((f) => ({ ...f, [field]: value }));
  };

  return (
    <div className="max-w-3xl space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => router.back()}
          className="p-2 rounded-lg text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all"
        >
          <span className="material-symbols-outlined" style={{ fontSize: "22px" }}>arrow_back</span>
        </button>
        <div>
          <h1 className="text-2xl font-black text-white font-[family-name:var(--font-plus-jakarta-sans)] tracking-tight">
            Add Product
          </h1>
          <p className="text-[#9c8273] text-sm mt-0.5">Create a new store product</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {error && (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center gap-3">
            <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>error</span>
            {error}
          </div>
        )}

        {/* Main info card */}
        <div className="bg-[#1e1008]/50 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-5">
          <h2 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)] flex items-center gap-2">
            <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "20px" }}>info</span>
            Product Information
          </h2>

          {/* Name */}
          <div>
            <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Product Name *</label>
            <input
              type="text"
              value={form.name}
              onChange={(e) => updateField("name", e.target.value)}
              placeholder="e.g. Diamond Rank"
              required
              className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] focus:ring-1 focus:ring-[#ff6a00]/30 transition-all text-sm"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Description</label>
            <textarea
              value={form.description}
              onChange={(e) => updateField("description", e.target.value)}
              placeholder="Describe what this product includes..."
              rows={4}
              className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] focus:ring-1 focus:ring-[#ff6a00]/30 transition-all text-sm resize-none"
            />
          </div>

          {/* Price + Category row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Price (€ EUR) *</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#54311e] text-sm font-bold">€</span>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={form.price}
                  onChange={(e) => updateField("price", e.target.value)}
                  placeholder="9.99"
                  required
                  className="w-full pl-8 pr-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] focus:ring-1 focus:ring-[#ff6a00]/30 transition-all text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Original Price (For Discount Badge)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#54311e] text-sm font-bold">€</span>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="Optional crossed out price"
                  value={form.originalPrice}
                  onChange={(e) => updateField("originalPrice", e.target.value)}
                  className="w-full pl-8 pr-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] focus:ring-1 focus:ring-[#ff6a00]/30 transition-all text-sm"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Category *</label>
              <select
                value={form.categoryId}
                onChange={(e) => updateField("categoryId", e.target.value)}
                required
                className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
              >
                <option value="">Select category</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
              {categories.length === 0 && (
                <p className="text-[#ff6a00] text-xs mt-1">
                  No categories yet. <a href="/dashboard/categories" className="underline">Create one first</a>.
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Subcategory Tab</label>
              <input
                type="text"
                placeholder="Ranks or Rank Upgrades"
                value={form.subCategory}
                onChange={(e) => updateField("subCategory", e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] focus:ring-1 focus:ring-[#ff6a00]/30 transition-all text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Purchases Count (Trending)</label>
              <input
                type="number"
                min="0"
                value={form.purchases}
                onChange={(e) => updateField("purchases", e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] focus:ring-1 focus:ring-[#ff6a00]/30 transition-all text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-[#c9a48f] mb-2">
              Perks & Commands List (1 perk per line)
            </label>
            <textarea
              rows={4}
              placeholder="/kit Samurai (Armor & Weapons)&#10;Access to /feed&#10;3 Homes (/sethome)"
              value={form.perks}
              onChange={(e) => updateField("perks", e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] focus:ring-1 focus:ring-[#ff6a00]/30 transition-all text-sm resize-none font-mono text-xs"
            />
          </div>
        </div>

        {/* Delivery Commands card */}
        <div className="bg-[#1e1008]/50 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)] flex items-center gap-2">
              <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "20px" }}>terminal</span>
              Delivery Commands
            </h2>
            <button
              type="button"
              onClick={() => setCommands([...commands, ""])}
              className="px-3 py-1.5 rounded-lg bg-[#ff6a00]/10 border border-[#ff6a00]/20 text-[#ff6a00] text-xs font-semibold hover:bg-[#ff6a00]/20 transition-all flex items-center gap-1"
            >
              <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>add</span>
              Add Command
            </button>
          </div>

          <p className="text-[#9c8273] text-xs leading-relaxed">
            RCON commands executed when this product is purchased. Use placeholders: <code className="text-[#ff6a00] bg-[#ff6a00]/10 px-1.5 py-0.5 rounded">{'{player}'}</code> <code className="text-[#ff6a00] bg-[#ff6a00]/10 px-1.5 py-0.5 rounded">{'{quantity}'}</code> <code className="text-[#ff6a00] bg-[#ff6a00]/10 px-1.5 py-0.5 rounded">{'{product}'}</code>. Leave empty to use auto-detection.
          </p>

          {commands.length === 0 ? (
            <div className="border border-dashed border-[rgba(255,120,30,0.15)] rounded-xl p-6 text-center">
              <span className="material-symbols-outlined text-[#54311e] mb-2" style={{ fontSize: "32px" }}>code_off</span>
              <p className="text-[#54311e] text-sm">No custom commands. Auto-detection will be used.</p>
              <p className="text-[#54311e]/60 text-xs mt-1">Click &quot;Add Command&quot; to define custom RCON commands.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {commands.map((cmd, idx) => (
                <div key={idx} className="flex items-center gap-2 group">
                  <span className="text-[#54311e] text-xs font-mono w-6 text-right shrink-0">#{idx + 1}</span>
                  <input
                    type="text"
                    value={cmd}
                    onChange={(e) => {
                      const newCmds = [...commands];
                      newCmds[idx] = e.target.value;
                      setCommands(newCmds);
                    }}
                    placeholder="e.g. lp user {player} parent add vip"
                    className="flex-1 px-4 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] focus:ring-1 focus:ring-[#ff6a00]/30 transition-all text-sm font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setCommands(commands.filter((_, i) => i !== idx))}
                    className="p-1.5 rounded-lg text-[#54311e] hover:text-red-400 hover:bg-red-500/10 transition-all opacity-0 group-hover:opacity-100"
                  >
                    <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>close</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Media card */}
        <div className="bg-[#1e1008]/50 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-5">
          <h2 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)] flex items-center gap-2">
            <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "20px" }}>image</span>
            Media
          </h2>

          <div>
            <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Thumbnail URL</label>
            <input
              type="url"
              value={form.thumbnail}
              onChange={(e) => updateField("thumbnail", e.target.value)}
              placeholder="https://example.com/image.png"
              className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] focus:ring-1 focus:ring-[#ff6a00]/30 transition-all text-sm"
            />
          </div>

          {form.thumbnail && (
            <div className="w-24 h-24 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] overflow-hidden">
              <img src={form.thumbnail} alt="Preview" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
            </div>
          )}
        </div>

        {/* Options card */}
        <div className="bg-[#1e1008]/50 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-5">
          <h2 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)] flex items-center gap-2">
            <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "20px" }}>tune</span>
            Options
          </h2>

          <div className="space-y-4">
            {/* Active toggle */}
            <label className="flex items-center justify-between cursor-pointer group">
              <div>
                <p className="text-white text-sm font-medium">Active</p>
                <p className="text-[#54311e] text-xs mt-0.5">Product is visible in the store</p>
              </div>
              <div
                onClick={() => updateField("active", !form.active)}
                className={`relative w-11 h-6 rounded-full transition-colors cursor-pointer ${
                  form.active ? "bg-[#ff6a00]" : "bg-[#54311e]/40"
                }`}
              >
                <div className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                  form.active ? "translate-x-5" : "translate-x-0"
                }`} />
              </div>
            </label>

            {/* Featured toggle */}
            <label className="flex items-center justify-between cursor-pointer group">
              <div>
                <p className="text-white text-sm font-medium">Featured</p>
                <p className="text-[#54311e] text-xs mt-0.5">Highlight this product on the storefront</p>
              </div>
              <div
                onClick={() => updateField("featured", !form.featured)}
                className={`relative w-11 h-6 rounded-full transition-colors cursor-pointer ${
                  form.featured ? "bg-[#ffa600]" : "bg-[#54311e]/40"
                }`}
              >
                <div className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                  form.featured ? "translate-x-5" : "translate-x-0"
                }`} />
              </div>
            </label>
          </div>
        </div>

        {/* Submit */}
        <div className="flex gap-3">
          <button
            type="button"
            onClick={() => router.back()}
            className="px-6 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-[#c9a48f] text-sm font-medium hover:bg-[#1e1008] transition-all"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="flex-1 sm:flex-none px-8 py-3 rounded-xl bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] text-white font-bold text-sm hover:from-[#ff7a20] hover:to-[#ff9c20] transition-all shadow-lg shadow-[#ff6a00]/25 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 font-[family-name:var(--font-plus-jakarta-sans)]"
          >
            {saving ? (
              <>
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
                Creating...
              </>
            ) : (
              <>
                <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>add</span>
                Create Product
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}

"use client";

import React, { useEffect, useState, useCallback } from "react";

interface StaffMember {
  id: string;
  name: string;
  role: string;
  group: "Owner" | "Manager" | "Developer" | "Admin" | "Sr Mod" | "Moderator" | "Trial";
  roleColor?: string;
  avatarUrl: string;
  joinedDate: string;
  messages: number;
  reactions: number;
  points: number;
  about?: string;
  discord?: string;
  status: string;
  order: number;
  active: boolean;
}

const GROUPS = [
  "Owner",
  "Manager",
  "Developer",
  "Admin",
  "Sr Mod",
  "Moderator",
  "Trial",
] as const;

export default function DashboardStaffPage() {
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: "",
    role: "",
    group: "Moderator" as StaffMember["group"],
    roleColor: "#ff6a00",
    avatarUrl: "",
    joinedDate: "",
    messages: 0,
    reactions: 0,
    points: 0,
    about: "",
    discord: "",
    status: "In Game",
    order: 0,
    active: true,
  });

  const fetchStaff = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/staff");
      const data = await res.json();
      if (data && data.staff) {
        setStaff(data.staff);
      }
    } catch {
      console.error("Failed to load staff");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStaff();
  }, [fetchStaff]);

  const openCreateModal = () => {
    setEditingStaff(null);
    setFormData({
      name: "",
      role: "",
      group: "Moderator",
      roleColor: "#ff6a00",
      avatarUrl: "",
      joinedDate: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      messages: 100,
      reactions: 50,
      points: 25,
      about: "",
      discord: "",
      status: "In Game",
      order: staff.length + 1,
      active: true,
    });
    setError("");
    setModalOpen(true);
  };

  const openEditModal = (member: StaffMember) => {
    setEditingStaff(member);
    setFormData({
      name: member.name,
      role: member.role,
      group: member.group,
      roleColor: member.roleColor || "#ff6a00",
      avatarUrl: member.avatarUrl,
      joinedDate: member.joinedDate,
      messages: member.messages,
      reactions: member.reactions,
      points: member.points,
      about: member.about || "",
      discord: member.discord || "",
      status: member.status || "In Game",
      order: member.order,
      active: member.active,
    });
    setError("");
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);

    try {
      const url = editingStaff ? `/api/staff/${editingStaff.id}` : "/api/staff";
      const method = editingStaff ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!res.ok) {
        const data = await res.json();
        setError(data.error || "Failed to save team member");
        setSubmitting(false);
        return;
      }

      setModalOpen(false);
      fetchStaff();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await fetch(`/api/staff/${id}`, { method: "DELETE" });
      if (res.ok) {
        setStaff((prev) => prev.filter((m) => m.id !== id));
        setDeleteConfirmId(null);
      }
    } catch {
      console.error("Failed to delete staff member");
    }
  };

  const handleToggleActive = async (member: StaffMember) => {
    try {
      const res = await fetch(`/api/staff/${member.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active: !member.active }),
      });
      if (res.ok) {
        setStaff((prev) =>
          prev.map((m) => (m.id === member.id ? { ...m, active: !m.active } : m))
        );
      }
    } catch {
      console.error("Failed to toggle status");
    }
  };

  const handleAutoAvatar = () => {
    if (formData.name) {
      setFormData((f) => ({
        ...f,
        avatarUrl: `https://minotar.net/helm/${encodeURIComponent(formData.name.trim())}/128.png`,
      }));
    }
  };

  const filteredStaff = staff.filter(
    (m) =>
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      m.role.toLowerCase().includes(search.toLowerCase()) ||
      m.group.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white font-[family-name:var(--font-plus-jakarta-sans)]">
            Staff Management
          </h1>
          <p className="text-sm text-[#9c8273] mt-1">
            Manage your network staff members, roles, permissions, and profile information.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <a
            href="/staff"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#140a05] text-[#9c8273] hover:text-white border border-[rgba(255,120,30,0.15)] text-xs font-bold transition-all"
          >
            <span className="material-symbols-outlined text-base">visibility</span>
            View Live Page
          </a>
          <button
            onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] text-white text-xs font-bold shadow-lg shadow-[#ff6a00]/25 hover:from-[#ff7a20] hover:to-[#ff9c20] transition-all cursor-pointer font-[family-name:var(--font-plus-jakarta-sans)]"
          >
            <span className="material-symbols-outlined text-base">add</span>
            Add Team Member
          </button>
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="flex items-center justify-between gap-4 bg-[#140a05] border border-[rgba(255,120,30,0.1)] rounded-2xl p-4">
        <div className="relative flex-1 max-w-md">
          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 material-symbols-outlined text-[#8a6b58] text-lg">
            search
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by username, role, or group..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#6a4e3e] text-xs focus:outline-none focus:border-[#ff6a00] transition-all"
          />
        </div>

        <span className="text-xs text-[#8a6b58] font-bold">
          {filteredStaff.length} Members
        </span>
      </div>

      {/* Staff Table / Cards */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-20 rounded-2xl bg-[#140a05] animate-pulse border border-[rgba(255,120,30,0.08)]" />
          ))}
        </div>
      ) : filteredStaff.length === 0 ? (
        <div className="text-center py-16 bg-[#140a05]/50 border border-[rgba(255,120,30,0.08)] rounded-2xl">
          <span className="material-symbols-outlined text-4xl text-[#8a6b58] mb-2">group_off</span>
          <p className="text-white font-bold text-sm">No staff members found</p>
          <p className="text-xs text-[#8a6b58] mt-1">Click &ldquo;Add Team Member&rdquo; above to create one.</p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#140a05]">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-[rgba(255,120,30,0.1)] bg-[#0d0603] text-[#8a6b58] uppercase font-bold tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Member</th>
                <th className="py-3.5 px-4">Group & Role</th>
                <th className="py-3.5 px-4">Joined Date</th>
                <th className="py-3.5 px-4 text-center">Messages</th>
                <th className="py-3.5 px-4 text-center">Reactions</th>
                <th className="py-3.5 px-4 text-center">Points</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[rgba(255,120,30,0.06)]">
              {filteredStaff.map((member) => (
                <tr key={member.id} className="hover:bg-[#1a0e07]/60 transition-colors">
                  {/* Member Name + Avatar */}
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg overflow-hidden bg-[#241107] border border-[rgba(255,120,30,0.2)] flex-shrink-0">
                        <img
                          src={member.avatarUrl || `https://minotar.net/helm/${encodeURIComponent(member.name)}/64.png`}
                          alt={member.name}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = `https://minotar.net/helm/${encodeURIComponent(member.name)}/64.png`;
                          }}
                        />
                      </div>
                      <div>
                        <p className="font-bold text-white text-sm">{member.name}</p>
                        {member.discord && (
                          <p className="text-[11px] text-[#5865F2] font-mono">{member.discord}</p>
                        )}
                      </div>
                    </div>
                  </td>

                  {/* Group & Role */}
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <span
                        className="px-2 py-0.5 rounded-md text-[10px] font-bold text-white shadow-sm"
                        style={{ backgroundColor: member.roleColor || "#ff6a00" }}
                      >
                        {member.role}
                      </span>
                      <span className="text-[11px] text-[#8a6b58] font-semibold">
                        ({member.group})
                      </span>
                    </div>
                  </td>

                  {/* Joined Date */}
                  <td className="py-3 px-4 text-[#9c8273]">
                    {member.joinedDate}
                  </td>

                  {/* Stats */}
                  <td className="py-3 px-4 text-center font-bold text-white">
                    {member.messages.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-center font-bold text-[#ff8c00]">
                    {member.reactions.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-center font-bold text-emerald-400">
                    {member.points.toLocaleString()}
                  </td>

                  {/* Active Toggle */}
                  <td className="py-3 px-4 text-center">
                    <button
                      onClick={() => handleToggleActive(member)}
                      className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-all cursor-pointer ${
                        member.active
                          ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"
                          : "bg-red-500/15 text-red-400 border border-red-500/30"
                      }`}
                    >
                      {member.active ? "Active" : "Hidden"}
                    </button>
                  </td>

                  {/* Actions */}
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => openEditModal(member)}
                        className="p-1.5 rounded-lg text-[#9c8273] hover:text-white hover:bg-[#2c150a] transition-colors"
                        title="Edit member"
                      >
                        <span className="material-symbols-outlined text-base">edit</span>
                      </button>

                      {deleteConfirmId === member.id ? (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleDelete(member.id)}
                            className="px-2 py-1 rounded bg-red-600 hover:bg-red-700 text-white text-[10px] font-bold"
                          >
                            Confirm
                          </button>
                          <button
                            onClick={() => setDeleteConfirmId(null)}
                            className="px-2 py-1 rounded bg-[#241107] text-[#9c8273] text-[10px]"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setDeleteConfirmId(member.id)}
                          className="p-1.5 rounded-lg text-[#9c8273] hover:text-red-400 hover:bg-red-500/10 transition-colors"
                          title="Delete member"
                        >
                          <span className="material-symbols-outlined text-base">delete</span>
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Edit / Create Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-[#160b05] border border-[rgba(255,120,30,0.25)] rounded-2xl w-full max-w-xl p-6 sm:p-8 shadow-2xl my-8">
            <div className="flex items-center justify-between pb-4 border-b border-[rgba(255,120,30,0.1)]">
              <h2 className="text-xl font-black text-white font-[family-name:var(--font-plus-jakarta-sans)] flex items-center gap-2">
                <span className="material-symbols-outlined text-[#ff6a00]">
                  {editingStaff ? "edit" : "person_add"}
                </span>
                {editingStaff ? "Edit Staff Member" : "Add Staff Member"}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1 text-[#8a6b58] hover:text-white rounded-lg transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            {error && (
              <div className="mt-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="mt-5 space-y-4">
              {/* Row 1: Name and Role */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#c9a48f] mb-1.5">
                    Minecraft / Forum Username *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Max"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.15)] text-white text-xs focus:outline-none focus:border-[#ff6a00]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#c9a48f] mb-1.5">
                    Role Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    placeholder="e.g. Owner, Lead Developer, Sr Mod"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.15)] text-white text-xs focus:outline-none focus:border-[#ff6a00]"
                  />
                </div>
              </div>

              {/* Row 2: Group Category & Badge Color */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#c9a48f] mb-1.5">
                    Staff Group Hierarchy
                  </label>
                  <select
                    value={formData.group}
                    onChange={(e) =>
                      setFormData({ ...formData, group: e.target.value as StaffMember["group"] })
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.15)] text-white text-xs focus:outline-none focus:border-[#ff6a00]"
                  >
                    {GROUPS.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#c9a48f] mb-1.5">
                    Badge Hex Color
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={formData.roleColor}
                      onChange={(e) => setFormData({ ...formData, roleColor: e.target.value })}
                      className="w-10 h-10 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.15)] cursor-pointer"
                    />
                    <input
                      type="text"
                      value={formData.roleColor}
                      onChange={(e) => setFormData({ ...formData, roleColor: e.target.value })}
                      className="flex-1 px-3 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.15)] text-white text-xs font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Row 3: Avatar URL + Minecraft auto-fetch */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-[#c9a48f]">
                    Avatar Image URL
                  </label>
                  <button
                    type="button"
                    onClick={handleAutoAvatar}
                    className="text-[11px] text-[#ff8c00] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-xs">auto_awesome</span>
                    Auto-generate from Minecraft Skin
                  </button>
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="url"
                    value={formData.avatarUrl}
                    onChange={(e) => setFormData({ ...formData, avatarUrl: e.target.value })}
                    placeholder="https://... or leave blank for auto Minecraft avatar"
                    className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.15)] text-white text-xs focus:outline-none focus:border-[#ff6a00]"
                  />
                  {formData.avatarUrl && (
                    <div className="w-10 h-10 rounded-lg overflow-hidden bg-[#0c0603] border border-[rgba(255,120,30,0.2)] flex-shrink-0">
                      <img src={formData.avatarUrl} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>
              </div>

              {/* Row 4: Joined Date & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#c9a48f] mb-1.5">
                    Joined Date (e.g. May 30, 2016)
                  </label>
                  <input
                    type="text"
                    value={formData.joinedDate}
                    onChange={(e) => setFormData({ ...formData, joinedDate: e.target.value })}
                    placeholder="May 30, 2016"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.15)] text-white text-xs focus:outline-none focus:border-[#ff6a00]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#c9a48f] mb-1.5">
                    Current Status / Activity
                  </label>
                  <input
                    type="text"
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                    placeholder="e.g. In Forums, In Game, Online"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.15)] text-white text-xs focus:outline-none focus:border-[#ff6a00]"
                  />
                </div>
              </div>

              {/* Row 5: Stats (Messages, Reaction Score, Points matching reference image) */}
              <div className="grid grid-cols-3 gap-3 p-3.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.1)]">
                <div>
                  <label className="block text-[11px] font-bold text-[#8a6b58] mb-1 uppercase">
                    Messages
                  </label>
                  <input
                    type="number"
                    value={formData.messages}
                    onChange={(e) => setFormData({ ...formData, messages: parseInt(e.target.value || "0", 10) })}
                    className="w-full px-3 py-1.5 rounded-lg bg-[#140a05] border border-[rgba(255,120,30,0.15)] text-white text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#8a6b58] mb-1 uppercase">
                    Reaction score
                  </label>
                  <input
                    type="number"
                    value={formData.reactions}
                    onChange={(e) => setFormData({ ...formData, reactions: parseInt(e.target.value || "0", 10) })}
                    className="w-full px-3 py-1.5 rounded-lg bg-[#140a05] border border-[rgba(255,120,30,0.15)] text-white text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#8a6b58] mb-1 uppercase">
                    Points
                  </label>
                  <input
                    type="number"
                    value={formData.points}
                    onChange={(e) => setFormData({ ...formData, points: parseInt(e.target.value || "0", 10) })}
                    className="w-full px-3 py-1.5 rounded-lg bg-[#140a05] border border-[rgba(255,120,30,0.15)] text-white text-xs font-bold"
                  />
                </div>
              </div>

              {/* Row 6: Discord & About */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#c9a48f] mb-1.5">
                    Discord Tag
                  </label>
                  <input
                    type="text"
                    value={formData.discord}
                    onChange={(e) => setFormData({ ...formData, discord: e.target.value })}
                    placeholder="e.g. Max#0001"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.15)] text-white text-xs focus:outline-none focus:border-[#ff6a00]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#c9a48f] mb-1.5">
                    Display Order Index
                  </label>
                  <input
                    type="number"
                    value={formData.order}
                    onChange={(e) => setFormData({ ...formData, order: parseInt(e.target.value || "1", 10) })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.15)] text-white text-xs focus:outline-none focus:border-[#ff6a00]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#c9a48f] mb-1.5">
                  About / Bio Description
                </label>
                <textarea
                  rows={2}
                  value={formData.about}
                  onChange={(e) => setFormData({ ...formData, about: e.target.value })}
                  placeholder="Short description of member duties, realms managed, etc."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.15)] text-white text-xs focus:outline-none focus:border-[#ff6a00]"
                />
              </div>

              {/* Active Toggle */}
              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="staff-active"
                  checked={formData.active}
                  onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
                  className="w-4 h-4 accent-[#ff6a00] rounded"
                />
                <label htmlFor="staff-active" className="text-xs font-bold text-white cursor-pointer">
                  Display this staff member publicly on the /staff page
                </label>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-3 pt-4 border-t border-[rgba(255,120,30,0.1)]">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-[#1f1008] text-[#9c8273] hover:text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] text-white text-xs font-bold shadow-lg shadow-[#ff6a00]/25 hover:from-[#ff7a20] hover:to-[#ff9c20] transition-all cursor-pointer disabled:opacity-50"
                >
                  {submitting ? "Saving..." : editingStaff ? "Save Changes" : "Create Member"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

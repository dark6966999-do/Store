"use client";

import React, { useState, useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import { STORE_URL } from "@/lib/urls";

const navItems = [
  { label: "Overview", icon: "dashboard", href: "/dashboard" },
  { label: "Products", icon: "inventory_2", href: "/dashboard/products" },
  { label: "Categories", icon: "category", href: "/dashboard/categories" },
  { label: "Customers", icon: "group", href: "/dashboard/customers" },
  { label: "Transactions", icon: "receipt_long", href: "/dashboard/transactions" },
  { label: "Staff Team", icon: "shield_person", href: "/dashboard/staff" },
  { label: "Appearance", icon: "palette", href: "/dashboard/appearance" },
  { label: "Server Status", icon: "dns", href: "/dashboard/server" },
  { label: "Console", icon: "terminal", href: "/dashboard/console" },
  { label: "Settings", icon: "settings", href: "/dashboard/settings" },
];

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [adminEmail, setAdminEmail] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((res) => res.json())
      .then((data) => {
        if (data.authenticated) {
          setAdminEmail(data.email);
        }
      })
      .catch(() => {});
  }, []);

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/dashboard/login");
    router.refresh();
  };

  // Don't show dashboard shell on login page
  if (pathname === "/dashboard/login") {
    return <>{children}</>;
  }

  return (
    <div className="flex h-screen bg-[#0a0503] overflow-hidden">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed lg:static z-50 h-full flex flex-col border-r border-[rgba(255,120,30,0.08)] bg-[#0c0603]/95 backdrop-blur-xl transition-all duration-300 ${
          collapsed ? "w-[72px]" : "w-[260px]"
        } ${mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}
      >
        {/* Logo area */}
        <div className={`flex items-center h-16 border-b border-[rgba(255,120,30,0.08)] px-4 ${collapsed ? "justify-center" : "gap-3"}`}>
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#ff6a00] to-[#ff8c00] flex items-center justify-center flex-shrink-0 shadow-lg shadow-[#ff6a00]/20">
            <span className="material-symbols-outlined text-white" style={{ fontSize: "20px", fontVariationSettings: "'FILL' 1" }}>
              store
            </span>
          </div>
          {!collapsed && (
            <span className="font-black text-white text-lg tracking-tight font-[family-name:var(--font-plus-jakarta-sans)] truncate">
              MineStore
            </span>
          )}
        </div>

        {/* Nav items */}
        <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group ${
                  isActive
                    ? "bg-[#ff6a00]/15 text-[#ff8c00] shadow-sm"
                    : "text-[#9c8273] hover:text-white hover:bg-[#1e1008]"
                } ${collapsed ? "justify-center" : ""}`}
              >
                <span
                  className={`material-symbols-outlined flex-shrink-0 transition-colors ${
                    isActive ? "text-[#ff6a00]" : "text-[#9c8273] group-hover:text-white"
                  }`}
                  style={{ fontSize: "22px", fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
                >
                  {item.icon}
                </span>
                {!collapsed && <span className="truncate">{item.label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* Sidebar footer */}
        <div className={`border-t border-[rgba(255,120,30,0.08)] p-3 space-y-2`}>
          {/* View store */}
          <a
            href={STORE_URL}
            target="_blank"
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all ${collapsed ? "justify-center" : ""}`}
          >
            <span className="material-symbols-outlined" style={{ fontSize: "22px" }}>storefront</span>
            {!collapsed && <span>View Store</span>}
          </a>

          {/* Collapse toggle */}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className={`hidden lg:flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all w-full ${collapsed ? "justify-center" : ""}`}
          >
            <span className="material-symbols-outlined" style={{ fontSize: "22px" }}>
              {collapsed ? "chevron_right" : "chevron_left"}
            </span>
            {!collapsed && <span>Collapse</span>}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="h-16 border-b border-[rgba(255,120,30,0.08)] bg-[#0c0603]/80 backdrop-blur-xl flex items-center justify-between px-4 lg:px-6 flex-shrink-0">
          {/* Mobile menu + breadcrumb */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 rounded-lg text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all"
            >
              <span className="material-symbols-outlined" style={{ fontSize: "24px" }}>menu</span>
            </button>

            <div className="flex items-center gap-2 text-sm">
              <span className="text-[#54311e]">Dashboard</span>
              {pathname !== "/dashboard" && (
                <>
                  <span className="text-[#54311e]">/</span>
                  <span className="text-[#c9a48f] capitalize">
                    {pathname.split("/").filter(Boolean).slice(1).join(" / ")}
                  </span>
                </>
              )}
            </div>
          </div>

          {/* Right side */}
          <div className="flex items-center gap-3">
            {/* Admin info */}
            <div className="hidden sm:flex items-center gap-3">
              <div className="text-right">
                <p className="text-sm font-medium text-white truncate max-w-[160px]">{adminEmail || "Admin"}</p>
                <p className="text-xs text-[#54311e]">Administrator</p>
              </div>
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#ff6a00] to-[#ff8c00] flex items-center justify-center text-white text-sm font-bold shadow-lg shadow-[#ff6a00]/20">
                A
              </div>
            </div>

            {/* Logout */}
            <button
              onClick={handleLogout}
              className="p-2 rounded-lg text-[#9c8273] hover:text-red-400 hover:bg-red-500/10 transition-all"
              title="Logout"
            >
              <span className="material-symbols-outlined" style={{ fontSize: "22px" }}>logout</span>
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

"use client";

import React, { useEffect, useState, useCallback } from "react";

interface Customer {
  username: string;
  avatar: string;
  totalSpent: number;
  currency: string;
  orderCount: number;
  lastOrder: string;
  firstOrder: string;
  email?: string;
  country?: string;
  statuses: Record<string, number>;
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  const fetchCustomers = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: "15" });
      if (search) params.set("search", search);
      const res = await fetch(`/api/dashboard/customers?${params}`);
      const data = await res.json();
      setCustomers(data.customers || []);
      setTotalPages(data.totalPages || 1);
      setTotal(data.total || 0);
    } catch (err) {
      console.error("Failed to fetch customers:", err);
    } finally {
      setLoading(false);
    }
  }, [page, search]);

  useEffect(() => {
    fetchCustomers();
  }, [fetchCustomers]);

  useEffect(() => {
    setPage(1);
  }, [search]);

  const topSpender = customers.length > 0 ? customers[0] : null;
  const avgSpend =
    customers.length > 0
      ? customers.reduce((s, c) => s + c.totalSpent, 0) / customers.length
      : 0;

  function timeAgo(dateStr: string) {
    const d = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    if (days === 0) return "Today";
    if (days === 1) return "Yesterday";
    if (days < 30) return `${days}d ago`;
    if (days < 365) return `${Math.floor(days / 30)}mo ago`;
    return `${Math.floor(days / 365)}y ago`;
  }

  if (loading && customers.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-3">
          <svg className="animate-spin h-8 w-8 text-[#ff6a00]" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
          <span className="text-[#9c8273] text-sm">Loading customers...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5 max-w-[1400px]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white font-[family-name:var(--font-plus-jakarta-sans)] tracking-tight">
            Customers
          </h1>
          <p className="text-[#9c8273] text-sm mt-1">
            {total} unique customer{total !== 1 ? "s" : ""} found
          </p>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#ff6a00]/10 flex items-center justify-center">
              <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "22px", fontVariationSettings: "'FILL' 1" }}>group</span>
            </div>
            <div>
              <p className="text-[#54311e] text-[10px] font-semibold uppercase tracking-widest">Total Customers</p>
              <p className="text-2xl font-black text-white font-[family-name:var(--font-space-grotesk)]">{total}</p>
            </div>
          </div>
        </div>

        <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#10B981]/10 flex items-center justify-center">
              <span className="material-symbols-outlined text-[#10B981]" style={{ fontSize: "22px", fontVariationSettings: "'FILL' 1" }}>trending_up</span>
            </div>
            <div>
              <p className="text-[#54311e] text-[10px] font-semibold uppercase tracking-widest">Avg. Spend</p>
              <p className="text-2xl font-black text-white font-[family-name:var(--font-space-grotesk)]">${avgSpend.toFixed(2)}</p>
            </div>
          </div>
        </div>

        <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-5">
          <div className="flex items-center gap-3">
            {topSpender && (
              <img
                src={topSpender.avatar}
                alt={topSpender.username}
                className="w-10 h-10 rounded-xl"
                style={{ imageRendering: "pixelated" }}
              />
            )}
            <div>
              <p className="text-[#54311e] text-[10px] font-semibold uppercase tracking-widest">Top Spender</p>
              <p className="text-lg font-bold text-white truncate">{topSpender?.username || "—"}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-[#54311e]" style={{ fontSize: "20px" }}>search</span>
        <input
          type="text"
          placeholder="Search by username or email..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-[#1e1008]/60 border border-[rgba(255,120,30,0.1)] rounded-xl pl-11 pr-4 py-2.5 text-sm text-white placeholder:text-[#54311e] focus:outline-none focus:border-[#ff6a00]/40 transition-colors"
        />
      </div>

      {/* Customer table */}
      <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl overflow-hidden">
        {/* Header row */}
        <div className="hidden md:grid grid-cols-[1fr_140px_100px_120px_120px_60px] items-center px-5 py-3 text-[10px] font-bold text-[#54311e] uppercase tracking-widest border-b border-[rgba(255,120,30,0.04)]">
          <span>Customer</span>
          <span>Total Spent</span>
          <span>Orders</span>
          <span>First Order</span>
          <span>Last Active</span>
          <span className="text-right">View</span>
        </div>

        <div className="divide-y divide-[rgba(255,120,30,0.04)]">
          {customers.length === 0 ? (
            <div className="p-12 text-center">
              <span className="material-symbols-outlined text-[#54311e] mb-3 block" style={{ fontSize: "48px" }}>person_off</span>
              <p className="text-[#9c8273] text-sm">No customers found</p>
            </div>
          ) : (
            customers.map((customer) => (
              <div
                key={customer.username}
                className="grid grid-cols-1 md:grid-cols-[1fr_140px_100px_120px_120px_60px] items-center px-5 py-4 hover:bg-[rgba(255,120,30,0.03)] transition-colors gap-2 md:gap-0"
              >
                {/* Customer info */}
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={customer.avatar}
                    alt={customer.username}
                    className="w-10 h-10 rounded-xl flex-shrink-0"
                    style={{ imageRendering: "pixelated" }}
                  />
                  <div className="min-w-0">
                    <p className="text-white text-sm font-semibold truncate">{customer.username}</p>
                    {customer.email && (
                      <p className="text-[#54311e] text-xs truncate">{customer.email}</p>
                    )}
                  </div>
                </div>

                {/* Total spent */}
                <div className="flex items-center gap-1 md:block">
                  <span className="md:hidden text-[#54311e] text-xs">Spent:</span>
                  <p className="text-[#ff8c00] text-sm font-bold font-[family-name:var(--font-space-grotesk)]">
                    ${customer.totalSpent.toFixed(2)}
                  </p>
                </div>

                {/* Order count */}
                <div className="flex items-center gap-1 md:block">
                  <span className="md:hidden text-[#54311e] text-xs">Orders:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-white text-sm font-[family-name:var(--font-space-grotesk)]">
                      {customer.orderCount}
                    </span>
                    {customer.orderCount >= 5 && (
                      <span className="text-[8px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded-full bg-[#ffa600]/15 text-[#ffa600]">
                        Loyal
                      </span>
                    )}
                  </div>
                </div>

                {/* First order */}
                <div className="flex items-center gap-1 md:block">
                  <span className="md:hidden text-[#54311e] text-xs">First:</span>
                  <p className="text-[#9c8273] text-xs">{timeAgo(customer.firstOrder)}</p>
                </div>

                {/* Last active */}
                <div className="flex items-center gap-1 md:block">
                  <span className="md:hidden text-[#54311e] text-xs">Last:</span>
                  <p className="text-[#9c8273] text-xs">{timeAgo(customer.lastOrder)}</p>
                </div>

                {/* View button */}
                <div className="flex justify-end">
                  <button
                    onClick={() => setSelectedCustomer(customer)}
                    className="w-8 h-8 rounded-full bg-[#ff6a00] hover:bg-[#ff8c00] flex items-center justify-center text-white transition-colors shadow-md shadow-[#ff6a00]/20"
                  >
                    <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>visibility</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-[#54311e] text-xs">
            Page {page} of {totalPages}
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="p-2 rounded-lg bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] text-[#9c8273] hover:text-white hover:border-[rgba(255,120,30,0.2)] disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>chevron_left</span>
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="p-2 rounded-lg bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] text-[#9c8273] hover:text-white hover:border-[rgba(255,120,30,0.2)] disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>chevron_right</span>
            </button>
          </div>
        </div>
      )}

      {/* Customer detail modal */}
      {selectedCustomer && (
        <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4" onClick={() => setSelectedCustomer(null)}>
          <div
            className="bg-[#1a0e07] border border-[rgba(255,120,30,0.12)] rounded-2xl w-full max-w-lg p-6 space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <img
                  src={selectedCustomer.avatar}
                  alt={selectedCustomer.username}
                  className="w-16 h-16 rounded-2xl"
                  style={{ imageRendering: "pixelated" }}
                />
                <div>
                  <h2 className="text-xl font-black text-white font-[family-name:var(--font-plus-jakarta-sans)]">
                    {selectedCustomer.username}
                  </h2>
                  {selectedCustomer.email && (
                    <p className="text-[#9c8273] text-sm">{selectedCustomer.email}</p>
                  )}
                  {selectedCustomer.country && (
                    <p className="text-[#54311e] text-xs mt-0.5">{selectedCustomer.country}</p>
                  )}
                </div>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="p-2 rounded-lg text-[#54311e] hover:text-white hover:bg-[#1e1008] transition-all"
              >
                <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>close</span>
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.06)] rounded-xl p-4 text-center">
                <p className="text-[#54311e] text-[9px] font-bold uppercase tracking-widest">Total Spent</p>
                <p className="text-xl font-black text-[#ff8c00] mt-1 font-[family-name:var(--font-space-grotesk)]">
                  ${selectedCustomer.totalSpent.toFixed(2)}
                </p>
              </div>
              <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.06)] rounded-xl p-4 text-center">
                <p className="text-[#54311e] text-[9px] font-bold uppercase tracking-widest">Orders</p>
                <p className="text-xl font-black text-white mt-1 font-[family-name:var(--font-space-grotesk)]">
                  {selectedCustomer.orderCount}
                </p>
              </div>
              <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.06)] rounded-xl p-4 text-center">
                <p className="text-[#54311e] text-[9px] font-bold uppercase tracking-widest">Avg. Order</p>
                <p className="text-xl font-black text-white mt-1 font-[family-name:var(--font-space-grotesk)]">
                  ${(selectedCustomer.totalSpent / selectedCustomer.orderCount).toFixed(2)}
                </p>
              </div>
            </div>

            {/* Status breakdown */}
            <div>
              <p className="text-[#54311e] text-[10px] font-bold uppercase tracking-widest mb-2">Order Statuses</p>
              <div className="flex flex-wrap gap-2">
                {Object.entries(selectedCustomer.statuses).map(([status, count]) => (
                  <span
                    key={status}
                    className={`text-xs font-bold px-3 py-1 rounded-full ${
                      status === "completed"
                        ? "bg-[#10B981]/15 text-[#10B981]"
                        : status === "pending"
                        ? "bg-[#ffa600]/15 text-[#ffa600]"
                        : "bg-red-500/15 text-red-400"
                    }`}
                  >
                    {count}x {status}
                  </span>
                ))}
              </div>
            </div>

            {/* Timeline */}
            <div className="flex items-center gap-4 text-xs text-[#9c8273]">
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined" style={{ fontSize: "14px" }}>calendar_today</span>
                First: {new Date(selectedCustomer.firstOrder).toLocaleDateString()}
              </div>
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined" style={{ fontSize: "14px" }}>schedule</span>
                Last: {timeAgo(selectedCustomer.lastOrder)}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

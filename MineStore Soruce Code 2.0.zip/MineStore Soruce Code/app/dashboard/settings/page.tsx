"use client";

import React, { useEffect, useState } from "react";

interface VoteLink {
  name: string;
  url: string;
}

interface StoreConfig {
  serverIp: string;
  serverName: string;
  logoUrl: string;
  discordUrl: string;
  forumUrl: string;
  voteLinks: VoteLink[];
  socialLinks: Record<string, string>;
}

export default function SettingsPage() {
  const [config, setConfig] = useState<StoreConfig>({
    serverIp: "play.pika-network.net",
    serverName: "PikaNetwork",
    logoUrl: "/logo.png",
    discordUrl: "",
    forumUrl: "",
    voteLinks: [],
    socialLinks: {},
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  // Tebex Payment Gateway state
  const [tebexConfig, setTebexConfig] = useState({
    publicToken: "",
    secretKey: "",
    webhookSecret: "",
    sandbox: true,
    enabled: true,
  });
  const [tebexStatus, setTebexStatus] = useState<{
    connectionValid: boolean;
    error: string | null;
    testing: boolean;
    tested: boolean;
  }>({ connectionValid: false, error: null, testing: false, tested: false });
  const [copiedWebhook, setCopiedWebhook] = useState(false);

  useEffect(() => {
    Promise.all([
      fetch("/api/config").then((r) => r.json()).catch(() => null),
      fetch("/api/tebex/status").then((r) => r.json()).catch(() => null),
    ])
      .then(([configData, tebexData]) => {
        if (configData && !configData.error) {
          setConfig({
            serverIp: configData.serverIp || "",
            serverName: configData.serverName || "",
            logoUrl: configData.logoUrl || "",
            discordUrl: configData.discordUrl || "",
            forumUrl: configData.forumUrl || "",
            voteLinks: Array.isArray(configData.voteLinks) ? configData.voteLinks : [],
            socialLinks: configData.socialLinks || {},
          });
        }
        if (tebexData && tebexData.config) {
          setTebexConfig({
            publicToken: tebexData.config.publicToken || "",
            secretKey: tebexData.config.hasSecretKey ? "••••••••••••••••" : "",
            webhookSecret: tebexData.config.hasWebhookSecret ? "••••••••••••••••" : "",
            sandbox: tebexData.config.sandbox !== undefined ? tebexData.config.sandbox : true,
            enabled: tebexData.config.enabled !== undefined ? tebexData.config.enabled : true,
          });
          setTebexStatus({
            connectionValid: Boolean(tebexData.connectionValid),
            error: tebexData.error || null,
            testing: false,
            tested: true,
          });
        }
      })
      .finally(() => setLoading(false));
  }, []);

  const testTebexConnection = async () => {
    setTebexStatus((s) => ({ ...s, testing: true }));
    try {
      const res = await fetch("/api/tebex/status");
      const data = await res.json();
      setTebexStatus({
        connectionValid: Boolean(data.connectionValid),
        error: data.error || null,
        testing: false,
        tested: true,
      });
    } catch {
      setTebexStatus({
        connectionValid: false,
        error: "Network error testing Tebex endpoint",
        testing: false,
        tested: true,
      });
    }
  };

  const copyWebhookUrl = () => {
    if (typeof window !== "undefined") {
      const url = `${window.location.origin}/api/tebex/webhook`;
      navigator.clipboard.writeText(url);
      setCopiedWebhook(true);
      setTimeout(() => setCopiedWebhook(false), 2500);
    }
  };

  const handleSave = async () => {
    setError("");
    setSaving(true);
    setSaved(false);

    try {
      // 1. Save general config
      const res = await fetch("/api/config", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(config),
      });

      if (!res.ok) {
        const data = await res.json();
        setError(data.error || "Failed to save configuration");
        return;
      }

      // 2. Save Tebex config
      const tebexPayload: any = {
        publicToken: tebexConfig.publicToken.trim(),
        sandbox: tebexConfig.sandbox,
        enabled: tebexConfig.enabled,
      };
      // Only send secretKey / webhookSecret if changed from mask
      if (tebexConfig.secretKey && !tebexConfig.secretKey.includes("••••")) {
        tebexPayload.secretKey = tebexConfig.secretKey.trim();
      }
      if (tebexConfig.webhookSecret && !tebexConfig.webhookSecret.includes("••••")) {
        tebexPayload.webhookSecret = tebexConfig.webhookSecret.trim();
      }

      await fetch("/api/tebex/status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(tebexPayload),
      });

      // Refresh connection status
      await testTebexConnection();

      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const addVoteLink = () => {
    setConfig((c) => ({
      ...c,
      voteLinks: [...c.voteLinks, { name: "", url: "" }],
    }));
  };

  const removeVoteLink = (index: number) => {
    setConfig((c) => ({
      ...c,
      voteLinks: c.voteLinks.filter((_, i) => i !== index),
    }));
  };

  const updateVoteLink = (index: number, field: "name" | "url", value: string) => {
    setConfig((c) => ({
      ...c,
      voteLinks: c.voteLinks.map((link, i) =>
        i === index ? { ...link, [field]: value } : link
      ),
    }));
  };

  const updateSocial = (key: string, value: string) => {
    setConfig((c) => ({
      ...c,
      socialLinks: { ...c.socialLinks, [key]: value },
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <svg className="animate-spin h-8 w-8 text-[#ff6a00]" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
        </svg>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white font-[family-name:var(--font-plus-jakarta-sans)] tracking-tight">
            Settings
          </h1>
          <p className="text-[#9c8273] text-sm mt-1">Manage your store configuration</p>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] text-white font-bold text-sm hover:from-[#ff7a20] hover:to-[#ff9c20] transition-all shadow-lg shadow-[#ff6a00]/25 disabled:opacity-50 font-[family-name:var(--font-plus-jakarta-sans)]"
        >
          {saving ? (
            <>
              <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
              Saving...
            </>
          ) : saved ? (
            <>
              <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>check</span>
              Saved!
            </>
          ) : (
            <>
              <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>save</span>
              Save Changes
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center gap-3">
          <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>error</span>
          {error}
        </div>
      )}

      {/* Server settings */}
      <div className="bg-[#1e1008]/50 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-5">
        <h2 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)] flex items-center gap-2">
          <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "20px" }}>dns</span>
          Server
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Server Name</label>
            <input
              type="text"
              value={config.serverName}
              onChange={(e) => setConfig((c) => ({ ...c, serverName: e.target.value }))}
              className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Server IP</label>
            <input
              type="text"
              value={config.serverIp}
              onChange={(e) => setConfig((c) => ({ ...c, serverIp: e.target.value }))}
              className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Logo URL</label>
          <div className="flex items-center gap-4">
            <input
              type="text"
              value={config.logoUrl}
              onChange={(e) => setConfig((c) => ({ ...c, logoUrl: e.target.value }))}
              className="flex-1 px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
            />
            {config.logoUrl && (
              <div className="w-12 h-12 rounded-lg bg-[#0c0603] border border-[rgba(255,120,30,0.12)] overflow-hidden flex-shrink-0">
                <img src={config.logoUrl} alt="Logo" className="w-full h-full object-contain" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Links */}
      <div className="bg-[#1e1008]/50 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-5">
        <h2 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)] flex items-center gap-2">
          <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "20px" }}>link</span>
          Links
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Discord Invite URL</label>
            <input
              type="url"
              value={config.discordUrl}
              onChange={(e) => setConfig((c) => ({ ...c, discordUrl: e.target.value }))}
              placeholder="https://discord.gg/..."
              className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-[#c9a48f] mb-2">Forum URL</label>
            <input
              type="url"
              value={config.forumUrl}
              onChange={(e) => setConfig((c) => ({ ...c, forumUrl: e.target.value }))}
              placeholder="https://forums.example.com"
              className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
            />
          </div>
        </div>
      </div>

      {/* Social Links */}
      <div className="bg-[#1e1008]/50 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-5">
        <h2 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)] flex items-center gap-2">
          <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "20px" }}>share</span>
          Social Media
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {["twitter", "youtube", "instagram", "tiktok"].map((platform) => (
            <div key={platform}>
              <label className="block text-sm font-semibold text-[#c9a48f] mb-2 capitalize">{platform}</label>
              <input
                type="url"
                value={config.socialLinks[platform] || ""}
                onChange={(e) => updateSocial(platform, e.target.value)}
                placeholder={`https://${platform}.com/...`}
                className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
              />
            </div>
          ))}
        </div>
      </div>

      {/* Tebex Payment Gateway */}
      <div className="bg-[#1e1008]/50 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#ff6a00]/10 border border-[#ff6a00]/20 flex items-center justify-center text-[#ff6a00]">
              <span className="material-symbols-outlined" style={{ fontSize: "22px" }}>payments</span>
            </div>
            <div>
              <h2 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)] flex items-center gap-2">
                Tebex Payment Gateway
              </h2>
              <p className="text-xs text-[#9c8273]">
                Accept cards, PayPal, Paysafecard, and local methods via Tebex Headless Checkout.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {tebexStatus.connectionValid ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Live API Connected
              </span>
            ) : tebexConfig.sandbox ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                <span className="w-2 h-2 rounded-full bg-blue-400" />
                Sandbox / Test Mode
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Pending Setup
              </span>
            )}

            <button
              type="button"
              onClick={testTebexConnection}
              disabled={tebexStatus.testing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#140a05] text-[#ff6a00] hover:bg-[#ff6a00]/10 border border-[rgba(255,120,30,0.2)] text-xs font-bold transition-all disabled:opacity-50 cursor-pointer"
            >
              <span className={`material-symbols-outlined ${tebexStatus.testing ? "animate-spin" : ""}`} style={{ fontSize: "16px" }}>
                refresh
              </span>
              {tebexStatus.testing ? "Testing..." : "Test Connection"}
            </button>
          </div>
        </div>

        {/* Toggles */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-[rgba(255,120,30,0.06)]">
          <label className="flex items-center justify-between p-3.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] cursor-pointer hover:border-[rgba(255,120,30,0.2)] transition-colors">
            <div>
              <div className="text-sm font-semibold text-white">Enable Tebex Gateway</div>
              <div className="text-xs text-[#9c8273]">Process payments through Tebex checkout system</div>
            </div>
            <input
              type="checkbox"
              checked={tebexConfig.enabled}
              onChange={(e) => setTebexConfig((c) => ({ ...c, enabled: e.target.checked }))}
              className="w-5 h-5 accent-[#ff6a00] rounded cursor-pointer"
            />
          </label>

          <label className="flex items-center justify-between p-3.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] cursor-pointer hover:border-[rgba(255,120,30,0.2)] transition-colors">
            <div>
              <div className="text-sm font-semibold text-white">Sandbox / Simulation Mode</div>
              <div className="text-xs text-[#9c8273]">Instant test orders with automated RCON delivery</div>
            </div>
            <input
              type="checkbox"
              checked={tebexConfig.sandbox}
              onChange={(e) => setTebexConfig((c) => ({ ...c, sandbox: e.target.checked }))}
              className="w-5 h-5 accent-[#ff6a00] rounded cursor-pointer"
            />
          </label>
        </div>

        {/* API Credentials */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-[#c9a48f] mb-1.5">
              Tebex Public Webstore Token
            </label>
            <input
              type="text"
              value={tebexConfig.publicToken}
              onChange={(e) => setTebexConfig((c) => ({ ...c, publicToken: e.target.value }))}
              placeholder="e.g. 1234567-abcdef0123456789-abcdef"
              className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] font-mono text-xs transition-all"
            />
            <p className="text-xs text-[#735747] mt-1">
              Found in your Tebex Creator Panel under Webstore Integrations or Headless API.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-[#c9a48f] mb-1.5">
                Tebex Secret API Key (Optional)
              </label>
              <input
                type="password"
                value={tebexConfig.secretKey}
                onChange={(e) => setTebexConfig((c) => ({ ...c, secretKey: e.target.value }))}
                placeholder="Leave blank to keep existing key"
                className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] font-mono text-xs transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#c9a48f] mb-1.5">
                Webhook HMAC Secret (Optional)
              </label>
              <input
                type="password"
                value={tebexConfig.webhookSecret}
                onChange={(e) => setTebexConfig((c) => ({ ...c, webhookSecret: e.target.value }))}
                placeholder="Leave blank to keep existing secret"
                className="w-full px-4 py-3 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] font-mono text-xs transition-all"
              />
            </div>
          </div>
        </div>

        {/* Webhook Endpoint Info */}
        <div className="rounded-xl p-4 bg-[#0c0603]/80 border border-[rgba(255,120,30,0.12)] space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#c9a48f] uppercase tracking-wider flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "16px" }}>webhook</span>
              Tebex Webhook Endpoint URL
            </span>
            <span className="text-[11px] text-[#735747]">Events: payment.completed, validation.webhook</span>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={typeof window !== "undefined" ? `${window.location.origin}/api/tebex/webhook` : "/api/tebex/webhook"}
              className="flex-1 px-3 py-2 rounded-lg bg-[#140a05] border border-[rgba(255,120,30,0.15)] text-[#e2d5cd] font-mono text-xs select-all focus:outline-none"
            />
            <button
              type="button"
              onClick={copyWebhookUrl}
              className="px-3 py-2 rounded-lg bg-[#ff6a00]/10 hover:bg-[#ff6a00]/20 text-[#ff6a00] border border-[#ff6a00]/20 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer flex-shrink-0"
            >
              <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>
                {copiedWebhook ? "done" : "content_copy"}
              </span>
              {copiedWebhook ? "Copied!" : "Copy"}
            </button>
          </div>
        </div>
      </div>

      {/* Vote Links */}
      <div className="bg-[#1e1008]/50 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)] flex items-center gap-2">
            <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "20px" }}>how_to_vote</span>
            Vote Links
          </h2>
          <div className="flex items-center gap-2">
            <a
              href="/vote"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#140a05] text-[#9c8273] hover:text-white text-xs font-bold border border-[rgba(255,120,30,0.15)] transition-all"
            >
              <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>visibility</span>
              View Live Page
            </a>
            <button
              onClick={addVoteLink}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#ff6a00]/10 text-[#ff6a00] text-xs font-bold hover:bg-[#ff6a00]/20 transition-all cursor-pointer"
            >
              <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>add</span>
              Add Link
            </button>
          </div>
        </div>

        {config.voteLinks.length === 0 ? (
          <p className="text-[#54311e] text-sm">No vote links added yet.</p>
        ) : (
          <div className="space-y-3">
            {config.voteLinks.map((link, index) => (
              <div key={index} className="flex items-center gap-3">
                <input
                  type="text"
                  value={link.name}
                  onChange={(e) => updateVoteLink(index, "name", e.target.value)}
                  placeholder="Site name"
                  className="w-32 sm:w-40 px-3 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
                />
                <input
                  type="url"
                  value={link.url}
                  onChange={(e) => updateVoteLink(index, "url", e.target.value)}
                  placeholder="https://..."
                  className="flex-1 px-3 py-2.5 rounded-xl bg-[#0c0603] border border-[rgba(255,120,30,0.12)] text-white placeholder-[#54311e] focus:outline-none focus:border-[#ff6a00] transition-all text-sm"
                />
                <button
                  onClick={() => removeVoteLink(index)}
                  className="p-2 rounded-lg text-[#9c8273] hover:text-red-400 hover:bg-red-500/10 transition-all flex-shrink-0"
                >
                  <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>close</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom save */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={saving}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] text-white font-bold text-sm hover:from-[#ff7a20] hover:to-[#ff9c20] transition-all shadow-lg shadow-[#ff6a00]/25 disabled:opacity-50 font-[family-name:var(--font-plus-jakarta-sans)]"
        >
          <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>save</span>
          {saving ? "Saving..." : "Save All Changes"}
        </button>
      </div>
    </div>
  );
}

"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";

export default function ConsolePage() {
  const [logs, setLogs] = useState<string[]>([]);
  const [command, setCommand] = useState("");
  const [commandHistory, setCommandHistory] = useState<Array<{
    command: string;
    executedBy: string;
    timestamp: string;
  }>>([]);
  const [loading, setLoading] = useState(true);
  const [autoScroll, setAutoScroll] = useState(true);
  const [filter, setFilter] = useState("");
  const [sending, setSending] = useState(false);
  const logEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [cmdHistoryIdx, setCmdHistoryIdx] = useState(-1);

  const fetchLogs = useCallback(async () => {
    try {
      const res = await fetch("/api/bridge/console?limit=500");
      const data = await res.json();
      if (data.success) {
        setLogs(data.logs || []);
        setCommandHistory(data.commandHistory || []);
      }
    } catch (err) {
      console.error("Failed to fetch logs:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchLogs();
    const interval = setInterval(fetchLogs, 3000);
    return () => clearInterval(interval);
  }, [fetchLogs]);

  useEffect(() => {
    if (autoScroll && logEndRef.current) {
      logEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [logs, autoScroll]);

  const handleSendCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim() || sending) return;

    setSending(true);
    try {
      const res = await fetch("/api/bridge/console", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "execute",
          command: command.trim(),
          executedBy: "Dashboard",
        }),
      });
      const data = await res.json();
      if (data.success) {
        setCommand("");
        setCmdHistoryIdx(-1);
        // Immediately show it in local state
        setCommandHistory(prev => [
          { command: command.trim(), executedBy: "Dashboard", timestamp: new Date().toISOString() },
          ...prev,
        ]);
      }
    } catch (err) {
      console.error("Failed to send command:", err);
    } finally {
      setSending(false);
      inputRef.current?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Navigate command history with up/down arrows
    const cmds = commandHistory.map(c => c.command);
    if (e.key === "ArrowUp") {
      e.preventDefault();
      const newIdx = Math.min(cmdHistoryIdx + 1, cmds.length - 1);
      setCmdHistoryIdx(newIdx);
      if (cmds[newIdx]) setCommand(cmds[newIdx]);
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      const newIdx = cmdHistoryIdx - 1;
      if (newIdx < 0) {
        setCmdHistoryIdx(-1);
        setCommand("");
      } else {
        setCmdHistoryIdx(newIdx);
        if (cmds[newIdx]) setCommand(cmds[newIdx]);
      }
    }
  };

  const getLogLineColor = (line: string) => {
    if (line.includes("[ERROR]") || line.includes("[SEVERE]")) return "text-red-400";
    if (line.includes("[WARN]") || line.includes("[WARNING]")) return "text-yellow-400";
    if (line.includes("[INFO]")) return "text-[#c9a48f]";
    if (line.includes("[DEBUG]")) return "text-blue-400";
    return "text-[#9c8273]";
  };

  const filteredLogs = filter
    ? logs.filter((line) => line.toLowerCase().includes(filter.toLowerCase()))
    : logs;

  return (
    <div className="space-y-4 h-full flex flex-col">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 flex-shrink-0">
        <div>
          <h1 className="text-2xl font-bold text-white font-[family-name:var(--font-plus-jakarta-sans)]">
            Live Console
          </h1>
          <p className="text-sm text-[#9c8273] mt-1">
            Stream server console output and execute commands remotely
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${logs.length > 0 ? "bg-emerald-500 animate-pulse" : "bg-[#54311e]"}`} />
            <span className="text-xs text-[#9c8273]">{logs.length} lines</span>
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={autoScroll}
              onChange={(e) => setAutoScroll(e.target.checked)}
              className="accent-[#ff6a00] w-4 h-4"
            />
            <span className="text-sm text-[#9c8273]">Auto-scroll</span>
          </label>
        </div>
      </div>

      {/* Filter bar */}
      <div className="relative flex-shrink-0">
        <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-[#54311e]" style={{ fontSize: "18px" }}>
          search
        </span>
        <input
          type="text"
          placeholder="Filter logs..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#110a04] border border-[rgba(255,120,30,0.1)] text-white text-sm placeholder:text-[#54311e] focus:outline-none focus:border-[#ff6a00]/30 transition-colors"
        />
      </div>

      {/* Console Output */}
      <div className="flex-1 min-h-0 rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#050301] overflow-hidden flex flex-col">
        <div className="flex items-center gap-2 px-4 py-2 border-b border-[rgba(255,120,30,0.06)] bg-[#0a0503]">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500/60" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/60" />
          </div>
          <span className="text-xs text-[#54311e] font-mono ml-2">server console</span>
        </div>

        <div className="flex-1 overflow-y-auto p-4 font-mono text-xs leading-5 space-y-0">
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin w-6 h-6 border-2 border-[#ff6a00] border-t-transparent rounded-full" />
            </div>
          ) : filteredLogs.length === 0 ? (
            <div className="text-center py-20">
              <span className="material-symbols-outlined text-[#54311e] mb-2 block" style={{ fontSize: "32px" }}>
                terminal
              </span>
              <p className="text-[#54311e]">
                {filter ? "No matching log lines" : "No console output yet. Connect a server to start streaming."}
              </p>
            </div>
          ) : (
            filteredLogs.map((line, idx) => (
              <div
                key={idx}
                className={`hover:bg-[rgba(255,120,30,0.03)] px-2 py-0.5 rounded ${getLogLineColor(line)}`}
              >
                {line}
              </div>
            ))
          )}
          <div ref={logEndRef} />
        </div>

        {/* Command Input */}
        <form
          onSubmit={handleSendCommand}
          className="border-t border-[rgba(255,120,30,0.06)] bg-[#0a0503] p-3 flex items-center gap-2"
        >
          <span className="text-[#ff6a00] font-mono text-sm font-bold">&gt;</span>
          <input
            ref={inputRef}
            type="text"
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Enter command..."
            className="flex-1 bg-transparent text-white font-mono text-sm placeholder:text-[#54311e] focus:outline-none"
            disabled={sending}
          />
          <button
            type="submit"
            disabled={!command.trim() || sending}
            className="px-4 py-1.5 rounded-lg bg-[#ff6a00] text-white text-sm font-medium hover:bg-[#ff8c00] disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center gap-1.5"
          >
            {sending ? (
              <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
            ) : (
              <>
                <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>send</span>
                Send
              </>
            )}
          </button>
        </form>
      </div>

      {/* Recent Commands */}
      {commandHistory.length > 0 && (
        <div className="rounded-2xl border border-[rgba(255,120,30,0.1)] bg-[#110a04] p-4 flex-shrink-0">
          <h3 className="text-sm font-semibold text-[#c9a48f] mb-3 flex items-center gap-2">
            <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>history</span>
            Recent Commands
          </h3>
          <div className="space-y-1 max-h-32 overflow-y-auto">
            {commandHistory.slice(0, 10).map((cmd, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between text-xs py-1.5 px-2 rounded-lg hover:bg-[#0a0503] cursor-pointer transition-colors"
                onClick={() => {
                  setCommand(cmd.command);
                  inputRef.current?.focus();
                }}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-[#ff6a00] font-mono">&gt;</span>
                  <span className="text-white font-mono truncate">{cmd.command}</span>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0 ml-3">
                  <span className="text-[#54311e]">{cmd.executedBy}</span>
                  <span className="text-[#54311e]">
                    {new Date(cmd.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

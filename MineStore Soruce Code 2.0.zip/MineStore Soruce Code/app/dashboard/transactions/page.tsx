"use client";

import React, { useEffect, useState, useCallback } from "react";

interface TransactionItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  thumbnail?: string;
}

interface Transaction {
  id: string;
  invoiceId: string;
  username: string;
  avatar: string;
  email: string;
  total: number;
  currency: string;
  status: string;
  items: TransactionItem[];
  itemCount: number;
  createdAt: string;
  deliveryStatus: string;
}

interface Summary {
  totalRevenue: number;
  totalOrders: number;
  completedCount: number;
  pendingCount: number;
  failedCount: number;
}

export default function TransactionsPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [summary, setSummary] = useState<Summary>({
    totalRevenue: 0,
    totalOrders: 0,
    completedCount: 0,
    pendingCount: 0,
    failedCount: 0,
  });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);

  const fetchTransactions = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: "15" });
      if (search) params.set("search", search);
      if (statusFilter) params.set("status", statusFilter);
      const res = await fetch(`/api/dashboard/transactions?${params}`);
      const data = await res.json();
      setTransactions(data.transactions || []);
      setTotalPages(data.totalPages || 1);
      setTotal(data.total || 0);
      if (data.summary) setSummary(data.summary);
    } catch (err) {
      console.error("Failed to fetch transactions:", err);
    } finally {
      setLoading(false);
    }
  }, [page, search, statusFilter]);

  useEffect(() => {
    fetchTransactions();
  }, [fetchTransactions]);

  useEffect(() => {
    setPage(1);
  }, [search, statusFilter]);

  function formatDate(dateStr: string) {
    const d = new Date(dateStr);
    return d.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  }

  function formatTime(dateStr: string) {
    const d = new Date(dateStr);
    return d.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  const statusColors: Record<string, { bg: string; text: string }> = {
    completed: { bg: "bg-[#10B981]/15", text: "text-[#10B981]" },
    pending: { bg: "bg-[#ffa600]/15", text: "text-[#ffa600]" },
    failed: { bg: "bg-red-500/15", text: "text-red-400" },
    refunded: { bg: "bg-blue-500/15", text: "text-blue-400" },
  };

  if (loading && transactions.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-3">
          <svg className="animate-spin h-8 w-8 text-[#ff6a00]" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
          <span className="text-[#9c8273] text-sm">Loading transactions...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5 max-w-[1400px]">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black text-white font-[family-name:var(--font-plus-jakarta-sans)] tracking-tight">
          Transactions
        </h1>
        <p className="text-[#9c8273] text-sm mt-1">
          {total} transaction{total !== 1 ? "s" : ""} total
        </p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#ff6a00]/10 flex items-center justify-center">
              <span className="material-symbols-outlined text-[#ff6a00]" style={{ fontSize: "22px", fontVariationSettings: "'FILL' 1" }}>payments</span>
            </div>
            <div>
              <p className="text-[#54311e] text-[10px] font-semibold uppercase tracking-widest">Revenue</p>
              <p className="text-xl font-black text-white font-[family-name:var(--font-space-grotesk)]">
                ${summary.totalRevenue.toFixed(2)}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#10B981]/10 flex items-center justify-center">
              <span className="material-symbols-outlined text-[#10B981]" style={{ fontSize: "22px", fontVariationSettings: "'FILL' 1" }}>check_circle</span>
            </div>
            <div>
              <p className="text-[#54311e] text-[10px] font-semibold uppercase tracking-widest">Completed</p>
              <p className="text-xl font-black text-white font-[family-name:var(--font-space-grotesk)]">
                {summary.completedCount}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#ffa600]/10 flex items-center justify-center">
              <span className="material-symbols-outlined text-[#ffa600]" style={{ fontSize: "22px", fontVariationSettings: "'FILL' 1" }}>pending</span>
            </div>
            <div>
              <p className="text-[#54311e] text-[10px] font-semibold uppercase tracking-widest">Pending</p>
              <p className="text-xl font-black text-white font-[family-name:var(--font-space-grotesk)]">
                {summary.pendingCount}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
              <span className="material-symbols-outlined text-red-400" style={{ fontSize: "22px", fontVariationSettings: "'FILL' 1" }}>error</span>
            </div>
            <div>
              <p className="text-[#54311e] text-[10px] font-semibold uppercase tracking-widest">Failed</p>
              <p className="text-xl font-black text-white font-[family-name:var(--font-space-grotesk)]">
                {summary.failedCount}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-md">
          <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-[#54311e]" style={{ fontSize: "20px" }}>search</span>
          <input
            type="text"
            placeholder="Search by username, invoice, or email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-[#1e1008]/60 border border-[rgba(255,120,30,0.1)] rounded-xl pl-11 pr-4 py-2.5 text-sm text-white placeholder:text-[#54311e] focus:outline-none focus:border-[#ff6a00]/40 transition-colors"
          />
        </div>
        <div className="flex gap-2">
          {["", "completed", "pending", "failed"].map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all border ${
                statusFilter === s
                  ? "bg-[#ff6a00]/15 border-[#ff6a00]/30 text-[#ff8c00]"
                  : "bg-[#1e1008]/40 border-[rgba(255,120,30,0.08)] text-[#54311e] hover:text-[#9c8273] hover:border-[rgba(255,120,30,0.15)]"
              }`}
            >
              {s || "All"}
            </button>
          ))}
        </div>
      </div>

      {/* Transactions table */}
      <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl overflow-hidden">
        {/* Header */}
        <div className="hidden lg:grid grid-cols-[80px_1fr_120px_100px_120px_120px_50px] items-center px-5 py-3 text-[10px] font-bold text-[#54311e] uppercase tracking-widest border-b border-[rgba(255,120,30,0.04)]">
          <span>Invoice</span>
          <span>Customer</span>
          <span>Amount</span>
          <span>Items</span>
          <span>Status</span>
          <span>Date</span>
          <span className="text-right">View</span>
        </div>

        {/* Rows */}
        <div className="divide-y divide-[rgba(255,120,30,0.04)]">
          {transactions.length === 0 ? (
            <div className="p-12 text-center">
              <span className="material-symbols-outlined text-[#54311e] mb-3 block" style={{ fontSize: "48px" }}>receipt_long</span>
              <p className="text-[#9c8273] text-sm">No transactions found</p>
            </div>
          ) : (
            transactions.map((tx) => {
              const sc = statusColors[tx.status] || statusColors.failed;
              return (
                <div
                  key={tx.id}
                  className="grid grid-cols-1 lg:grid-cols-[80px_1fr_120px_100px_120px_120px_50px] items-center px-5 py-4 hover:bg-[rgba(255,120,30,0.03)] transition-colors gap-2 lg:gap-0"
                >
                  {/* Invoice */}
                  <p className="text-[#54311e] text-xs font-[family-name:var(--font-space-grotesk)] truncate">
                    <span className="lg:hidden text-[#54311e] mr-1">#</span>
                    {tx.invoiceId.slice(-6).toUpperCase()}
                  </p>

                  {/* Customer */}
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={tx.avatar}
                      alt={tx.username}
                      className="w-9 h-9 rounded-lg flex-shrink-0"
                      style={{ imageRendering: "pixelated" }}
                    />
                    <div className="min-w-0">
                      <p className="text-white text-sm font-medium truncate">{tx.username}</p>
                      {tx.email && (
                        <p className="text-[#54311e] text-[11px] truncate">{tx.email}</p>
                      )}
                    </div>
                  </div>

                  {/* Amount */}
                  <div className="flex items-center gap-1 lg:block">
                    <span className="lg:hidden text-[#54311e] text-xs">Amount:</span>
                    <p className="text-white text-sm font-bold font-[family-name:var(--font-space-grotesk)]">
                      ${tx.total.toFixed(2)}
                      <span className="text-[#54311e] text-[10px] ml-1">{tx.currency}</span>
                    </p>
                  </div>

                  {/* Items */}
                  <div className="flex items-center gap-1 lg:block">
                    <span className="lg:hidden text-[#54311e] text-xs">Items:</span>
                    <p className="text-[#9c8273] text-sm font-[family-name:var(--font-space-grotesk)]">
                      {tx.itemCount} item{tx.itemCount !== 1 ? "s" : ""}
                    </p>
                  </div>

                  {/* Status */}
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-full ${sc.bg} ${sc.text}`}>
                      {tx.status}
                    </span>
                    {tx.deliveryStatus === "delivered" && tx.status === "completed" && (
                      <span className="material-symbols-outlined text-[#10B981]" style={{ fontSize: "14px", fontVariationSettings: "'FILL' 1" }}>
                        local_shipping
                      </span>
                    )}
                  </div>

                  {/* Date */}
                  <div className="flex items-center gap-1 lg:block">
                    <span className="lg:hidden text-[#54311e] text-xs">Date:</span>
                    <div>
                      <p className="text-[#9c8273] text-xs">{formatDate(tx.createdAt)}</p>
                      <p className="text-[#54311e] text-[10px]">{formatTime(tx.createdAt)}</p>
                    </div>
                  </div>

                  {/* View */}
                  <div className="flex justify-end">
                    <button
                      onClick={() => setSelectedTx(tx)}
                      className="w-8 h-8 rounded-full bg-[#ff6a00] hover:bg-[#ff8c00] flex items-center justify-center text-white transition-colors shadow-md shadow-[#ff6a00]/20"
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>visibility</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-[#54311e] text-xs">
            Page {page} of {totalPages} · {total} total
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="p-2 rounded-lg bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] text-[#9c8273] hover:text-white hover:border-[rgba(255,120,30,0.2)] disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>chevron_left</span>
            </button>
            {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {
              const p = i + 1;
              return (
                <button
                  key={p}
                  onClick={() => setPage(p)}
                  className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${
                    page === p
                      ? "bg-[#ff6a00] text-white shadow-md shadow-[#ff6a00]/25"
                      : "bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] text-[#54311e] hover:text-white"
                  }`}
                >
                  {p}
                </button>
              );
            })}
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="p-2 rounded-lg bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] text-[#9c8273] hover:text-white hover:border-[rgba(255,120,30,0.2)] disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>chevron_right</span>
            </button>
          </div>
        </div>
      )}

      {/* Transaction detail modal */}
      {selectedTx && (
        <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4" onClick={() => setSelectedTx(null)}>
          <div
            className="bg-[#1a0e07] border border-[rgba(255,120,30,0.12)] rounded-2xl w-full max-w-lg p-6 space-y-5 max-h-[85vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-xl font-black text-white font-[family-name:var(--font-plus-jakarta-sans)]">
                  Transaction Details
                </h2>
                <p className="text-[#54311e] text-xs mt-1 font-[family-name:var(--font-space-grotesk)]">
                  Invoice: {selectedTx.invoiceId}
                </p>
              </div>
              <button
                onClick={() => setSelectedTx(null)}
                className="p-2 rounded-lg text-[#54311e] hover:text-white hover:bg-[#1e1008] transition-all"
              >
                <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>close</span>
              </button>
            </div>

            {/* Customer info */}
            <div className="flex items-center gap-4 bg-[#1e1008]/60 border border-[rgba(255,120,30,0.06)] rounded-xl p-4">
              <img
                src={selectedTx.avatar}
                alt={selectedTx.username}
                className="w-14 h-14 rounded-xl"
                style={{ imageRendering: "pixelated" }}
              />
              <div>
                <p className="text-white font-bold text-lg">{selectedTx.username}</p>
                {selectedTx.email && <p className="text-[#9c8273] text-sm">{selectedTx.email}</p>}
                <p className="text-[#54311e] text-xs mt-1">
                  {formatDate(selectedTx.createdAt)} at {formatTime(selectedTx.createdAt)}
                </p>
              </div>
            </div>

            {/* Status + Total */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.06)] rounded-xl p-4 text-center">
                <p className="text-[#54311e] text-[9px] font-bold uppercase tracking-widest">Status</p>
                <span
                  className={`inline-block mt-2 text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full ${
                    (statusColors[selectedTx.status] || statusColors.failed).bg
                  } ${(statusColors[selectedTx.status] || statusColors.failed).text}`}
                >
                  {selectedTx.status}
                </span>
              </div>
              <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.06)] rounded-xl p-4 text-center">
                <p className="text-[#54311e] text-[9px] font-bold uppercase tracking-widest">Total</p>
                <p className="text-2xl font-black text-[#ff8c00] mt-1 font-[family-name:var(--font-space-grotesk)]">
                  ${selectedTx.total.toFixed(2)}
                </p>
              </div>
            </div>

            {/* Items */}
            {selectedTx.items && selectedTx.items.length > 0 && (
              <div>
                <p className="text-[#54311e] text-[10px] font-bold uppercase tracking-widest mb-3">
                  Items ({selectedTx.items.length})
                </p>
                <div className="space-y-2">
                  {selectedTx.items.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between bg-[#1e1008]/40 border border-[rgba(255,120,30,0.04)] rounded-xl p-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {item.thumbnail ? (
                          <img src={item.thumbnail} alt={item.productName} className="w-8 h-8 rounded-lg object-cover flex-shrink-0" />
                        ) : (
                          <div className="w-8 h-8 rounded-lg bg-[#0c0603] flex items-center justify-center flex-shrink-0">
                            <span className="material-symbols-outlined text-[#54311e]" style={{ fontSize: "16px" }}>inventory_2</span>
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="text-white text-sm font-medium truncate">{item.productName}</p>
                          <p className="text-[#54311e] text-[10px]">Qty: {item.quantity}</p>
                        </div>
                      </div>
                      <p className="text-[#ff8c00] text-sm font-bold font-[family-name:var(--font-space-grotesk)] flex-shrink-0">
                        ${item.price.toFixed(2)}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Delivery status */}
            <div className="flex items-center gap-2 text-xs">
              <span
                className={`material-symbols-outlined ${
                  selectedTx.deliveryStatus === "delivered" ? "text-[#10B981]" : "text-[#ffa600]"
                }`}
                style={{ fontSize: "16px", fontVariationSettings: "'FILL' 1" }}
              >
                {selectedTx.deliveryStatus === "delivered" ? "check_circle" : "pending"}
              </span>
              <span className="text-[#9c8273]">
                Delivery: <span className="text-white font-medium capitalize">{selectedTx.deliveryStatus}</span>
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

"use client";

import React, { useEffect, useState, useMemo } from "react";

/* ─────────────── types ─────────────── */
interface DashboardStats {
  visitors: { total: number; daily: number[]; change: number };
  totalSales: { revenue: number; currency: string };
  monthlySales: { revenue: number; change: number; monthName: string };
  todaySales: { revenue: number; currency: string };
  monthlyBreakdown: { month: string; revenue: number }[];
  recentPayments: {
    id: number;
    orderId: string;
    username: string;
    avatar: string;
    price: number;
    currency: string;
    status: string;
    createdAt: string;
  }[];
  totalProducts: number;
  totalCategories: number;
  totalOrders: number;
}

/* ─────────────── helpers ─────────────── */
function fmt(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(2)}k`;
  return n.toFixed(2);
}

/* ─────────────── mini bar chart ─────────────── */
function MiniBarChart({ data, color = "#ff6a00" }: { data: number[]; color?: string }) {
  const max = Math.max(...data, 1);
  return (
    <div className="flex items-end gap-[3px] h-12">
      {data.map((v, i) => (
        <div
          key={i}
          className="w-[6px] rounded-sm transition-all duration-500"
          style={{
            height: `${Math.max((v / max) * 100, 8)}%`,
            backgroundColor: color,
            opacity: v === 0 ? 0.25 : 0.6 + (v / max) * 0.4,
          }}
        />
      ))}
    </div>
  );
}

/* ─────────────── sparkline chart ─────────────── */
function Sparkline({ data, color = "#10B981" }: { data: number[]; color?: string }) {
  const max = Math.max(...data, 1);
  const min = Math.min(...data);
  const w = 120;
  const h = 40;
  const pad = 2;

  const points = data.map((v, i) => {
    const x = pad + (i / (data.length - 1)) * (w - pad * 2);
    const y = h - pad - ((v - min) / (max - min || 1)) * (h - pad * 2);
    return `${x},${y}`;
  });

  const pathD = `M${points.join(" L")}`;
  const areaD = `${pathD} L${w - pad},${h} L${pad},${h} Z`;

  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="overflow-visible">
      <defs>
        <linearGradient id="sparkFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={areaD} fill="url(#sparkFill)" />
      <path d={pathD} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ─────────────── income line chart ─────────────── */
function IncomeChart({ data }: { data: { month: string; revenue: number }[] }) {
  const max = Math.max(...data.map((d) => d.revenue), 1);
  const roundedMax = Math.ceil(max / 500) * 500 || 1000;
  const gridLines = 5;
  const w = 500;
  const h = 200;
  const padLeft = 60;
  const padRight = 20;
  const padTop = 10;
  const padBottom = 30;

  const chartW = w - padLeft - padRight;
  const chartH = h - padTop - padBottom;

  const points = data.map((d, i) => {
    const x = padLeft + (i / (data.length - 1)) * chartW;
    const y = padTop + chartH - (d.revenue / roundedMax) * chartH;
    return { x, y, ...d };
  });

  const pathD = `M${points.map((p) => `${p.x},${p.y}`).join(" L")}`;
  const areaD = `${pathD} L${points[points.length - 1].x},${padTop + chartH} L${points[0].x},${padTop + chartH} Z`;

  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} className="overflow-visible">
      <defs>
        <linearGradient id="incomeGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ff6a00" stopOpacity="0.15" />
          <stop offset="100%" stopColor="#ff6a00" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* Grid lines */}
      {Array.from({ length: gridLines + 1 }).map((_, i) => {
        const y = padTop + (i / gridLines) * chartH;
        const val = roundedMax - (i / gridLines) * roundedMax;
        return (
          <g key={i}>
            <line
              x1={padLeft}
              y1={y}
              x2={w - padRight}
              y2={y}
              stroke="rgba(255,120,30,0.06)"
              strokeWidth="1"
            />
            <text
              x={padLeft - 8}
              y={y + 4}
              textAnchor="end"
              fill="#54311e"
              fontSize="10"
              fontFamily="var(--font-space-grotesk), monospace"
            >
              {fmt(val)} USD
            </text>
          </g>
        );
      })}

      {/* Month labels */}
      {points.map((p, i) => (
        <text
          key={i}
          x={p.x}
          y={h - 6}
          textAnchor="middle"
          fill="#54311e"
          fontSize="10"
          fontFamily="var(--font-space-grotesk), monospace"
        >
          {p.month}
        </text>
      ))}

      {/* Area fill */}
      <path d={areaD} fill="url(#incomeGrad)" />

      {/* Line */}
      <path
        d={pathD}
        fill="none"
        stroke="#ff6a00"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Data dots */}
      {points.map((p, i) => (
        <circle
          key={i}
          cx={p.x}
          cy={p.y}
          r="3.5"
          fill="#0c0603"
          stroke="#ff6a00"
          strokeWidth="2"
        />
      ))}
    </svg>
  );
}

/* ─────────────── main page component ─────────────── */
export default function DashboardOverview() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/dashboard/stats")
      .then((r) => r.json())
      .then((data) => setStats(data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  // Generate sparkline data from monthly breakdown
  const sparklineData = useMemo(() => {
    if (!stats?.monthlyBreakdown) return [0, 1, 2, 3, 2, 4, 3];
    return stats.monthlyBreakdown.map((m) => m.revenue);
  }, [stats]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-3">
          <svg className="animate-spin h-8 w-8 text-[#ff6a00]" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
          <span className="text-[#9c8273] text-sm">Loading dashboard...</span>
        </div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="flex items-center justify-center h-64 text-[#9c8273]">
        Failed to load dashboard data.
      </div>
    );
  }

  return (
    <div className="space-y-5 max-w-[1400px]">
      {/* ──── Page title ──── */}
      <h1 className="text-xl font-bold text-white font-[family-name:var(--font-plus-jakarta-sans)] tracking-tight">
        Home
      </h1>

      {/* ──── Top stat cards ──── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* Store Visitors */}
        <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-5 hover:border-[rgba(255,120,30,0.2)] transition-all duration-300">
          <div className="flex items-start justify-between mb-4">
            <p className="text-[#9c8273] text-xs font-semibold uppercase tracking-wider">Store Visitors</p>
            <span className="text-[#54311e] text-[10px] font-medium px-2 py-0.5 rounded-full border border-[rgba(255,120,30,0.1)]">
              This Week
            </span>
          </div>
          <div className="flex items-end justify-between gap-3">
            <div>
              <p className="text-3xl font-black text-white font-[family-name:var(--font-space-grotesk)]">
                {stats.visitors.total.toLocaleString()}
              </p>
              <p className={`text-xs mt-1 flex items-center gap-1 ${stats.visitors.change >= 0 ? "text-[#10B981]" : "text-red-400"}`}>
                <span className="material-symbols-outlined" style={{ fontSize: "14px" }}>
                  {stats.visitors.change >= 0 ? "trending_up" : "trending_down"}
                </span>
                {Math.abs(stats.visitors.change).toFixed(2)}%
              </p>
            </div>
            <MiniBarChart data={stats.visitors.daily} />
          </div>
          <div className="flex justify-between mt-2">
            {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
              <span key={i} className="text-[8px] text-[#54311e] font-medium w-[6px] text-center">
                {d}
              </span>
            ))}
          </div>
        </div>

        {/* Total in Sales */}
        <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-5 hover:border-[rgba(255,120,30,0.2)] transition-all duration-300 flex flex-col items-center justify-center text-center">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#10B981]/20 to-[#10B981]/5 flex items-center justify-center mb-3">
            <span className="material-symbols-outlined text-[#10B981]" style={{ fontSize: "24px", fontVariationSettings: "'FILL' 1" }}>
              monetization_on
            </span>
          </div>
          <p className="text-[#9c8273] text-xs font-semibold uppercase tracking-wider">Total in Sales</p>
          <p className="text-2xl font-black text-white mt-1 font-[family-name:var(--font-space-grotesk)]">
            {fmt(stats.totalSales.revenue)} {stats.totalSales.currency}
          </p>
          <p className="text-[10px] text-[#54311e] mt-1.5 flex items-center gap-1">
            <span className="material-symbols-outlined" style={{ fontSize: "12px" }}>schedule</span>
            All Time Sales
          </p>
        </div>

        {/* Monthly Sales */}
        <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-5 hover:border-[rgba(255,120,30,0.2)] transition-all duration-300">
          <p className="text-[#9c8273] text-xs font-semibold uppercase tracking-wider mb-2">
            {stats.monthlySales.monthName}&apos;s Sales
          </p>
          <div className="flex items-center gap-3 mb-3">
            <p className="text-2xl font-black text-white font-[family-name:var(--font-space-grotesk)]">
              {fmt(stats.monthlySales.revenue)} USD
            </p>
            <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${stats.monthlySales.change >= 0 ? "bg-[#10B981]/15 text-[#10B981]" : "bg-red-500/15 text-red-400"}`}>
              {stats.monthlySales.change >= 0 ? "↑" : "↓"} {Math.abs(stats.monthlySales.change).toFixed(2)}%
            </span>
          </div>
          <Sparkline data={sparklineData} color="#10B981" />
        </div>

        {/* Today Sales */}
        <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-5 hover:border-[rgba(255,120,30,0.2)] transition-all duration-300 flex flex-col items-center justify-center text-center">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#ffa600]/20 to-[#ffa600]/5 flex items-center justify-center mb-3">
            <span className="material-symbols-outlined text-[#ffa600]" style={{ fontSize: "24px", fontVariationSettings: "'FILL' 1" }}>
              chat_bubble
            </span>
          </div>
          <p className="text-[#9c8273] text-xs font-semibold uppercase tracking-wider">Today Sales</p>
          <p className="text-2xl font-black text-white mt-1 font-[family-name:var(--font-space-grotesk)]">
            {fmt(stats.todaySales.revenue)} {stats.todaySales.currency}
          </p>
          <p className="text-[10px] text-[#54311e] mt-1.5 flex items-center gap-1">
            <span className="material-symbols-outlined" style={{ fontSize: "12px" }}>today</span>
            Today
          </p>
        </div>
      </div>

      {/* ──── Middle row: Welcome + Recent Payments ──── */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Welcome + Total Income stacked */}
        <div className="space-y-4">
          {/* Welcome Card */}
          <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-6 flex items-start gap-5">
            <div className="flex-shrink-0 w-16 h-16 rounded-xl bg-gradient-to-br from-[#ffa600]/30 to-[#ff6a00]/10 flex items-center justify-center">
              <span className="material-symbols-outlined text-[#ffa600]" style={{ fontSize: "36px", fontVariationSettings: "'FILL' 1" }}>
                warning
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-white font-bold text-lg font-[family-name:var(--font-plus-jakarta-sans)]">
                Welcome back 👋
              </h2>
              <p className="text-[#9c8273] text-sm mt-1 leading-relaxed">
                Your store is running smoothly. You have <span className="text-white font-semibold">{stats.totalProducts} products</span> across <span className="text-white font-semibold">{stats.totalCategories} categories</span> with <span className="text-white font-semibold">{stats.totalOrders} total orders</span>. 🤗
              </p>
              <button className="mt-4 inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] text-white font-bold text-sm hover:from-[#ff7a20] hover:to-[#ff9c20] transition-all shadow-lg shadow-[#ff6a00]/25 hover:shadow-[#ff6a00]/40 font-[family-name:var(--font-plus-jakarta-sans)]">
                <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>download</span>
                View Full Report
              </button>
            </div>
          </div>

          {/* Total Income Chart */}
          <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)]">Total Income</h3>
                <p className="text-[#54311e] text-xs mt-0.5">Yearly report overview</p>
              </div>
            </div>
            <IncomeChart data={stats.monthlyBreakdown} />
          </div>
        </div>

        {/* Recent Payments */}
        <div className="bg-[#1e1008]/60 border border-[rgba(255,120,30,0.08)] rounded-2xl overflow-hidden">
          <div className="flex items-center justify-between p-5 border-b border-[rgba(255,120,30,0.06)]">
            <h3 className="text-white font-bold font-[family-name:var(--font-plus-jakarta-sans)]">
              Recent Payments
            </h3>
            <button className="p-1.5 rounded-lg text-[#54311e] hover:text-white hover:bg-[#1e1008] transition-all">
              <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>more_vert</span>
            </button>
          </div>

          {/* Table header */}
          <div className="grid grid-cols-[60px_1fr_100px_110px_50px] items-center px-5 py-3 text-[10px] font-bold text-[#54311e] uppercase tracking-widest border-b border-[rgba(255,120,30,0.04)]">
            <span>#</span>
            <span>Username</span>
            <span>Price</span>
            <span>Status</span>
            <span className="text-right">View</span>
          </div>

          {/* Table rows */}
          <div className="divide-y divide-[rgba(255,120,30,0.04)]">
            {stats.recentPayments.length === 0 ? (
              <div className="p-10 text-center text-[#54311e] text-sm">
                No payments yet
              </div>
            ) : (
              stats.recentPayments.map((payment) => (
                <div
                  key={payment.orderId}
                  className="grid grid-cols-[60px_1fr_100px_110px_50px] items-center px-5 py-3 hover:bg-[rgba(255,120,30,0.03)] transition-colors"
                >
                  <span className="text-[#54311e] text-sm font-[family-name:var(--font-space-grotesk)]">
                    {payment.id}
                  </span>
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={payment.avatar}
                      alt={payment.username}
                      className="w-8 h-8 rounded-lg flex-shrink-0"
                      style={{ imageRendering: "pixelated" }}
                    />
                    <span className="text-white text-sm font-medium truncate">
                      {payment.username}
                    </span>
                  </div>
                  <span className="text-white text-sm font-[family-name:var(--font-space-grotesk)]">
                    {payment.price.toFixed(2)} {payment.currency}
                  </span>
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-full w-fit ${
                      payment.status === "completed"
                        ? "bg-[#10B981]/15 text-[#10B981]"
                        : payment.status === "pending"
                        ? "bg-[#ffa600]/15 text-[#ffa600]"
                        : "bg-red-500/15 text-red-400"
                    }`}
                  >
                    {payment.status}
                  </span>
                  <div className="flex justify-end">
                    <button className="w-8 h-8 rounded-full bg-[#ff6a00] hover:bg-[#ff8c00] flex items-center justify-center text-white transition-colors shadow-md shadow-[#ff6a00]/20">
                      <span className="material-symbols-outlined" style={{ fontSize: "16px" }}>
                        visibility
                      </span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

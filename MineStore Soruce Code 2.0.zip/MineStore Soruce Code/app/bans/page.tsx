"use client";

import React, { useState, useEffect, useMemo, useCallback } from "react";
import Link from "next/link";
import { STORE_URL } from "@/lib/urls";

interface Punishment {
  id: string;
  serverId?: string;
  serverName?: string;
  player: string;
  playerUuid?: string;
  type: "BAN" | "KICK" | "MUTE" | "WARN" | "UNBAN" | "UNMUTE";
  reason: string;
  staff: string;
  duration?: string | number;
  expires?: string;
  timestamp: number;
  dateFormatted?: string;
}

interface Counts {
  bans: number;
  kicks: number;
  mutes: number;
  warnings: number;
  total: number;
}

const SERVER_IP = "play.pika-network.net";
const LOGO_SRC = "/logo.png";

type TabType = "bans" | "kicks" | "mutes" | "warnings";

export default function PunishmentsPage() {
  const [activeTab, setActiveTab] = useState<TabType>("bans");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [submittedSearch, setSubmittedSearch] = useState<string>("");
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [punishments, setPunishments] = useState<Punishment[]>([]);
  const [counts, setCounts] = useState<Counts>({
    bans: 0,
    kicks: 0,
    mutes: 0,
    warnings: 0,
    total: 0,
  });
  const [totalPages, setTotalPages] = useState<number>(1);
  const [totalItems, setTotalItems] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [copyModalOpen, setCopyModalOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [rconPlayerCount, setRconPlayerCount] = useState<number | null>(null);
  const [rconOnline, setRconOnline] = useState<boolean | null>(null);

  // Trigger Toast helper
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((cur) => (cur === msg ? null : cur));
    }, 2800);
  };

  const handleCopyIP = () => {
    navigator.clipboard.writeText(SERVER_IP);
    setCopied(true);
    setCopyModalOpen(true);
    setTimeout(() => setCopied(false), 2200);
  };

  // Fetch punishments from API
  const fetchPunishments = useCallback(
    async (scanConsole = false) => {
      try {
        if (scanConsole) setIsSyncing(true);
        else setLoading(true);

        const params = new URLSearchParams({
          tab: activeTab,
          search: submittedSearch,
          page: String(currentPage),
          limit: "15",
        });
        const res = await fetch(`/api/punishments?${params.toString()}`);
        const data = await res.json();

        if (data.success) {
          setPunishments(data.punishments || []);
          if (data.pagination) {
            setTotalPages(data.pagination.totalPages || 1);
            setTotalItems(data.pagination.totalItems || 0);
          }
          if (data.counts) {
            setCounts(data.counts);
          }
        }
      } catch (err) {
        console.error("Failed to load punishments:", err);
      } finally {
        setLoading(false);
        setIsSyncing(false);
      }
    },
    [activeTab, submittedSearch, currentPage]
  );

  useEffect(() => {
    fetchPunishments();
  }, [fetchPunishments]);

  useEffect(() => {
    let active = true;

    const updatePlayerCount = async () => {
      try {
        const response = await fetch("/api/bridge/heartbeat", { cache: "no-store" });
        const data = await response.json();
        if (!active) return;
        setRconOnline(data.rcon?.online === true);
        setRconPlayerCount(
          data.rcon?.online && typeof data.rcon.onlinePlayers === "number"
            ? data.rcon.onlinePlayers
            : null
        );
      } catch {
        if (active) {
          setRconOnline(false);
          setRconPlayerCount(null);
        }
      }
    };

    void updatePlayerCount();
    const interval = setInterval(updatePlayerCount, 15000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, []);

  // Poll for newly ingested console punishment events every 15 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      fetchPunishments();
    }, 15000);
    return () => clearInterval(interval);
  }, [fetchPunishments]);

  // Handle Tab Switch
  const handleTabChange = (tab: TabType) => {
    setActiveTab(tab);
    setCurrentPage(1);
  };

  // Handle Search Submission
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittedSearch(searchQuery.trim());
    setCurrentPage(1);
  };

  const handleClearSearch = () => {
    setSearchQuery("");
    setSubmittedSearch("");
    setCurrentPage(1);
  };

  const handleUserClick = (username: string) => {
    setSearchQuery(username);
    setSubmittedSearch(username);
    setCurrentPage(1);
  };

  // Minecraft text parser helper to replicate color formatting and emoji
  const renderMinecraftFormatted = (raw: string) => {
    if (!raw) return "No reason specified";

    // Split words or parse color codes like &e, &c, &a, &f, §e, etc.
    const parts = raw.split(/((?:[&§][0-9a-fk-or])+)/gi);

    let currentColor = "";
    let isBold = false;

    return (
      <span>
        {parts.map((part, idx) => {
          if (/^[&§]/.test(part)) {
            // Update styles according to last color code
            const codes = part.replace(/[&§]/g, "").toLowerCase();
            for (const c of codes) {
              if (c === "e") currentColor = "#eab308"; // yellow
              else if (c === "c" || c === "4") currentColor = "#ef4444"; // red
              else if (c === "a" || c === "2") currentColor = "#22c55e"; // green
              else if (c === "b" || c === "3" || c === "9") currentColor = "#38bdf8"; // aqua/blue
              else if (c === "d" || c === "5") currentColor = "#c084fc"; // purple
              else if (c === "6") currentColor = "#f97316"; // orange
              else if (c === "f" || c === "r") currentColor = ""; // reset
              else if (c === "l") isBold = true;
            }
            return null;
          }

          // Highlight URLs
          const urlRegex = /(https?:\/\/[^\s]+)/g;
          if (urlRegex.test(part)) {
            return (
              <span
                key={idx}
                style={{ color: currentColor || undefined }}
                className={isBold ? "font-bold" : ""}
              >
                {part.split(urlRegex).map((sub, sIdx) => {
                  if (/^https?:\/\//i.test(sub)) {
                    return (
                      <a
                        key={sIdx}
                        href={sub}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-orange-500 hover:underline inline-block mx-0.5"
                      >
                        {sub}
                      </a>
                    );
                  }
                  return sub;
                })}
              </span>
            );
          }

          return (
            <span
              key={idx}
              style={{ color: currentColor || undefined }}
              className={`${isBold ? "font-bold" : ""} ${
                part.includes("⚡") ? "text-amber-500 font-bold" : ""
              }`}
            >
              {part}
            </span>
          );
        })}
      </span>
    );
  };

  const navItems = [
    { name: "Home", href: "/" },
    { name: "Vote", href: "/vote" },
    { name: "Staff", href: "/staff" },
    { name: "Rules", href: "/rules" },
    { name: "Support", href: "/#support" },
    { name: "Punishments", href: "/bans", active: true },
  ];

  return (
    <div className="bg-[#f0edf5] text-slate-800 font-sans antialiased min-h-screen flex flex-col selection:bg-[#ff6a00] selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 pointer-events-none">
          <div className="toast-anim bg-[#221008]/95 border border-[#ff6a00]/40 text-white px-4 py-3 rounded-xl shadow-[0_10px_30px_rgba(255,106,0,0.3)] flex items-center gap-2.5 backdrop-blur-lg pointer-events-auto text-sm font-semibold">
            <span className="material-symbols-outlined text-[#ff7700] text-[18px]">check_circle</span>
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Server IP Copied Modal Dialog */}
      {copyModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-sm p-4"
          onClick={() => setCopyModalOpen(false)}
        >
          <div
            className="bg-white text-slate-800 rounded-2xl p-8 sm:p-10 max-w-[420px] w-full mx-auto shadow-2xl text-center flex flex-col items-center gap-4 relative animate-scaleUp"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-20 h-20 rounded-full border-[3.5px] border-[#ff6a00] flex items-center justify-center mt-2">
              <svg
                className="w-10 h-10 text-[#ff6a00]"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                strokeWidth="3.5"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h3 className="text-2xl font-['Plus_Jakarta_Sans',sans-serif] font-extrabold text-[#333333] tracking-tight">
              Server IP Copied
            </h3>
            <p className="text-sm font-semibold text-[#666666]">
              We hope to see you online soon!
            </p>
            <button
              onClick={() => setCopyModalOpen(false)}
              className="mt-2 w-full py-3 bg-[#ff6a00] hover:bg-[#e05d00] text-white font-bold rounded-xl transition-all shadow-md active:scale-95"
            >
              OK
            </button>
          </div>
        </div>
      )}

      {/* Main site hero and navigation */}
      <div className="relative w-full overflow-hidden border-b border-[#ff6a00]/25 bg-[#090403] shadow-[0_20px_50px_rgba(0,0,0,0.7)]">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_45%,rgba(255,106,0,0.24),transparent_38%),radial-gradient(ellipse_at_12%_5%,rgba(255,94,0,0.16),transparent_28%),radial-gradient(ellipse_at_90%_10%,rgba(255,145,0,0.14),transparent_25%)]" />
        <div className="hero-light-beam pointer-events-none absolute inset-x-0 top-0 h-[360px]" />
        <section className="relative z-10 mx-auto max-w-[1320px] px-4 pb-8 pt-9 sm:px-6 sm:pb-10 sm:pt-12">
          <div className="mx-auto mb-6 flex w-fit items-center gap-2 rounded-full border border-[#ffb15c]/20 bg-black/35 px-3.5 py-1.5 text-[10px] font-bold uppercase text-[#ffd09a] shadow-[0_0_28px_rgba(255,106,0,0.12)] backdrop-blur sm:text-xs">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-300 opacity-70" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            Minecraft network · online now
          </div>

          <div className="grid items-center gap-7 lg:grid-cols-[1fr_minmax(280px,420px)_1fr] lg:gap-10">
            <button
              onClick={handleCopyIP}
              type="button"
              title="Copy server address"
              className="group order-2 flex w-full items-center gap-3 rounded-xl border border-white/10 bg-black/35 px-4 py-3 text-left shadow-[0_12px_35px_rgba(0,0,0,0.3)] backdrop-blur-md transition-all hover:-translate-y-1 hover:border-[#ff9b37]/60 hover:bg-black/50 lg:order-1 lg:max-w-[260px] lg:justify-self-end"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#ff7700] text-black shadow-[0_0_24px_rgba(255,119,0,0.38)]">
                <span className="material-symbols-outlined text-[22px]">play_arrow</span>
              </span>
              <span className="min-w-0">
                <span className="block truncate font-['Plus_Jakarta_Sans',sans-serif] text-sm font-extrabold text-white">{SERVER_IP}</span>
                <span className="mt-0.5 flex items-center gap-1.5 text-xs text-[#d7c2b3]" aria-live="polite">
                  <span className={`h-1.5 w-1.5 rounded-full ${rconOnline === null ? "bg-[#9c8273]" : rconOnline ? "bg-emerald-400" : "bg-red-400"}`} />
                  {copied ? "Copied to clipboard" : rconPlayerCount !== null ? `${rconPlayerCount.toLocaleString()} players online` : rconOnline === false ? "RCON unavailable" : "Connecting to RCON..."}
                </span>
              </span>
              <span className="material-symbols-outlined ml-auto text-[#ffb15c] opacity-0 transition-opacity group-hover:opacity-100">content_copy</span>
            </button>

            <Link href="/" className="order-1 flex flex-col items-center text-center transition-transform hover:scale-[1.02] lg:order-2">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img alt="PikaNetwork" className="hero-logo h-auto w-[250px] object-contain drop-shadow-[0_18px_36px_rgba(0,0,0,0.75)] sm:w-[310px] md:w-[360px]" src={LOGO_SRC} />
              <span className="mt-1 font-['Plus_Jakarta_Sans',sans-serif] text-xl font-black text-white sm:text-2xl">Your next adventure starts here</span>
              <span className="mt-1 max-w-sm text-xs text-[#c9a48f] sm:text-sm">BedWars, Survival, SkyBlock and more. Find your world.</span>
            </Link>

            <a href="https://pika-network.net/discord" target="_blank" rel="noopener noreferrer" className="group order-3 flex w-full items-center gap-3 rounded-xl border border-white/10 bg-black/35 px-4 py-3 text-left shadow-[0_12px_35px_rgba(0,0,0,0.3)] backdrop-blur-md transition-all hover:-translate-y-1 hover:border-[#ff9b37]/60 hover:bg-black/50 lg:max-w-[260px]">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#ff7700]/15 text-[#ffab57] ring-1 ring-[#ff9b37]/30">
                <span className="material-symbols-outlined text-[21px]">forum</span>
              </span>
              <span className="min-w-0">
                <span className="block font-['Plus_Jakarta_Sans',sans-serif] text-sm font-extrabold text-white">Discord Server</span>
                <span className="mt-0.5 block text-xs text-[#d7c2b3]">Meet the community</span>
              </span>
              <span className="material-symbols-outlined ml-auto text-[#ffb15c] transition-transform group-hover:translate-x-1">arrow_forward</span>
            </a>
          </div>

          <div className="mt-8 flex flex-col items-center justify-between gap-3 rounded-lg border border-[#ffad54]/35 bg-gradient-to-r from-[#d84b08] via-[#ff7900] to-[#dc4b08] px-4 py-3 shadow-[0_8px_30px_rgba(255,106,0,0.24)] sm:flex-row sm:px-5">
            <div>
              <p className="font-['Plus_Jakarta_Sans',sans-serif] text-sm font-black text-white sm:text-base">Ready to jump in?</p>
              <p className="text-xs text-white/80">Copy the address and join PikaNetwork in-game.</p>
            </div>
            <button onClick={handleCopyIP} type="button" className="inline-flex min-h-10 items-center justify-center gap-2 rounded-md bg-[#17100b] px-4 py-2 text-xs font-extrabold text-white shadow-md transition hover:bg-black sm:text-sm">
              <span className="material-symbols-outlined text-[17px]">content_copy</span>
              {copied ? "Copied!" : SERVER_IP}
            </button>
          </div>
        </section>

        <nav className="relative z-30 w-full border-t border-[#ff6a00]/25 bg-black/40 backdrop-blur-md">
          <div className="mx-auto flex max-w-[1320px] items-center justify-between gap-3 px-4 py-2.5 sm:px-6">
            <div className="hidden items-center gap-1 sm:gap-2.5 md:flex md:gap-4">
              {navItems.map((item) => (
                <Link key={item.name} href={item.href} aria-current={item.active ? "page" : undefined} className={`rounded-lg font-['Plus_Jakarta_Sans',sans-serif] text-sm font-black transition-all sm:text-base ${item.active ? "border border-[#ffea00]/30 bg-[#180903]/80 px-4 py-1.5 text-[#ffea00]" : "px-2.5 py-1.5 text-white hover:text-[#ffea00] sm:px-3"}`}>
                  {item.name}
                </Link>
              ))}
            </div>

            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} type="button" aria-expanded={mobileMenuOpen} className="flex items-center gap-2 py-2 text-sm font-bold text-white md:hidden">
              <span className="material-symbols-outlined">menu</span>
              <span>Menu</span>
            </button>

            <Link href="/rules" className="py-2 text-sm font-bold text-[#ffb15c] transition hover:text-white md:hidden">
              Rules
            </Link>

            <a href={STORE_URL} className="flex shrink-0 items-center gap-2 rounded-xl bg-[#ffea00] px-5 py-2 font-['Plus_Jakarta_Sans',sans-serif] text-sm font-black text-[#1c1803] shadow-[0_4px_16px_rgba(255,234,0,0.35)] transition hover:bg-[#ffd700] sm:px-6 sm:text-base">
              <span className="material-symbols-outlined text-[18px]">shopping_cart</span>
              <span>Store</span>
            </a>
          </div>

          {mobileMenuOpen && (
            <div className="flex flex-col gap-1 border-t border-white/10 bg-black/70 px-4 py-3 md:hidden">
              {navItems.map((item) => (
                <Link key={item.name} href={item.href} onClick={() => setMobileMenuOpen(false)} className={`py-2 text-sm font-bold ${item.active ? "text-[#ffea00]" : "text-white/80"}`}>
                  {item.name}
                </Link>
              ))}
            </div>
          )}
        </nav>
      </div>

      {/* MAIN PUNISHMENTS CONTENT */}
      <main className="flex-1 max-w-[1240px] w-full mx-auto px-4 sm:px-6 py-8 sm:py-10">
        {/* Title & Live Monitoring Indicator */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Punishments
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Live server punishments, bans, kicks, mutes, and warning logs.
            </p>
          </div>

          {/* Console Live Monitoring Status */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-white px-3.5 py-1.5 rounded-full border border-gray-200 shadow-sm text-xs font-semibold text-slate-700">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Console Monitoring: <strong className="text-emerald-600">Active</strong></span>
            </div>

            <button
              onClick={() => fetchPunishments(true)}
              disabled={isSyncing}
              className="flex items-center gap-1.5 bg-[#ff6a00] hover:bg-[#e05d00] active:scale-95 text-white px-3.5 py-1.5 rounded-full text-xs font-bold transition-all shadow-sm disabled:opacity-50"
              title="Scan stored console output for confirmed punishment events"
            >
              <span className={`material-symbols-outlined text-[16px] ${isSyncing ? "animate-spin" : ""}`}>
                sync
              </span>
              <span>{isSyncing ? "Scanning..." : "Scan Console"}</span>
            </button>
          </div>
        </div>

        {/* 100% COPY OF PIKA-NETWORK LITEBANS TABLE CONTAINER */}
        <div className="bg-white rounded-lg shadow-[0_4px_20px_rgba(0,0,0,0.08)] border border-gray-200 overflow-hidden">
          {/* TOP TABS & SEARCH BAR (ORANGE THEME) */}
          <div className="bg-[#ff6a00] bg-gradient-to-r from-[#ff6a00] to-[#ff7700] px-3 sm:px-6 pt-3 flex flex-col md:flex-row md:items-end justify-between gap-3">
            {/* Left: 4 Tabs (Bans, Kicks, Mutes, Warnings) */}
            <div className="flex items-end gap-1 sm:gap-2 overflow-x-auto pb-0">
              {/* Bans Tab */}
              <button
                onClick={() => handleTabChange("bans")}
                className={`flex items-center gap-2 px-5 sm:px-7 py-3 font-bold text-sm sm:text-base transition-all rounded-t-md select-none ${
                  activeTab === "bans"
                    ? "bg-white text-[#ff6a00] shadow-sm font-extrabold"
                    : "text-white hover:text-white/80 hover:bg-black/10"
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">block</span>
                <span>Bans</span>
                {counts.bans > 0 && (
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      activeTab === "bans"
                        ? "bg-[#ff6a00]/10 text-[#ff6a00]"
                        : "bg-black/20 text-white"
                    }`}
                  >
                    {counts.bans}
                  </span>
                )}
              </button>

              {/* Kicks Tab */}
              <button
                onClick={() => handleTabChange("kicks")}
                className={`flex items-center gap-2 px-5 sm:px-7 py-3 font-bold text-sm sm:text-base transition-all rounded-t-md select-none ${
                  activeTab === "kicks"
                    ? "bg-white text-[#ff6a00] shadow-sm font-extrabold"
                    : "text-white hover:text-white/80 hover:bg-black/10"
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">logout</span>
                <span>Kicks</span>
                {counts.kicks > 0 && (
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      activeTab === "kicks"
                        ? "bg-[#ff6a00]/10 text-[#ff6a00]"
                        : "bg-black/20 text-white"
                    }`}
                  >
                    {counts.kicks}
                  </span>
                )}
              </button>

              {/* Mutes Tab */}
              <button
                onClick={() => handleTabChange("mutes")}
                className={`flex items-center gap-2 px-5 sm:px-7 py-3 font-bold text-sm sm:text-base transition-all rounded-t-md select-none ${
                  activeTab === "mutes"
                    ? "bg-white text-[#ff6a00] shadow-sm font-extrabold"
                    : "text-white hover:text-white/80 hover:bg-black/10"
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">volume_off</span>
                <span>Mutes</span>
                {counts.mutes > 0 && (
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      activeTab === "mutes"
                        ? "bg-[#ff6a00]/10 text-[#ff6a00]"
                        : "bg-black/20 text-white"
                    }`}
                  >
                    {counts.mutes}
                  </span>
                )}
              </button>

              {/* Warnings Tab */}
              <button
                onClick={() => handleTabChange("warnings")}
                className={`flex items-center gap-2 px-5 sm:px-7 py-3 font-bold text-sm sm:text-base transition-all rounded-t-md select-none ${
                  activeTab === "warnings"
                    ? "bg-white text-[#ff6a00] shadow-sm font-extrabold"
                    : "text-white hover:text-white/80 hover:bg-black/10"
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">warning</span>
                <span>Warnings</span>
                {counts.warnings > 0 && (
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      activeTab === "warnings"
                        ? "bg-[#ff6a00]/10 text-[#ff6a00]"
                        : "bg-black/20 text-white"
                    }`}
                  >
                    {counts.warnings}
                  </span>
                )}
              </button>
            </div>

            {/* Right: Search Box */}
            <form onSubmit={handleSearchSubmit} className="mb-2 sm:mb-2.5">
              <div className="relative flex items-center bg-black/20 hover:bg-black/25 focus-within:bg-black/30 border border-white/20 rounded-md transition-all">
                <span className="material-symbols-outlined text-white/80 pl-3 text-[18px] pointer-events-none">
                  search
                </span>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Enter a Minecraft Username..."
                  className="bg-transparent text-white placeholder-white/70 text-xs sm:text-sm px-3 py-2 outline-none w-56 sm:w-64"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={handleClearSearch}
                    className="pr-2 text-white/70 hover:text-white text-xs"
                  >
                    <span className="material-symbols-outlined text-[16px]">close</span>
                  </button>
                )}
                <button
                  type="submit"
                  className="bg-black/30 hover:bg-black/40 text-white font-bold text-xs px-3 py-2 rounded-r-md transition-colors border-l border-white/20"
                >
                  Search
                </button>
              </div>
            </form>
          </div>

          {/* Active Search Filter Banner */}
          {submittedSearch && (
            <div className="bg-orange-50 border-b border-orange-200 px-6 py-2 flex items-center justify-between text-xs text-orange-900">
              <span>
                Filtering punishments for user: <strong>&quot;{submittedSearch}&quot;</strong>
              </span>
              <button
                onClick={handleClearSearch}
                className="text-[#ff6a00] font-bold hover:underline"
              >
                Clear Filter
              </button>
            </div>
          )}

          {/* PUNISHMENTS TABLE */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              {/* Header row in solid orange matching Pika screenshot */}
              <thead>
                <tr className="bg-[#ff6a00] text-white uppercase text-[13px] font-black tracking-wider">
                  <th className="py-3.5 pl-6 pr-4 w-[20%]">USER</th>
                  <th className="py-3.5 px-4 w-[18%]">STAFF</th>
                  <th className="py-3.5 px-4 w-[36%]">REASON</th>
                  <th className="py-3.5 px-4 w-[14%]">DATE</th>
                  <th className="py-3.5 pl-4 pr-6 w-[12%]">EXPIRES</th>
                </tr>
              </thead>

              {/* Body rows */}
              <tbody className="divide-y divide-gray-100 text-sm">
                {loading ? (
                  <tr>
                    <td colSpan={5} className="py-16 text-center text-slate-400">
                      <div className="flex flex-col items-center justify-center gap-3">
                        <span className="material-symbols-outlined text-4xl text-[#ff6a00] animate-spin">
                          progress_activity
                        </span>
                        <span className="font-semibold text-sm">Loading punishment records...</span>
                      </div>
                    </td>
                  </tr>
                ) : punishments.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-16 text-center text-slate-500">
                      <div className="flex flex-col items-center justify-center gap-2">
                        <span className="material-symbols-outlined text-4xl text-slate-300">
                          sentiment_satisfied
                        </span>
                        <span className="font-bold text-base text-slate-700">
                          No {activeTab} found
                        </span>
                        <p className="text-xs text-slate-400 max-w-sm">
                          {submittedSearch
                            ? `No records found matching username "${submittedSearch}".`
                            : `There are currently no recorded ${activeTab} on the server.`}
                        </p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  punishments.map((item) => (
                    <tr
                      key={item.id}
                      className="hover:bg-orange-50/40 transition-colors group"
                    >
                      {/* USER COLUMN: Avatar + Username in purple/orange bold */}
                      <td className="py-3 pl-6 pr-4 whitespace-nowrap">
                        <button
                          onClick={() => handleUserClick(item.player)}
                          className="flex items-center gap-2.5 group-hover:scale-[1.02] transition-transform text-left"
                        >
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img
                            src={`https://cravatar.eu/helmavatar/${encodeURIComponent(
                              item.player
                            )}/24.png`}
                            alt={item.player}
                            className="w-6 h-6 rounded shadow-sm bg-slate-200 flex-shrink-0"
                            onError={(e) => {
                              // Fallback to Steve head if skin server fails
                              (e.target as HTMLImageElement).src =
                                "https://cravatar.eu/helmavatar/Steve/24.png";
                            }}
                          />
                          <span className="font-bold text-[#ff6a00] hover:underline cursor-pointer">
                            {item.player}
                          </span>
                        </button>
                      </td>

                      {/* STAFF COLUMN: Console/Staff Avatar + Name */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-2.5">
                          {item.staff.toUpperCase() === "CONSOLE" ? (
                            <div className="w-6 h-6 rounded bg-[#222222] text-white flex items-center justify-center font-mono text-[10px] font-bold shadow-sm flex-shrink-0 border border-black/10">
                              💻
                            </div>
                          ) : (
                            /* eslint-disable-next-line @next/next/no-img-element */
                            <img
                              src={`https://cravatar.eu/helmavatar/${encodeURIComponent(
                                item.staff
                              )}/24.png`}
                              alt={item.staff}
                              className="w-6 h-6 rounded shadow-sm bg-slate-200 flex-shrink-0"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src =
                                  "https://cravatar.eu/helmavatar/CONSOLE/24.png";
                              }}
                            />
                          )}
                          <span className="font-bold text-slate-800 text-xs sm:text-sm">
                            {item.staff}
                          </span>
                        </div>
                      </td>

                      {/* REASON COLUMN: Minecraft colored & styled reason */}
                      <td className="py-3 px-4 text-xs sm:text-sm text-slate-600 leading-snug">
                        {renderMinecraftFormatted(item.reason)}
                      </td>

                      {/* DATE COLUMN: September 26, 2026, 05:44 */}
                      <td className="py-3 px-4 text-xs text-slate-500 whitespace-nowrap font-medium">
                        {item.dateFormatted || new Date(item.timestamp).toLocaleString()}
                      </td>

                      {/* EXPIRES COLUMN: October 03, 2026, 05:44 or Permanent */}
                      <td className="py-3 pl-4 pr-6 text-xs whitespace-nowrap">
                        <span
                          className={`font-semibold ${
                            item.expires?.toLowerCase().includes("permanent")
                              ? "text-rose-600 font-bold"
                              : item.expires?.toLowerCase().includes("expired")
                              ? "text-slate-400 font-medium"
                              : "text-slate-700"
                          }`}
                        >
                          {item.expires || "Permanent"}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* PAGINATION BAR (100% COPY OF PIKA-NETWORK LITEBANS PAGINATION) */}
          <div className="border-t border-gray-200 bg-gray-50/70 px-6 py-3.5 flex items-center justify-between text-xs sm:text-sm font-medium text-slate-600 select-none">
            {/* Prev Button */}
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage <= 1 || loading}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-all font-semibold ${
                currentPage <= 1 || loading
                  ? "text-slate-300 cursor-not-allowed"
                  : "text-slate-700 hover:text-[#ff6a00] hover:bg-orange-50 active:scale-95"
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">chevron_left</span>
              <span>Prev</span>
            </button>

            {/* Middle Info: e.g. "1,526,997 bans" */}
            <div className="text-slate-500 font-medium text-xs sm:text-sm">
              <strong className="text-slate-800 font-bold">
                {totalItems.toLocaleString()}
              </strong>{" "}
              {activeTab}
              {totalPages > 1 && (
                <span className="text-slate-400 ml-2">
                  (Page {currentPage} of {totalPages})
                </span>
              )}
            </div>

            {/* Next Button */}
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages || loading}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-all font-semibold ${
                currentPage >= totalPages || loading
                  ? "text-slate-300 cursor-not-allowed"
                  : "text-slate-700 hover:text-[#ff6a00] hover:bg-orange-50 active:scale-95"
              }`}
            >
              <span>Next</span>
              <span className="material-symbols-outlined text-[16px]">chevron_right</span>
            </button>
          </div>
        </div>
      </main>

      {/* Footer matching the homepage */}
      <footer className="relative z-20 mt-20 w-full border-t border-[#ff6a00]/20 bg-[#0a0503] pt-10 pb-12 text-[#c9a48f]">
        <div className="mx-auto flex max-w-[1320px] flex-col gap-10 px-4 sm:px-6">
          {/* Top Banner Inside Footer */}
          <div className="relative flex w-full flex-col items-center justify-between gap-4 rounded-2xl border border-[#ffa04d]/40 bg-gradient-to-r from-[#d84315] via-[#ff6a00] to-[#e65100] px-5 py-3.5 shadow-[0_8px_32px_rgba(255,106,0,0.45)] sm:flex-row sm:px-8 sm:py-4">
            {/* Left: Server IP & Copy */}
            <div
              onClick={handleCopyIP}
              className="flex items-center gap-4 cursor-pointer group"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={LOGO_SRC}
                alt="PikaNetwork"
                className="w-14 sm:w-16 h-auto object-contain -mt-6 sm:-mt-8 -mb-2 drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)] group-hover:scale-105 transition-transform"
              />
              <div className="flex flex-col">
                <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base sm:text-lg tracking-wider leading-tight group-hover:text-[#ffe4a0] transition-colors">
                  {SERVER_IP.toUpperCase()}
                </span>
                <span className="flex items-center gap-1.5 text-[11px] font-black text-[#ffe4a0] tracking-wider uppercase">
                  <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse"></span>
                  {copied ? "COPIED TO CLIPBOARD!" : "ONLINE - CLICK TO COPY"}
                </span>
              </div>
            </div>

            {/* Right: Social Media Icons */}
            <div className="flex items-center gap-4 text-white">
              {/* Discord */}
              <a
                href="https://pika-network.net/discord"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#ffea00] hover:scale-110 transition-all"
                aria-label="Discord"
              >
                <svg className="w-6 h-6 fill-current" viewBox="0 0 127.14 96.36">
                  <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z" />
                </svg>
              </a>

              {/* X / Twitter */}
              <a
                href="https://twitter.com/PikaNetworkMC"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#ffea00] hover:scale-110 transition-all"
                aria-label="X (Twitter)"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </a>

              {/* Instagram */}
              <a
                href="https://instagram.com/pikanetworkmc"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#ffea00] hover:scale-110 transition-all"
                aria-label="Instagram"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
              </a>
            </div>
          </div>

          {/* Main 3 Columns */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10 pt-4">
            {/* Column 1: ABOUT US */}
            <div className="flex flex-col gap-3">
              <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase">
                ABOUT US
              </h3>
              <p className="text-sm text-[#c9a48f] leading-relaxed">
                PikaNetwork is one of the largest Minecraft servers! Since the day PikaNetwork was formed,
                back in 2014, we have focused on bringing joy to the community. We offer many game modes,
                these being BedWars, OneBlock, KitPvP, OP Factions, OP Lifesteal, OP Prison, OP SkyBlock,
                Practice, SkyPvP, Survival and SkyMines!
              </p>
              <div className="text-sm text-white pt-1">
                <span className="text-[#c9a48f]">Come play at: </span>
                <strong
                  className="text-[#ffea00] font-mono cursor-pointer hover:underline"
                  onClick={handleCopyIP}
                >
                  {SERVER_IP}
                </strong>
              </div>
            </div>

            {/* Column 2: LINKS */}
            <div className="flex flex-col gap-3">
              <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase">
                LINKS
              </h3>
              <ul className="flex flex-col gap-2 text-sm text-[#c9a48f]">
                <li
                  className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer"
                  onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
                >
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Back to Top</span>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors">
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <a href={STORE_URL} className="hover:text-[#ffea00] transition-colors font-medium">
                    Store
                  </a>
                </li>
                <li
                  className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer"
                  onClick={() => triggerToast("Contact support form opened")}
                >
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Contact Us</span>
                </li>
                <li
                  className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer"
                  onClick={() => triggerToast("Terms & Conditions")}
                >
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Terms and Conditions</span>
                </li>
                <li
                  className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer"
                  onClick={() => triggerToast("Privacy Policy")}
                >
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Privacy Policy</span>
                </li>
                <li
                  className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer"
                  onClick={() => triggerToast("Responsible disclosure guidelines")}
                >
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Responsible disclosure</span>
                </li>
              </ul>
            </div>

            {/* Column 3: SUPPORT US */}
            <div className="flex flex-col gap-3">
              <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase">
                SUPPORT US
              </h3>
              <p className="text-sm text-[#c9a48f] leading-relaxed">
                Have you had a fun time here? Support us by purchasing packages such as ranks, commands, crate keys, and more!
              </p>
              <div className="pt-2">
                <a
                  href={STORE_URL}
                  className="inline-flex items-center justify-center bg-[#ffea00] hover:bg-[#ffd700] text-[#1c1803] font-['Plus_Jakarta_Sans',sans-serif] font-extrabold text-sm px-7 py-2.5 rounded-xl shadow-[0_4px_16px_rgba(255,234,0,0.35)] hover:scale-105 active:scale-95 transition-all"
                >
                  Visit Store
                </a>
              </div>
            </div>
          </div>

          {/* Bottom Copyright & Disclaimer */}
          <div className="pt-6 border-t border-[#ff6a00]/15 flex items-start gap-3.5 text-xs text-[#8c7262]">
            <div className="w-8 h-8 rounded-lg bg-[#221008] border border-white/10 flex items-center justify-center text-slate-400 font-bold text-base flex-shrink-0 shadow-inner">
              G
            </div>
            <div className="flex flex-col gap-0.5">
              <div className="text-white font-bold">Copyright © CraftiGames B.V. 2026</div>
              <div className="text-[11px] text-[#8c7262]">
                We are not affiliated with Mojang or Minecraft.
              </div>
              <div className="text-[11px] text-[#8c7262]">
                We are not affiliated with Nintendo Co., Ltd.
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

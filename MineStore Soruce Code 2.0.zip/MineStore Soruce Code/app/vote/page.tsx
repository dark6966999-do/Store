"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { STORE_URL } from "@/lib/urls";

interface VoteLink {
  name: string;
  url: string;
}

interface StoreConfig {
  serverIp: string;
  serverName: string;
  logoUrl: string;
  discordUrl: string;
  forumUrl: string;
  voteLinks: VoteLink[];
  socialLinks: Record<string, string>;
}

// Sample leaderboard voters
const TOP_VOTERS = [
  { rank: 1, name: "ShadowNinja_99", votes: 124, prize: "$50 Store Voucher", badge: "👑 Top Voter" },
  { rank: 2, name: "DragonSlayer_X", votes: 118, prize: "$30 Store Voucher", badge: "🥈 2nd Place" },
  { rank: 3, name: "ValkyrieQueen", votes: 112, prize: "$20 Store Voucher", badge: "🥉 3rd Place" },
  { rank: 4, name: "FrostBite_MC", votes: 98, prize: "Mythic Crate Key", badge: "#4" },
  { rank: 5, name: "ThunderBolt", votes: 94, prize: "500 Store Coins", badge: "#5" },
  { rank: 6, name: "ObsidianKnight", votes: 89, prize: "Cosmic Crate Key", badge: "#6" },
  { rank: 7, name: "BlazeMaster", votes: 85, prize: "250 Store Coins", badge: "#7" },
  { rank: 8, name: "PixelCrafter", votes: 81, prize: "Vote Crate Bundle", badge: "#8" },
  { rank: 9, name: "EnderDragonLord", votes: 76, prize: "100 Store Coins", badge: "#9" },
  { rank: 10, name: "MysticArcher", votes: 72, prize: "Vote Crate Key", badge: "#10" },
];

export default function VotePage() {
  const [config, setConfig] = useState<StoreConfig>({
    serverIp: "play.pika-network.net",
    serverName: "PikaNetwork",
    logoUrl: "/logo.png",
    discordUrl: "https://discord.gg/pika",
    forumUrl: "https://pika-network.net/forums/",
    voteLinks: [
      { name: "Minecraft-MP", url: "https://minecraft-mp.com/server/pikanetwork/vote/" },
      { name: "TopG", url: "https://topg.org/minecraft-servers/server-pikanetwork" },
      { name: "Planet Minecraft", url: "https://www.planetminecraft.com/server/pikanetwork/vote/" },
      { name: "MinecraftServers.org", url: "https://minecraftservers.org/server/pikanetwork" },
    ],
    socialLinks: {},
  });

  const [copied, setCopied] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [votedSites, setVotedSites] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);

  // Fetch dynamic config from backend
  useEffect(() => {
    fetch("/api/config")
      .then((res) => res.json())
      .then((data) => {
        if (data && !data.error) {
          setConfig({
            serverIp: data.serverIp || "play.pika-network.net",
            serverName: data.serverName || "PikaNetwork",
            logoUrl: data.logoUrl || "/logo.png",
            discordUrl: data.discordUrl || "https://discord.gg/pika",
            forumUrl: data.forumUrl || "https://pika-network.net/forums/",
            voteLinks:
              Array.isArray(data.voteLinks) && data.voteLinks.length > 0
                ? data.voteLinks
                : [
                    { name: "Minecraft-MP", url: "https://minecraft-mp.com/server/pikanetwork/vote/" },
                    { name: "TopG", url: "https://topg.org/minecraft-servers/server-pikanetwork" },
                    { name: "Planet Minecraft", url: "https://www.planetminecraft.com/server/pikanetwork/vote/" },
                    { name: "MinecraftServers.org", url: "https://minecraftservers.org/server/pikanetwork" },
                  ],
            socialLinks: data.socialLinks || {},
          });
        }
      })
      .catch((err) => console.error("Error loading config:", err))
      .finally(() => setLoading(false));

    // Load voted state from local storage
    try {
      const saved = localStorage.getItem("minestore_voted_sites");
      if (saved) {
        setVotedSites(JSON.parse(saved));
      }
    } catch {}
  }, []);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((cur) => (cur === msg ? null : cur));
    }, 2800);
  };

  const handleCopyIp = () => {
    navigator.clipboard.writeText(config.serverIp);
    setCopied(true);
    triggerToast(`Copied ${config.serverIp} to clipboard!`);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleVoteClick = (index: number, url: string) => {
    window.open(url, "_blank", "noopener,noreferrer");
    const updated = { ...votedSites, [index]: Date.now() };
    setVotedSites(updated);
    try {
      localStorage.setItem("minestore_voted_sites", JSON.stringify(updated));
    } catch {}
    triggerToast("Thank you for voting! Claiming reward in-game...");
  };

  const isVotedRecently = (index: number) => {
    const timestamp = votedSites[index];
    if (!timestamp) return false;
    const hoursPassed = (Date.now() - timestamp) / (1000 * 60 * 60);
    return hoursPassed < 24;
  };

  return (
    <div className="min-h-screen bg-[#0a0503] text-white flex flex-col font-sans selection:bg-[#ff6a00] selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3 rounded-xl bg-[#1e1008] border border-[#ff6a00]/40 text-white shadow-2xl shadow-[#ff6a00]/20 animate-bounce">
          <span className="material-symbols-outlined text-[#ff8c00]">check_circle</span>
          <span className="text-sm font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Top Header Bar */}
      <header className="border-b border-[rgba(255,120,30,0.12)] bg-[#0c0603]/90 backdrop-blur-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          {/* Logo & Server Name */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#ff6a00] to-[#ff8c00] flex items-center justify-center shadow-lg shadow-[#ff6a00]/30 group-hover:scale-105 transition-all duration-300">
              <span className="material-symbols-outlined text-white" style={{ fontSize: "24px" }}>
                how_to_vote
              </span>
            </div>
            <div>
              <span className="font-black text-xl tracking-tight text-white group-hover:text-[#ff8c00] transition-colors">
                {config.serverName}
              </span>
              <span className="block text-xs font-semibold text-[#ff6a00] tracking-widest uppercase">
                Vote & Rewards
              </span>
            </div>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-1 bg-[#140a05] border border-[rgba(255,120,30,0.1)] rounded-full px-3 py-1.5 shadow-inner">
            <Link
              href="/"
              className="px-4 py-2 rounded-full text-sm font-medium text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all"
            >
              Home
            </Link>
            <a
              href={STORE_URL}
              className="px-4 py-2 rounded-full text-sm font-medium text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all"
            >
              Store
            </a>
            <Link
              href="/vote"
              className="px-4 py-2 rounded-full text-sm font-bold text-white bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] shadow-md shadow-[#ff6a00]/25 transition-all"
            >
              Vote
            </Link>
            {config.forumUrl && (
              <a
                href={config.forumUrl}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 rounded-full text-sm font-medium text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all"
              >
                Forums
              </a>
            )}
            <Link
              href="/dashboard"
              className="px-4 py-2 rounded-full text-sm font-medium text-[#9c8273] hover:text-white hover:bg-[#1e1008] transition-all flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-xs">dashboard</span>
              Dashboard
            </Link>
          </nav>

          {/* Right Action Widgets */}
          <div className="flex items-center gap-3">
            {/* Copy Server IP */}
            <button
              onClick={handleCopyIp}
              className="relative group flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-[#140a05] hover:bg-[#1e1008] border border-[rgba(255,120,30,0.15)] hover:border-[#ff6a00]/40 transition-all duration-300 shadow-lg cursor-pointer"
              title="Click to copy server IP"
            >
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <div className="text-left hidden sm:block">
                <p className="text-[10px] uppercase font-bold text-[#8a6b58] tracking-wider leading-none">
                  {copied ? "Copied!" : "Click to copy IP"}
                </p>
                <p className="text-xs font-black text-white group-hover:text-[#ff8c00] transition-colors leading-tight">
                  {config.serverIp}
                </p>
              </div>
              <span className="material-symbols-outlined text-[#8a6b58] group-hover:text-[#ff8c00] text-sm transition-colors">
                {copied ? "check" : "content_copy"}
              </span>
            </button>

            {/* Discord Button */}
            {config.discordUrl && (
              <a
                href={config.discordUrl}
                target="_blank"
                rel="noreferrer"
                className="hidden lg:flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#5865F2]/15 hover:bg-[#5865F2]/25 border border-[#5865F2]/30 text-white text-xs font-bold transition-all duration-300 shadow-md"
              >
                <svg className="w-4 h-4 fill-[#5865F2]" viewBox="0 0 24 24">
                  <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
                </svg>
                Discord
              </a>
            )}
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Hero Rewards Banner (Styled in MineStore fiery amber theme) */}
        <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#1b0d06] via-[#120803] to-[#0c0502] border border-[rgba(255,120,30,0.18)] p-8 sm:p-12 mb-12 shadow-2xl">
          {/* Ambient background glowing orbs */}
          <div className="absolute -top-24 -left-24 w-96 h-96 bg-[#ff6a00]/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-[#ff8c00]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#ff6a00]/15 border border-[#ff6a00]/30 text-[#ff8c00] text-xs font-bold uppercase tracking-wider mb-5">
              <span className="material-symbols-outlined text-sm">stars</span>
              Official Voting Portal
            </div>

            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
              Vote for <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#ff6a00] via-[#ff8c00] to-[#ffa040]">{config.serverName}</span>
            </h1>

            <p className="mt-4 text-base sm:text-lg text-[#bca292] leading-relaxed">
              Support our community every 24 hours to earn free in-game crate keys, realm store coins, voter streaks, and a chance to win up to <strong className="text-white font-bold">$100+ in monthly store vouchers!</strong>
            </p>

            {/* Voting Perks Badges */}
            <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3.5 rounded-2xl bg-[#0c0603]/80 border border-[rgba(255,120,30,0.1)] flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#ff6a00]/20 flex items-center justify-center text-[#ff8c00] font-bold">
                  🔑
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Free Keys</h4>
                  <p className="text-[10px] text-[#8a6b58]">Mythic & Cosmic</p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#0c0603]/80 border border-[rgba(255,120,30,0.1)] flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-400 font-bold">
                  🪙
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Store Coins</h4>
                  <p className="text-[10px] text-[#8a6b58]">50+ per vote</p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#0c0603]/80 border border-[rgba(255,120,30,0.1)] flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-400 font-bold">
                  ⚡
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">XP Buffs</h4>
                  <p className="text-[10px] text-[#8a6b58]">2x Multipliers</p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#0c0603]/80 border border-[rgba(255,120,30,0.1)] flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold">
                  🏆
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Top Prizes</h4>
                  <p className="text-[10px] text-[#8a6b58]">$50 Vouchers</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Content Layout: Left = Vote Links, Right = Top Voters Leaderboard */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* LEFT COLUMN: Dynamic Vote Links Grid */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#ff6a00]">list_alt</span>
                  Active Voting Links
                </h2>
                <p className="text-sm text-[#8a6b58] mt-1">
                  Click each site, enter your username, and complete the vote to collect all rewards.
                </p>
              </div>
              <span className="text-xs px-3 py-1 rounded-full bg-[#1e1008] border border-[rgba(255,120,30,0.2)] text-[#ff8c00] font-bold">
                {config.voteLinks.length} Links Available
              </span>
            </div>

            {/* List of dynamic vote links */}
            <div className="space-y-4">
              {config.voteLinks.map((link, index) => {
                const voted = isVotedRecently(index);

                return (
                  <div
                    key={index}
                    className={`relative overflow-hidden rounded-2xl p-5 border transition-all duration-300 ${
                      voted
                        ? "bg-[#140a05]/60 border-[rgba(255,120,30,0.08)] opacity-75"
                        : "bg-gradient-to-r from-[#170c06] to-[#120803] border-[rgba(255,120,30,0.15)] hover:border-[#ff6a00]/40 shadow-lg hover:shadow-[#ff6a00]/10 hover:-translate-y-0.5"
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      {/* Left: Index number + Title & Perks */}
                      <div className="flex items-center gap-4">
                        {/* Vote Site Number Badge */}
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#ff6a00] to-[#ff8c00] flex items-center justify-center font-black text-white text-lg shadow-md shadow-[#ff6a00]/20 flex-shrink-0">
                          #{String(index + 1).padStart(2, "0")}
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-black text-lg text-white group-hover:text-[#ff8c00] transition-colors">
                              {link.name || `Voting Platform #${index + 1}`}
                            </h3>
                            {voted ? (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                Voted ✓
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#ff6a00]/10 text-[#ff8c00] border border-[#ff6a00]/20 flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#ff6a00] animate-ping" />
                                Ready
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-[#9c8273] mt-0.5 flex items-center gap-2">
                            <span>🎁 1x Vote Crate Key</span>
                            <span>•</span>
                            <span>🪙 50 Store Coins</span>
                          </p>
                        </div>
                      </div>

                      {/* Right: Vote Action Button */}
                      <div className="flex items-center gap-2 sm:self-center">
                        <button
                          onClick={() => handleVoteClick(index, link.url)}
                          className={`w-full sm:w-auto px-6 py-3 rounded-xl font-bold text-sm tracking-wide flex items-center justify-center gap-2 transition-all duration-300 shadow-md ${
                            voted
                              ? "bg-[#1e1008] text-[#8a6b58] hover:text-white border border-[rgba(255,120,30,0.1)]"
                              : "bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] hover:from-[#ff7a20] hover:to-[#ff9c20] text-white shadow-[#ff6a00]/25 hover:shadow-[#ff6a00]/40 hover:scale-102"
                          }`}
                        >
                          <span className="material-symbols-outlined text-base">
                            {voted ? "refresh" : "open_in_new"}
                          </span>
                          {voted ? "Vote Again" : "Vote Now"}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* How to vote guide */}
            <div className="mt-10 rounded-2xl bg-[#120803] border border-[rgba(255,120,30,0.12)] p-6">
              <h3 className="text-lg font-black text-white flex items-center gap-2 mb-4">
                <span className="material-symbols-outlined text-[#ff6a00]">help_outline</span>
                How to Vote & Claim Rewards
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex gap-3">
                  <div className="w-7 h-7 rounded-lg bg-[#1e1008] border border-[#ff6a00]/30 text-[#ff8c00] text-xs font-black flex items-center justify-center flex-shrink-0">
                    1
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">Click a voting link</h5>
                    <p className="text-[11px] text-[#8a6b58] mt-0.5">
                      Open any of the active vote links above in a new browser tab.
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="w-7 h-7 rounded-lg bg-[#1e1008] border border-[#ff6a00]/30 text-[#ff8c00] text-xs font-black flex items-center justify-center flex-shrink-0">
                    2
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">Enter your Minecraft name</h5>
                    <p className="text-[11px] text-[#8a6b58] mt-0.5">
                      Type your exact in-game IGN on the voting website form.
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="w-7 h-7 rounded-lg bg-[#1e1008] border border-[#ff6a00]/30 text-[#ff8c00] text-xs font-black flex items-center justify-center flex-shrink-0">
                    3
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">Complete verification</h5>
                    <p className="text-[11px] text-[#8a6b58] mt-0.5">
                      Solve the website captcha and press the &ldquo;Submit Vote&rdquo; button.
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="w-7 h-7 rounded-lg bg-[#1e1008] border border-[#ff6a00]/30 text-[#ff8c00] text-xs font-black flex items-center justify-center flex-shrink-0">
                    4
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">Enjoy in-game perks</h5>
                    <p className="text-[11px] text-[#8a6b58] mt-0.5">
                      Keys and coins are credited automatically to your account within 60s!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: Monthly Top Voters Leaderboard (matching PikaNetwork) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="rounded-3xl bg-gradient-to-b from-[#160b05] to-[#0f0602] border border-[rgba(255,120,30,0.15)] p-6 shadow-xl">
              {/* Leaderboard Header */}
              <div className="flex items-center justify-between pb-5 border-b border-[rgba(255,120,30,0.1)]">
                <div>
                  <h3 className="text-xl font-black text-white flex items-center gap-2">
                    <span className="material-symbols-outlined text-amber-400">emoji_events</span>
                    Top Voters of the Month
                  </h3>
                  <p className="text-xs text-[#8a6b58] mt-0.5">
                    Resets on the 1st of every month
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
                    Active Season
                  </span>
                </div>
              </div>

              {/* Podium: Top 3 Winners */}
              <div className="mt-6 grid grid-cols-3 gap-2.5 items-end pt-4 pb-6">
                {/* 2nd Place */}
                <div className="flex flex-col items-center text-center p-3 rounded-2xl bg-[#140a05] border border-slate-400/20 relative">
                  <div className="w-12 h-12 rounded-xl overflow-hidden bg-slate-700/50 mb-2 border border-slate-300/40">
                    <img
                      src={`https://minotar.net/helm/${TOP_VOTERS[1].name}/64.png`}
                      alt={TOP_VOTERS[1].name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-[10px] font-black text-slate-300">2ND</span>
                  <p className="text-xs font-bold text-white truncate max-w-[85px]">
                    {TOP_VOTERS[1].name}
                  </p>
                  <p className="text-[11px] font-semibold text-[#ff8c00]">
                    {TOP_VOTERS[1].votes} votes
                  </p>
                  <span className="mt-1 text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-400/10 text-slate-300">
                    $30 Voucher
                  </span>
                </div>

                {/* 1st Place (Crown) */}
                <div className="flex flex-col items-center text-center p-3.5 rounded-2xl bg-[#1e0e06] border border-amber-500/40 relative -translate-y-2 shadow-lg shadow-amber-500/10">
                  <div className="absolute -top-3 text-amber-400 text-lg">👑</div>
                  <div className="w-14 h-14 rounded-xl overflow-hidden bg-amber-600/30 mb-2 border-2 border-amber-400 shadow-md">
                    <img
                      src={`https://minotar.net/helm/${TOP_VOTERS[0].name}/64.png`}
                      alt={TOP_VOTERS[0].name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-[10px] font-black text-amber-400">1ST</span>
                  <p className="text-xs font-black text-white truncate max-w-[95px]">
                    {TOP_VOTERS[0].name}
                  </p>
                  <p className="text-[11px] font-bold text-[#ff8c00]">
                    {TOP_VOTERS[0].votes} votes
                  </p>
                  <span className="mt-1 text-[9px] font-bold px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                    $50 Voucher
                  </span>
                </div>

                {/* 3rd Place */}
                <div className="flex flex-col items-center text-center p-3 rounded-2xl bg-[#140a05] border border-amber-800/30 relative">
                  <div className="w-12 h-12 rounded-xl overflow-hidden bg-amber-900/40 mb-2 border border-amber-700/40">
                    <img
                      src={`https://minotar.net/helm/${TOP_VOTERS[2].name}/64.png`}
                      alt={TOP_VOTERS[2].name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-[10px] font-black text-amber-600">3RD</span>
                  <p className="text-xs font-bold text-white truncate max-w-[85px]">
                    {TOP_VOTERS[2].name}
                  </p>
                  <p className="text-[11px] font-semibold text-[#ff8c00]">
                    {TOP_VOTERS[2].votes} votes
                  </p>
                  <span className="mt-1 text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-800/10 text-amber-500">
                    $20 Voucher
                  </span>
                </div>
              </div>

              {/* Ranks 4 to 10 List */}
              <div className="space-y-2 mt-2">
                {TOP_VOTERS.slice(3).map((voter) => (
                  <div
                    key={voter.rank}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-[#120803]/80 hover:bg-[#180b05] border border-[rgba(255,120,30,0.06)] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-6 text-center text-xs font-bold text-[#8a6b58]">
                        #{voter.rank}
                      </span>
                      <img
                        src={`https://minotar.net/helm/${voter.name}/32.png`}
                        alt={voter.name}
                        className="w-7 h-7 rounded-lg border border-[rgba(255,120,30,0.15)]"
                      />
                      <span className="text-xs font-semibold text-white">
                        {voter.name}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-xs font-bold text-[#ff8c00]">
                        {voter.votes} votes
                      </span>
                      <span className="text-[10px] text-[#8a6b58] hidden sm:inline">
                        {voter.prize}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Monthly Rewards Info Box */}
              <div className="mt-6 p-4 rounded-2xl bg-[#0c0502] border border-[rgba(255,120,30,0.1)] text-center">
                <p className="text-xs text-[#a88f80]">
                  Want to be on the leaderboard? Vote on every link daily! Vouchers are sent directly via Discord ticket or in-game mail.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer (Matching MineStore dark theme) */}
      <footer className="mt-20 border-t border-[rgba(255,120,30,0.1)] bg-[#090402] py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#ff6a00] to-[#ff8c00] flex items-center justify-center shadow-md">
              <span className="material-symbols-outlined text-white text-lg">store</span>
            </div>
            <div>
              <p className="text-sm font-black text-white">{config.serverName} Network</p>
              <p className="text-xs text-[#8a6b58]">Not affiliated with Mojang Studios or Microsoft.</p>
            </div>
          </div>

          <div className="flex items-center gap-6 text-sm text-[#8a6b58]">
            <a href={STORE_URL} className="hover:text-[#ff8c00] transition-colors">Store Home</a>
            <Link href="/vote" className="text-[#ff8c00] font-bold">Vote</Link>
            <Link href="/dashboard" className="hover:text-[#ff8c00] transition-colors">Admin Dashboard</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

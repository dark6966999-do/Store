import type { Metadata } from "next";
import { Inter, Plus_Jakarta_Sans, Press_Start_2P, Space_Grotesk } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/ThemeProvider";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const plusJakartaSans = Plus_Jakarta_Sans({
  variable: "--font-plus-jakarta-sans",
  subsets: ["latin"],
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-space-grotesk",
  subsets: ["latin"],
});

const minecraft = Press_Start_2P({
  variable: "--font-minecraft",
  subsets: ["latin"],
  weight: "400",
});

export const metadata: Metadata = {
  title: "PikaNetwork | Premier Competitive Minecraft Server",
  description: "Premier Competitive PvP, SkyBlock, BedWars, GenPvP, OpPrison & Factions Minecraft Server Network. Play on 1.8 - 1.21 with zero downtime.",
  icons: {
    icon: "https://lh3.googleusercontent.com/aida/AEtjO1VbywZT5x6OFOsU8Joh984e0mL5lsWe3xnn1an8o4uBFrRmb6wCsmTURoi71xE1sa1fiFq3mwRXSpJ0U8GF2cTFSqGayZ6rGUyELVxM6PGEJr9xjDeYko8f7bF7YO2X5Y2c6j4kdsEkxIkaWz9uhTtYOIZcduqgbsInb-A3ip0snUVDcBODNy1nOYOnSyk77BkAddbn1aPCVrX1EhpurifANPWPJ_09LSoPyy5bUQiIMt7VSuX-dn5NmHk",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`dark ${inter.variable} ${plusJakartaSans.variable} ${spaceGrotesk.variable} ${minecraft.variable} h-full antialiased`}
    >
      <head>
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"
        />
      </head>
      <body className="min-h-full flex flex-col bg-bg-obsidian-void text-on-surface">
        <ThemeProvider>
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}

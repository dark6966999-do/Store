import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const categoryId = searchParams.get("category") || "";
    const subCategory = searchParams.get("subCategory") || "";
    const sortBy = searchParams.get("sortBy") || "newest"; // "trending" | "purchases" | "price_asc" | "price_desc" | "newest"
    const activeOnly = searchParams.get("active") === "true";
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "50");
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};

    if (search) {
      where.name = { contains: search };
    }

    if (categoryId) {
      where.categoryId = categoryId;
    }

    if (subCategory && subCategory !== "All") {
      where.subCategory = subCategory;
    }

    if (activeOnly) {
      where.active = true;
    }

    let orderBy: Record<string, "asc" | "desc"> = { createdAt: "desc" };
    if (sortBy === "trending" || sortBy === "purchases") {
      orderBy = { purchases: "desc" };
    } else if (sortBy === "price_asc") {
      orderBy = { price: "asc" };
    } else if (sortBy === "price_desc") {
      orderBy = { price: "desc" };
    }

    const [products, total] = await Promise.all([
      prisma.product.findMany({
        where,
        include: { category: true },
        orderBy,
        skip,
        take: limit,
      }),
      prisma.product.count({ where }),
    ]);

    return NextResponse.json({
      products,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error("Failed to fetch products:", error);
    return NextResponse.json(
      { error: "Failed to fetch products" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      description,
      price,
      originalPrice,
      subCategory,
      perks,
      purchases,
      categoryId,
      thumbnail,
      featured,
      active,
      commands
    } = body;

    if (!name || price === undefined || !categoryId) {
      return NextResponse.json(
        { error: "Name, price, and category are required" },
        { status: 400 }
      );
    }

    const product = await prisma.product.create({
      data: {
        name,
        description: description || "",
        price: parseFloat(price),
        originalPrice: originalPrice !== undefined && originalPrice !== "" ? parseFloat(originalPrice) : undefined,
        subCategory: subCategory || "Ranks",
        perks: Array.isArray(perks) ? perks : (typeof perks === "string" && perks ? JSON.parse(perks) : []),
        purchases: purchases !== undefined ? parseInt(purchases) : 0,
        categoryId,
        thumbnail: thumbnail || "",
        commands: Array.isArray(commands) ? commands : [],
        featured: featured || false,
        active: active !== false,
      },
      include: { category: true },
    });

    return NextResponse.json(product, { status: 201 });
  } catch (error) {
    console.error("Failed to create product:", error);
    return NextResponse.json(
      { error: "Failed to create product" },
      { status: 500 }
    );
  }
}

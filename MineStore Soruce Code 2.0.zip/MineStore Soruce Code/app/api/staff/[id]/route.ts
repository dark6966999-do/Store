import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const staff = await prisma.staffMember.findUnique({ where: { id } });

    if (!staff) {
      return NextResponse.json({ error: "Staff member not found" }, { status: 404 });
    }

    return NextResponse.json(staff);
  } catch (error) {
    console.error("Failed to fetch staff member:", error);
    return NextResponse.json({ error: "Failed to fetch staff member" }, { status: 500 });
  }
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const body = await request.json();

    const updated = await prisma.staffMember.update({
      where: { id },
      data: {
        ...(body.name !== undefined && { name: body.name }),
        ...(body.role !== undefined && { role: body.role }),
        ...(body.group !== undefined && { group: body.group }),
        ...(body.roleColor !== undefined && { roleColor: body.roleColor }),
        ...(body.avatarUrl !== undefined && { avatarUrl: body.avatarUrl }),
        ...(body.joinedDate !== undefined && { joinedDate: body.joinedDate }),
        ...(body.messages !== undefined && { messages: parseInt(body.messages, 10) }),
        ...(body.reactions !== undefined && { reactions: parseInt(body.reactions, 10) }),
        ...(body.points !== undefined && { points: parseInt(body.points, 10) }),
        ...(body.about !== undefined && { about: body.about }),
        ...(body.discord !== undefined && { discord: body.discord }),
        ...(body.status !== undefined && { status: body.status }),
        ...(body.order !== undefined && { order: parseInt(body.order, 10) }),
        ...(body.active !== undefined && { active: Boolean(body.active) }),
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Failed to update staff member:", error);
    return NextResponse.json({ error: "Failed to update staff member" }, { status: 500 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const deleted = await prisma.staffMember.delete({ where: { id } });

    return NextResponse.json({ success: true, deleted });
  } catch (error) {
    console.error("Failed to delete staff member:", error);
    return NextResponse.json({ error: "Failed to delete staff member" }, { status: 500 });
  }
}

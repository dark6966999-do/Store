import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const group = searchParams.get("group") || "";
    const activeOnly = searchParams.get("active") === "true";

    const where: Record<string, unknown> = {};
    if (group) where.group = group;
    if (activeOnly) where.active = true;

    const staff = await prisma.staffMember.findMany({ where });

    return NextResponse.json({ staff });
  } catch (error) {
    console.error("Failed to fetch staff members:", error);
    return NextResponse.json(
      { error: "Failed to fetch staff members" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      role,
      group,
      roleColor,
      avatarUrl,
      joinedDate,
      messages,
      reactions,
      points,
      about,
      discord,
      status,
      order,
      active,
    } = body;

    if (!name || !role) {
      return NextResponse.json(
        { error: "Name and role are required" },
        { status: 400 }
      );
    }

    const newStaff = await prisma.staffMember.create({
      data: {
        name,
        role,
        group: group || "Moderator",
        roleColor: roleColor || "#ff6a00",
        avatarUrl: avatarUrl || "",
        joinedDate: joinedDate || "",
        messages: parseInt(messages || "0", 10),
        reactions: parseInt(reactions || "0", 10),
        points: parseInt(points || "0", 10),
        about: about || "",
        discord: discord || "",
        status: status || "Online",
        order: order ? parseInt(order, 10) : undefined,
        active: active !== false,
      },
    });

    return NextResponse.json(newStaff, { status: 201 });
  } catch (error) {
    console.error("Failed to create staff member:", error);
    return NextResponse.json(
      { error: "Failed to create staff member" },
      { status: 500 }
    );
  }
}

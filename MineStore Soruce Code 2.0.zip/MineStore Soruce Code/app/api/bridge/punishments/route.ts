import { NextRequest, NextResponse } from "next/server";
import { validateBridgeAuth, unauthorizedResponse } from "@/lib/bridge-auth";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const PUNISHMENTS_FILE = path.join(DATA_DIR, "punishments.json");

export interface PunishmentRecord {
  id: string;
  serverId: string;
  serverName?: string;
  player: string;
  playerUuid: string;
  type: string; // BAN, TEMP_BAN, MUTE, TEMP_MUTE, WARN, KICK, UNBAN
  reason: string;
  staff: string;
  duration: number;
  punishmentId?: string;
  timestamp: number;
  receivedAt: string;
}

function readPunishments(): { punishments: PunishmentRecord[] } {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (!fs.existsSync(PUNISHMENTS_FILE)) {
      const init = { punishments: [] };
      fs.writeFileSync(PUNISHMENTS_FILE, JSON.stringify(init, null, 2), "utf-8");
      return init;
    }
    return JSON.parse(fs.readFileSync(PUNISHMENTS_FILE, "utf-8"));
  } catch {
    return { punishments: [] };
  }
}

function writePunishments(data: { punishments: PunishmentRecord[] }): void {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(PUNISHMENTS_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to write punishments:", err);
  }
}

/**
 * POST /api/bridge/punishments
 * Receives punishment events from any connected Minecraft server.
 */
export async function POST(req: NextRequest) {
  const auth = validateBridgeAuth(req);
  if (!auth.valid) {
    return unauthorizedResponse(auth.error!);
  }

  try {
    const body = await req.json();
    const data = readPunishments();

    const record: PunishmentRecord = {
      id: "punish_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
      serverId: auth.serverId!,
      serverName: req.headers.get("x-server-name") || body.serverName || auth.serverId!,
      player: body.player || "Unknown",
      playerUuid: body.playerUuid || "",
      type: body.type || "BAN",
      reason: body.reason || "No reason specified",
      staff: body.staff || "Console",
      duration: body.duration || 0,
      punishmentId: body.punishmentId || "",
      timestamp: body.timestamp || Date.now(),
      receivedAt: new Date().toISOString(),
    };

    // Prepend to list (latest first), cap at 1000 records
    data.punishments.unshift(record);
    if (data.punishments.length > 1000) {
      data.punishments = data.punishments.slice(0, 1000);
    }

    writePunishments(data);

    return NextResponse.json({
      success: true,
      message: "Punishment logged",
      record,
    });
  } catch (err) {
    console.error("Punishment endpoint error:", err);
    return NextResponse.json(
      { success: false, error: "Invalid request body" },
      { status: 400 }
    );
  }
}

/**
 * GET /api/bridge/punishments
 * Returns recorded punishments with optional filters (serverId, player, type).
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const serverId = searchParams.get("serverId");
  const player = searchParams.get("player");
  const type = searchParams.get("type");
  const limit = Math.min(200, parseInt(searchParams.get("limit") || "50", 10));

  const data = readPunishments();
  let list = data.punishments;

  if (serverId) {
    list = list.filter((p) => p.serverId.toLowerCase() === serverId.toLowerCase());
  }
  if (player) {
    list = list.filter((p) => p.player.toLowerCase().includes(player.toLowerCase()));
  }
  if (type) {
    list = list.filter((p) => p.type.toLowerCase() === type.toLowerCase());
  }

  return NextResponse.json({
    success: true,
    punishments: list.slice(0, limit),
    total: list.length,
  });
}

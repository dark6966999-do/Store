import { NextRequest, NextResponse } from "next/server";
import { validateBridgeAuth, unauthorizedResponse } from "@/lib/bridge-auth";
import { syncServerStatusViaRcon } from "@/lib/rcon";
import fs from "fs";
import path from "path";


/**
 * Bridge data store - separate from the main db.json
 * Stores server status, online players, and heartbeat history.
 */
const BRIDGE_DATA_DIR = path.join(process.cwd(), "data");
const BRIDGE_FILE = path.join(BRIDGE_DATA_DIR, "bridge.json");

interface ServerStatus {
  serverId: string;
  serverVersion: string;
  motd: string;
  tps1m: number;
  tps5m: number;
  tps15m: number;
  memory: {
    usedMB: number;
    totalMB: number;
    maxMB: number;
    percentUsed: number;
  };
  cpuLoad: number;
  availableProcessors: number;
  uptimeMs: number;
  uptimeFormatted: string;
  onlinePlayers: number;
  maxPlayers: number;
  totalMembersCount?: number;
  baltop?: Array<{ rank: number; playerName: string; value: string }>;
  votetop?: Array<{ rank: number; playerName: string; value: string }>;
  players: Array<{
    uuid: string;
    name: string;
    health: number;
    level: number;
    world: string;
    gameMode: string;
    sessionDurationMs?: number;
  }>;
  worlds: Array<{
    name: string;
    players: number;
    loadedChunks: number;
    entities: number;
    environment: string;
  }>;
  timestamp: number;
  lastHeartbeat: string;
}

interface BridgeData {
  servers: Record<string, ServerStatus>;
  lastUpdated: string;
}

function readBridgeData(): BridgeData {
  try {
    if (!fs.existsSync(BRIDGE_DATA_DIR)) {
      fs.mkdirSync(BRIDGE_DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(BRIDGE_FILE)) {
      const defaultData: BridgeData = { servers: {}, lastUpdated: new Date().toISOString() };
      fs.writeFileSync(BRIDGE_FILE, JSON.stringify(defaultData, null, 2), "utf-8");
      return defaultData;
    }
    return JSON.parse(fs.readFileSync(BRIDGE_FILE, "utf-8"));
  } catch {
    return { servers: {}, lastUpdated: new Date().toISOString() };
  }
}

function writeBridgeData(data: BridgeData): void {
  try {
    if (!fs.existsSync(BRIDGE_DATA_DIR)) {
      fs.mkdirSync(BRIDGE_DATA_DIR, { recursive: true });
    }
    data.lastUpdated = new Date().toISOString();
    fs.writeFileSync(BRIDGE_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to write bridge data:", err);
  }
}

/**
 * POST /api/bridge/heartbeat
 * Receives heartbeat data from the Minecraft plugin.
 */
export async function POST(req: NextRequest) {
  const auth = validateBridgeAuth(req);
  if (!auth.valid) {
    return unauthorizedResponse(auth.error!);
  }

  try {
    const body = await req.json();
    const data = readBridgeData();

    // Update server status
    data.servers[auth.serverId!] = {
      ...body,
      serverId: auth.serverId,
      lastHeartbeat: new Date().toISOString(),
    };

    writeBridgeData(data);

    return NextResponse.json({
      success: true,
      message: "Heartbeat received",
      serverTime: new Date().toISOString(),
    });
  } catch (err) {
    console.error("Heartbeat error:", err);
    return NextResponse.json(
      { success: false, error: "Invalid request body" },
      { status: 400 }
    );
  }
}

/**
 * GET /api/bridge/heartbeat
 * Returns the current status of all connected servers (for dashboard).
 * Queries Minecraft server via RCON if available.
 */
export async function GET(req: NextRequest) {
  // Sync status via RCON if server is accessible
  let rcon: { online: boolean; onlinePlayers?: number } = { online: false };
  try {
    const result = await syncServerStatusViaRcon();
    if (result.online && typeof result.status?.onlinePlayers === "number") {
      rcon = { online: true, onlinePlayers: result.status.onlinePlayers };
    }
  } catch (err) {
    // Non-blocking fallback to cached data
  }

  const data = readBridgeData();

  // Check for stale servers (no heartbeat in 60s)
  const now = Date.now();
  for (const [id, server] of Object.entries(data.servers)) {
    const lastBeat = new Date(server.lastHeartbeat).getTime();
    if (!Number.isFinite(lastBeat) || now - lastBeat > 60000) {
      // Mark as potentially offline but keep data
      (data.servers[id] as any)._stale = true;
    }
  }

  return NextResponse.json({
    success: true,
    servers: data.servers,
    lastUpdated: data.lastUpdated,
    rcon,
  });
}


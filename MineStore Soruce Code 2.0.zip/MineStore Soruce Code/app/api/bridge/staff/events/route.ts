import { NextRequest, NextResponse } from "next/server";
import { validateBridgeAuth, unauthorizedResponse } from "@/lib/bridge-auth";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const STAFF_ONLINE_FILE = path.join(DATA_DIR, "staff_online.json");

function readStaffOnline(): Record<string, Record<string, any>> {
  // Structure: { [serverId]: { [uuid]: { name, group, status, joinTime } } }
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (!fs.existsSync(STAFF_ONLINE_FILE)) {
      const init = {};
      fs.writeFileSync(STAFF_ONLINE_FILE, JSON.stringify(init, null, 2), "utf-8");
      return init;
    }
    return JSON.parse(fs.readFileSync(STAFF_ONLINE_FILE, "utf-8"));
  } catch {
    return {};
  }
}

function writeStaffOnline(data: Record<string, Record<string, any>>): void {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(STAFF_ONLINE_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to write staff online:", err);
  }
}

/**
 * POST /api/bridge/staff/events
 * Receives staff join/leave events.
 */
export async function POST(req: NextRequest) {
  const auth = validateBridgeAuth(req);
  if (!auth.valid) {
    return unauthorizedResponse(auth.error!);
  }

  try {
    const body = await req.json();
    const { event, username, uuid, group, status, joinTime } = body;
    const serverId = auth.serverId!;

    const data = readStaffOnline();
    if (!data[serverId]) {
      data[serverId] = {};
    }

    if (event === "staff_leave") {
      delete data[serverId][uuid];
    } else {
      data[serverId][uuid] = {
        name: username,
        group,
        status: status || "ONLINE",
        joinTime: joinTime || Date.now(),
        lastSeen: new Date().toISOString(),
      };
    }

    writeStaffOnline(data);

    return NextResponse.json({
      success: true,
      message: `Staff event '${event}' logged for ${username} on ${serverId}`,
    });
  } catch (err) {
    return NextResponse.json({ success: false, error: "Invalid request body" }, { status: 400 });
  }
}

/**
 * GET /api/bridge/staff/events
 * Returns currently online staff across all servers or for a specific server.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const serverId = searchParams.get("serverId");

  const data = readStaffOnline();

  if (serverId) {
    return NextResponse.json({ success: true, staff: data[serverId] || {} });
  }

  return NextResponse.json({ success: true, staff: data });
}

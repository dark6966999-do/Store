import { NextRequest, NextResponse } from "next/server";
import { validateBridgeAuth, unauthorizedResponse } from "@/lib/bridge-auth";

/**
 * POST /api/bridge/staff/sync
 * Receives online staff data from the Minecraft plugin.
 * The plugin sends a list of currently online staff with their groups.
 */
export async function POST(req: NextRequest) {
  const auth = validateBridgeAuth(req);
  if (!auth.valid) {
    return unauthorizedResponse(auth.error!);
  }

  try {
    const body = await req.json();

    // For now, just acknowledge the sync
    // The primary staff data is managed via the dashboard CRUD
    // This endpoint receives real-time online/offline status updates
    const onlineStaff = body.onlineStaff || [];

    return NextResponse.json({
      success: true,
      message: `Staff sync received: ${onlineStaff.length} staff online`,
      serverId: auth.serverId,
    });
  } catch (err) {
    console.error("Staff sync error:", err);
    return NextResponse.json(
      { success: false, error: "Invalid request body" },
      { status: 400 }
    );
  }
}

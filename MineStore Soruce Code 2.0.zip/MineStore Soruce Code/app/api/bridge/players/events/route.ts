import { NextRequest, NextResponse } from "next/server";
import { validateBridgeAuth, unauthorizedResponse } from "@/lib/bridge-auth";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const BRIDGE_FILE = path.join(DATA_DIR, "bridge.json");

/**
 * POST /api/bridge/players/events
 * Receives real-time player join/leave events.
 */
export async function POST(req: NextRequest) {
  const auth = validateBridgeAuth(req);
  if (!auth.valid) {
    return unauthorizedResponse(auth.error!);
  }

  try {
    const body = await req.json();
    const { event, username, uuid, onlineCount, maxSlots } = body;
    const serverId = auth.serverId!;

    // Update player counts in bridge.json if available
    if (fs.existsSync(BRIDGE_FILE)) {
      try {
        const data = JSON.parse(fs.readFileSync(BRIDGE_FILE, "utf-8"));
        if (data.servers && data.servers[serverId]) {
          if (typeof onlineCount === "number") {
            data.servers[serverId].onlinePlayers = onlineCount;
          }
          if (typeof maxSlots === "number") {
            data.servers[serverId].maxPlayers = maxSlots;
          }
          data.servers[serverId].lastHeartbeat = new Date().toISOString();
          fs.writeFileSync(BRIDGE_FILE, JSON.stringify(data, null, 2), "utf-8");
        }
      } catch (err) {
        console.error("Failed to update bridge.json on player event:", err);
      }
    }

    return NextResponse.json({
      success: true,
      message: `Player event '${event}' logged for ${username} on ${serverId}`,
    });
  } catch (err) {
    return NextResponse.json({ success: false, error: "Invalid request body" }, { status: 400 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { validateBridgeAuth, unauthorizedResponse } from "@/lib/bridge-auth";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const DELIVERIES_FILE = path.join(DATA_DIR, "deliveries.json");

interface Delivery {
  id: string;
  orderId: string;
  playerName: string;
  playerUuid: string;
  commands: string[];
  requireOnline: boolean;
  status: "pending" | "completed" | "failed";
  serverId?: string;
  error?: string;
  consoleOutput?: string;
  createdAt: string;
  completedAt?: string;
}

function readDeliveries(): { deliveries: Delivery[] } {
  try {
    if (!fs.existsSync(DELIVERIES_FILE)) return { deliveries: [] };
    return JSON.parse(fs.readFileSync(DELIVERIES_FILE, "utf-8"));
  } catch {
    return { deliveries: [] };
  }
}

function writeDeliveries(data: { deliveries: Delivery[] }): void {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(DELIVERIES_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to write deliveries:", err);
  }
}

/**
 * POST /api/bridge/deliveries/confirm
 * Called by the Minecraft plugin to confirm delivery status.
 */
export async function POST(req: NextRequest) {
  const auth = validateBridgeAuth(req);
  if (!auth.valid) {
    return unauthorizedResponse(auth.error!);
  }

  try {
    const body = await req.json();
    const { deliveryId, status, error, consoleOutput } = body;

    if (!deliveryId || !status) {
      return NextResponse.json(
        { success: false, error: "Missing deliveryId or status" },
        { status: 400 }
      );
    }

    const data = readDeliveries();
    const idx = data.deliveries.findIndex((d) => d.id === deliveryId);

    if (idx === -1) {
      return NextResponse.json(
        { success: false, error: "Delivery not found" },
        { status: 404 }
      );
    }

    data.deliveries[idx].status = status;
    data.deliveries[idx].completedAt = new Date().toISOString();
    if (error) {
      data.deliveries[idx].error = error;
    }
    if (consoleOutput) {
      data.deliveries[idx].consoleOutput = consoleOutput;
    }

    writeDeliveries(data);

    return NextResponse.json({
      success: true,
      message: `Delivery ${deliveryId} marked as ${status}`,
    });
  } catch (err) {
    console.error("Confirm delivery error:", err);
    return NextResponse.json(
      { success: false, error: "Invalid request body" },
      { status: 400 }
    );
  }
}

import { NextRequest, NextResponse } from "next/server";
import { validateBridgeAuth, unauthorizedResponse } from "@/lib/bridge-auth";
import { executeRconCommand } from "@/lib/rcon";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const DELIVERIES_FILE = path.join(DATA_DIR, "deliveries.json");

interface Delivery {
  id: string;
  orderId: string;
  playerName: string;
  playerUuid: string;
  commands: string[];
  requireOnline: boolean;
  status: "pending" | "completed" | "failed";
  serverId?: string;
  error?: string;
  createdAt: string;
  completedAt?: string;
  executionLogs?: string[];
}

interface DeliveriesData {
  deliveries: Delivery[];
}

function readDeliveries(): DeliveriesData {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (!fs.existsSync(DELIVERIES_FILE)) {
      const defaultData: DeliveriesData = { deliveries: [] };
      fs.writeFileSync(DELIVERIES_FILE, JSON.stringify(defaultData, null, 2), "utf-8");
      return defaultData;
    }
    return JSON.parse(fs.readFileSync(DELIVERIES_FILE, "utf-8"));
  } catch {
    return { deliveries: [] };
  }
}

function writeDeliveries(data: DeliveriesData): void {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(DELIVERIES_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to write deliveries:", err);
  }
}

function generateId(): string {
  return `del_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 7)}`;
}

/**
 * GET /api/bridge/deliveries/pending
 * Returns pending deliveries for the requesting server.
 */
export async function GET(req: NextRequest) {
  const auth = validateBridgeAuth(req);
  if (!auth.valid) {
    return unauthorizedResponse(auth.error!);
  }

  const data = readDeliveries();
  const pending = data.deliveries.filter(
    (d) => d.status === "pending" && (!d.serverId || d.serverId === auth.serverId)
  );

  return NextResponse.json({
    success: true,
    deliveries: pending,
  });
}

/**
 * POST /api/bridge/deliveries
 * Creates a new delivery and attempts instant RCON execution.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = readDeliveries();

    const newDelivery: Delivery = {
      id: generateId(),
      orderId: body.orderId || "manual",
      playerName: body.playerName,
      playerUuid: body.playerUuid || "",
      commands: body.commands || [],
      requireOnline: body.requireOnline ?? false,
      status: "pending",
      serverId: body.serverId || undefined,
      createdAt: new Date().toISOString(),
      executionLogs: [],
    };

    // Instant RCON delivery attempt
    if (newDelivery.commands.length > 0) {
      let allSucceeded = true;
      for (const rawCmd of newDelivery.commands) {
        const cmd = rawCmd.replace(/{player}|{username}/gi, newDelivery.playerName);
        const rconRes = await executeRconCommand(cmd);
        newDelivery.executionLogs?.push(`${cmd} -> ${rconRes.response || rconRes.error}`);
        if (!rconRes.success) {
          allSucceeded = false;
        }
      }

      if (allSucceeded) {
        newDelivery.status = "completed";
        newDelivery.completedAt = new Date().toISOString();
      }
    }

    data.deliveries.unshift(newDelivery);
    writeDeliveries(data);

    return NextResponse.json({
      success: true,
      delivery: newDelivery,
    });
  } catch (err) {
    console.error("Create delivery error:", err);
    return NextResponse.json(
      { success: false, error: "Invalid request body" },
      { status: 400 }
    );
  }
}


import { NextRequest, NextResponse } from "next/server";
import { validateBridgeAuth, unauthorizedResponse } from "@/lib/bridge-auth";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const LEADERBOARDS_FILE = path.join(DATA_DIR, "leaderboards.json");

export interface LeaderboardEntry {
  rank: number;
  playerName: string;
  value: string;
}

export interface LeaderboardData {
  serverId: string;
  serverName: string;
  name: string;
  command: string;
  entries: LeaderboardEntry[];
  rawLines: string[];
  updatedAt: string;
}

function readLeaderboards(): Record<string, Record<string, LeaderboardData>> {
  // Structure: { [serverId]: { [leaderboardName]: LeaderboardData } }
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (!fs.existsSync(LEADERBOARDS_FILE)) {
      const init = {};
      fs.writeFileSync(LEADERBOARDS_FILE, JSON.stringify(init, null, 2), "utf-8");
      return init;
    }
    return JSON.parse(fs.readFileSync(LEADERBOARDS_FILE, "utf-8"));
  } catch {
    return {};
  }
}

function writeLeaderboards(data: Record<string, Record<string, LeaderboardData>>): void {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(LEADERBOARDS_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to write leaderboards:", err);
  }
}

/**
 * POST /api/bridge/leaderboards
 * Receives scheduled command leaderboard results from a Minecraft server.
 */
export async function POST(req: NextRequest) {
  const auth = validateBridgeAuth(req);
  if (!auth.valid) {
    return unauthorizedResponse(auth.error!);
  }

  try {
    const body = await req.json();
    const { name, command, entries, rawLines } = body;

    if (!name) {
      return NextResponse.json({ success: false, error: "Missing leaderboard name" }, { status: 400 });
    }

    const data = readLeaderboards();
    const serverId = auth.serverId!;
    if (!data[serverId]) {
      data[serverId] = {};
    }

    data[serverId][name] = {
      serverId,
      serverName: req.headers.get("x-server-name") || body.serverName || serverId,
      name,
      command: command || "",
      entries: entries || [],
      rawLines: rawLines || [],
      updatedAt: new Date().toISOString(),
    };

    writeLeaderboards(data);

    return NextResponse.json({
      success: true,
      message: `Leaderboard '${name}' updated for server ${serverId}`,
    });
  } catch (err) {
    console.error("Leaderboard endpoint error:", err);
    return NextResponse.json({ success: false, error: "Invalid request body" }, { status: 400 });
  }
}

/**
 * GET /api/bridge/leaderboards
 * Returns leaderboards for a specific server or all servers.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const serverId = searchParams.get("serverId");
  const name = searchParams.get("name");

  const data = readLeaderboards();

  if (serverId && name) {
    const result = data[serverId]?.[name] || null;
    return NextResponse.json({ success: true, leaderboard: result });
  }

  if (serverId) {
    const serverBoards = data[serverId] || {};
    return NextResponse.json({ success: true, leaderboards: serverBoards });
  }

  return NextResponse.json({ success: true, leaderboards: data });
}

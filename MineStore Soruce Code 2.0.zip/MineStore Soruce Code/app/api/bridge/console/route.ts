import { NextRequest, NextResponse } from "next/server";
import { validateBridgeAuth, unauthorizedResponse } from "@/lib/bridge-auth";
import { executeRconCommand } from "@/lib/rcon";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const CONSOLE_FILE = path.join(DATA_DIR, "console.json");

import { scanConsoleLogsForPunishments } from "@/lib/punishments";

interface PendingCommand {
  id: string;
  command: string;
  serverId?: string;
  executedBy: string;
  timestamp: number;
}

interface ConsoleData {
  logs: string[];
  commandHistory: Array<{
    command: string;
    executedBy: string;
    timestamp: string;
    result?: string;
  }>;
  pendingCommands?: PendingCommand[];
}

function readConsoleData(): ConsoleData {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (!fs.existsSync(CONSOLE_FILE)) {
      const defaultData: ConsoleData = { logs: [], commandHistory: [], pendingCommands: [] };
      fs.writeFileSync(CONSOLE_FILE, JSON.stringify(defaultData, null, 2), "utf-8");
      return defaultData;
    }
    const data = JSON.parse(fs.readFileSync(CONSOLE_FILE, "utf-8"));
    if (!data.pendingCommands) data.pendingCommands = [];
    return data;
  } catch {
    return { logs: [], commandHistory: [], pendingCommands: [] };
  }
}

function writeConsoleData(data: ConsoleData): void {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(CONSOLE_FILE, JSON.stringify(data, null, 2), "utf-8");
    // Trigger real-time punishment log scan
    try {
      scanConsoleLogsForPunishments();
    } catch {}
  } catch (err) {
    console.error("Failed to write console data:", err);
  }
}

/**
 * POST /api/bridge/console
 * Receives console log lines from the plugin OR
 * sends commands to be executed on the server via RCON.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // If this is a command execution request (from dashboard)
    if (body.action === "execute" && body.command) {
      const data = readConsoleData();
      const command = body.command.trim();
      const timestamp = new Date().toLocaleTimeString();

      // Log input command
      data.logs.push(`[${timestamp}] [CONSOLE-INPUT] > ${command}`);

      // 1. Execute via RCON directly
      const rconRes = await executeRconCommand(command);

      let responseText = "";
      if (rconRes.success) {
        responseText = rconRes.response;
        const prefix = `[${timestamp}] [CONSOLE-OUTPUT] `;
        const outLines = responseText.split("\n").map((l: string) => `${prefix}${l.trim()}`).filter(Boolean);
        data.logs.push(...outLines);
      } else {
        responseText = `[RCON] ${rconRes.error || "Execution failed"}`;
        data.logs.push(`[${timestamp}] [ERROR] ${responseText}`);
      }

      // 2. Also keep in command history
      data.commandHistory.unshift({
        command,
        executedBy: body.executedBy || "Dashboard",
        timestamp: new Date().toISOString(),
        result: responseText,
      });

      if (data.commandHistory.length > 200) {
        data.commandHistory = data.commandHistory.slice(0, 200);
      }
      if (data.logs.length > 2500) {
        data.logs = data.logs.slice(-2500);
      }

      writeConsoleData(data);

      return NextResponse.json({
        success: rconRes.success,
        message: rconRes.success ? "Command executed via RCON" : "Command execution error",
        output: responseText,
        command,
      });
    }

    // If this is log data from the plugin
    const auth = validateBridgeAuth(req);

    if (!auth.valid) {
      return unauthorizedResponse(auth.error!);
    }

    if (body.logs) {
      const data = readConsoleData();
      let newLines: string[] = [];

      if (Array.isArray(body.logs)) {
        newLines = body.logs.map((l: any) => String(l).trim()).filter(Boolean);
      } else if (typeof body.logs === "string") {
        newLines = body.logs.split("\n").map((l: string) => l.trim()).filter(Boolean);
      }

      if (newLines.length > 0) {
        data.logs.push(...newLines);

        // Keep only last 2500 lines
        if (data.logs.length > 2500) {
          data.logs = data.logs.slice(-2500);
        }

        writeConsoleData(data);
      }
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Console endpoint error:", err);
    return NextResponse.json(
      { success: false, error: "Invalid request body: " + String(err) },
      { status: 400 }
    );
  }
}

/**
 * GET /api/bridge/console
 * Returns console logs and command history (for dashboard).
 */
export async function GET(req: NextRequest) {
  const data = readConsoleData();

  const url = new URL(req.url);
  const limit = parseInt(url.searchParams.get("limit") || "200");
  const offset = parseInt(url.searchParams.get("offset") || "0");

  return NextResponse.json({
    success: true,
    logs: data.logs.slice(-(offset + limit), offset > 0 ? -offset : undefined),
    commandHistory: data.commandHistory.slice(0, 50),
    totalLines: data.logs.length,
  });
}


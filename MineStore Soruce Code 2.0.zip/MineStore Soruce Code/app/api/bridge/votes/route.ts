import { NextRequest, NextResponse } from "next/server";
import { validateBridgeAuth, unauthorizedResponse } from "@/lib/bridge-auth";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const VOTES_FILE = path.join(DATA_DIR, "votes.json");

interface Vote {
  id: string;
  playerName: string;
  serviceName: string;
  address: string;
  serverId: string;
  timestamp: string;
  createdAt: string;
}

interface VotesData {
  votes: Vote[];
  totalVotes: number;
}

function readVotes(): VotesData {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (!fs.existsSync(VOTES_FILE)) {
      const defaultData: VotesData = { votes: [], totalVotes: 0 };
      fs.writeFileSync(VOTES_FILE, JSON.stringify(defaultData, null, 2), "utf-8");
      return defaultData;
    }
    return JSON.parse(fs.readFileSync(VOTES_FILE, "utf-8"));
  } catch {
    return { votes: [], totalVotes: 0 };
  }
}

function writeVotes(data: VotesData): void {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(VOTES_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to write votes:", err);
  }
}

function generateId(): string {
  return `vote_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 7)}`;
}

/**
 * POST /api/bridge/votes
 * Records a vote from the Minecraft plugin.
 */
export async function POST(req: NextRequest) {
  const auth = validateBridgeAuth(req);
  if (!auth.valid) {
    return unauthorizedResponse(auth.error!);
  }

  try {
    const body = await req.json();

    const data = readVotes();
    const newVote: Vote = {
      id: generateId(),
      playerName: body.playerName || "Unknown",
      serviceName: body.serviceName || "Unknown",
      address: body.address || "",
      serverId: auth.serverId!,
      timestamp: body.timestamp || new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    data.votes.unshift(newVote);
    data.totalVotes++;

    // Keep only last 1000 votes in file
    if (data.votes.length > 1000) {
      data.votes = data.votes.slice(0, 1000);
    }

    writeVotes(data);

    return NextResponse.json({
      success: true,
      vote: newVote,
    });
  } catch (err) {
    console.error("Vote recording error:", err);
    return NextResponse.json(
      { success: false, error: "Invalid request body" },
      { status: 400 }
    );
  }
}

/**
 * GET /api/bridge/votes
 * Returns vote data (for dashboard).
 */
export async function GET(req: NextRequest) {
  const data = readVotes();

  // Calculate stats
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const weekStart = todayStart - 6 * 24 * 60 * 60 * 1000;

  const todayVotes = data.votes.filter(
    (v) => new Date(v.createdAt).getTime() >= todayStart
  ).length;

  const weekVotes = data.votes.filter(
    (v) => new Date(v.createdAt).getTime() >= weekStart
  ).length;

  // Top voters (last 30 days)
  const thirtyDaysAgo = todayStart - 29 * 24 * 60 * 60 * 1000;
  const recentVotes = data.votes.filter(
    (v) => new Date(v.createdAt).getTime() >= thirtyDaysAgo
  );
  const voterCounts: Record<string, number> = {};
  for (const v of recentVotes) {
    voterCounts[v.playerName] = (voterCounts[v.playerName] || 0) + 1;
  }
  const topVoters = Object.entries(voterCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([name, count]) => ({ name, count }));

  return NextResponse.json({
    success: true,
    totalVotes: data.totalVotes,
    todayVotes,
    weekVotes,
    topVoters,
    recentVotes: data.votes.slice(0, 50),
  });
}

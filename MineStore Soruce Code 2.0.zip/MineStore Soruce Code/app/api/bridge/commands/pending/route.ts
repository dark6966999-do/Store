import { NextRequest, NextResponse } from "next/server";
import { validateBridgeAuth, unauthorizedResponse } from "@/lib/bridge-auth";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const CONSOLE_FILE = path.join(DATA_DIR, "console.json");

/**
 * GET /api/bridge/commands/pending
 * Called by the Minecraft plugin to retrieve commands queued from the web dashboard.
 */
export async function GET(req: NextRequest) {
  const auth = validateBridgeAuth(req);
  if (!auth.valid) {
    return unauthorizedResponse(auth.error!);
  }

  const serverId = auth.serverId || "survival-01";

  try {
    if (!fs.existsSync(CONSOLE_FILE)) {
      return NextResponse.json({ success: true, commands: [] });
    }

    const data = JSON.parse(fs.readFileSync(CONSOLE_FILE, "utf-8"));
    const pending = (data.pendingCommands || []).filter(
      (cmd: any) => !cmd.serverId || cmd.serverId === serverId || cmd.serverId === "all"
    );

    // Remove retrieved commands from pending queue
    if (pending.length > 0) {
      const retrievedIds = new Set(pending.map((c: any) => c.id));
      data.pendingCommands = (data.pendingCommands || []).filter(
        (cmd: any) => !retrievedIds.has(cmd.id)
      );
      fs.writeFileSync(CONSOLE_FILE, JSON.stringify(data, null, 2), "utf-8");
    }

    return NextResponse.json({
      success: true,
      commands: pending,
    });
  } catch (err) {
    console.error("Error fetching pending commands:", err);
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}

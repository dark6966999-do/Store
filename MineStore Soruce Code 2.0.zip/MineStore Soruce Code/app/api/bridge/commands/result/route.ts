import { NextRequest, NextResponse } from "next/server";
import { validateBridgeAuth, unauthorizedResponse } from "@/lib/bridge-auth";
import fs from "fs";
import path from "path";
import { scanConsoleLogsForPunishments } from "@/lib/punishments";

const DATA_DIR = path.join(process.cwd(), "data");
const CONSOLE_FILE = path.join(DATA_DIR, "console.json");

/**
 * POST /api/bridge/commands/result
 * Called by the Minecraft plugin after executing a remote command.
 */
export async function POST(req: NextRequest) {
  const auth = validateBridgeAuth(req);
  if (!auth.valid) {
    return unauthorizedResponse(auth.error!);
  }

  try {
    const body = await req.json();
    const { commandId, success, output } = body;

    if (!fs.existsSync(CONSOLE_FILE)) {
      return NextResponse.json({ success: true });
    }

    const data = JSON.parse(fs.readFileSync(CONSOLE_FILE, "utf-8"));

    // Add output lines to console logs
    if (output) {
      const timestamp = new Date().toLocaleTimeString();
      const prefix = `[${timestamp}] [CONSOLE-OUTPUT] `;
      const outputLines = output.split("\n").map((line: string) => `${prefix}${line.trim()}`).filter(Boolean);
      data.logs.push(...outputLines);
      if (data.logs.length > 2500) {
        data.logs = data.logs.slice(-2500);
      }
    }

    // Update command history entry if matching
    if (data.commandHistory && data.commandHistory.length > 0) {
      if (commandId) {
        const found = data.commandHistory.find((c: any) => c.commandId === commandId);
        if (found) {
          found.result = output || (success ? "Success" : "Failed");
        } else {
          data.commandHistory[0].result = output || (success ? "Success" : "Failed");
        }
      } else {
        data.commandHistory[0].result = output || (success ? "Success" : "Failed");
      }
    }

    fs.writeFileSync(CONSOLE_FILE, JSON.stringify(data, null, 2), "utf-8");
    scanConsoleLogsForPunishments();

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Error saving command result:", err);
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}

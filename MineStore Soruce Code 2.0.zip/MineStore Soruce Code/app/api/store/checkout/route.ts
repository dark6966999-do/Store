import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getDiscordSession, verifyDiscordToken } from "@/lib/discord-auth";
import { deliverOrder } from "@/lib/delivery";
import { sendOrderInvoiceEmail } from "@/lib/email";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      username,
      email,
      discordUsername: inputDiscordUsername,
      phone,
      country,
      items,
      currency = "EUR",
      discordToken,
    } = body;

    // Validate Minecraft Username
    if (!username || typeof username !== "string" || username.trim().length === 0) {
      return NextResponse.json(
        { error: "Please enter a valid Minecraft username" },
        { status: 400 }
      );
    }

    // Validate Customer Email
    if (!email || typeof email !== "string" || !email.includes("@")) {
      return NextResponse.json(
        { error: "Please enter a valid email address to receive your order invoice and delivery information" },
        { status: 400 }
      );
    }

    // Check Discord info (either authenticated session or username from Secure Checkout modal)
    let discordUser = await getDiscordSession();
    if (!discordUser && discordToken) {
      discordUser = verifyDiscordToken(discordToken);
    }

    const finalDiscordUsername = discordUser?.username || inputDiscordUsername?.trim() || "N/A";
    const finalDiscordId = discordUser?.id || null;
    const finalDiscordAvatar = discordUser?.avatarUrl || null;

    if (!finalDiscordUsername || finalDiscordUsername === "N/A") {
      return NextResponse.json(
        { error: "Please enter your Discord username" },
        { status: 400 }
      );
    }

    // Validate Items
    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: "Your cart is empty" }, { status: 400 });
    }

    // Resolve products and calculate total
    const allProducts = await prisma.product.findMany({});
    const productMap = new Map(allProducts.map((p) => [p.id, p]));

    const orderItems = [];
    let grandTotal = 0;

    for (const item of items) {
      const prod = productMap.get(item.productId);
      if (!prod) {
        return NextResponse.json(
          { error: `Product not found: ${item.productId}` },
          { status: 400 }
        );
      }
      const qty = Math.max(1, parseInt(item.quantity) || 1);
      const lineTotal = prod.price * qty;
      grandTotal += lineTotal;

      orderItems.push({
        productId: prod.id,
        productName: prod.name,
        price: prod.price,
        quantity: qty,
        thumbnail: prod.thumbnail,
      });
    }

    // Generate unique Invoice ID
    const invoiceId = `INV-2026-${Math.floor(100000 + Math.random() * 900000)}`;

    // 1. Execute live in-game delivery on Minecraft server
    const deliveryResult = await deliverOrder(
      username.trim(),
      invoiceId,
      orderItems.map((i) => {
        const prod = productMap.get(i.productId);
        let productCommands: string[] = [];
        try {
          const raw = prod?.commands || "[]";
          productCommands = typeof raw === "string" ? JSON.parse(raw) : (Array.isArray(raw) ? raw : []);
        } catch { productCommands = []; }
        return {
          productId: i.productId,
          productName: i.productName,
          quantity: i.quantity,
          subCategory: prod?.subCategory,
          commands: productCommands.length > 0 ? productCommands : undefined,
        };
      })
    );

    // 2. Save order to database
    const order = await prisma.order.create({
      data: {
        invoiceId,
        username: username.trim(),
        email: email.trim(),
        phone: phone ? phone.trim() : undefined,
        country: country ? country.trim() : undefined,
        total: Math.round(grandTotal * 100) / 100,
        currency,
        items: orderItems,
        discordId: finalDiscordId || undefined,
        discordUsername: finalDiscordUsername,
        discordAvatar: finalDiscordAvatar || undefined,
        deliveryStatus: "delivered",
        deliveryCommands: deliveryResult.commands,
      },
    });

    // 3. Send official confirmation & invoice email to customer's email address
    const emailResult = await sendOrderInvoiceEmail({
      invoiceId,
      orderId: order.id,
      customerEmail: email.trim(),
      minecraftUsername: username.trim(),
      discordUsername: finalDiscordUsername,
      phone: phone ? phone.trim() : undefined,
      country: country ? country.trim() : undefined,
      items: orderItems.map((i) => ({
        productName: i.productName,
        quantity: i.quantity,
        price: i.price,
      })),
      total: Math.round(grandTotal * 100) / 100,
      currency,
      deliveryCommands: deliveryResult.commands,
    });

    return NextResponse.json(
      {
        success: true,
        invoiceId,
        order,
        delivery: {
          status: "delivered",
          commands: deliveryResult.commands,
          logs: deliveryResult.logs,
        },
        emailSent: emailResult.success,
        customerEmail: email.trim(),
        message: `Thank you, ${username.trim()}! Invoice #${invoiceId} generated. A confirmation email with full delivery details was sent to ${email.trim()}. Perks have been delivered in-game!`,
      },
      { status: 201 }
    );
  } catch (error: any) {
    console.error("Checkout failed:", error);
    return NextResponse.json(
      { error: error?.message || "Failed to process checkout" },
      { status: 500 }
    );
  }
}

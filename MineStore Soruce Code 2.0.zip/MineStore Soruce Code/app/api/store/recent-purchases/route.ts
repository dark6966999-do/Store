import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const orders = await prisma.order.findMany({
      orderBy: { createdAt: "desc" },
      take: 10,
    });

    const recent = orders.map((order) => {
      const firstItem = order.items?.[0];
      return {
        id: order.id,
        username: order.username,
        avatarUrl: `https://minotar.net/helm/${encodeURIComponent(order.username)}/64.png`,
        productName: firstItem ? firstItem.productName : "Store Package",
        total: order.total,
        currency: order.currency,
        createdAt: order.createdAt,
      };
    });

    return NextResponse.json(recent);
  } catch (error) {
    console.error("Failed to fetch recent purchases:", error);
    return NextResponse.json([], { status: 500 });
  }
}

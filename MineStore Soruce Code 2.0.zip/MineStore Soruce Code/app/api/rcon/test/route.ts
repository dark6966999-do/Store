import { NextRequest, NextResponse } from "next/server";
import { executeRconCommand, syncServerStatusViaRcon, getRconConfig } from "@/lib/rcon";
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const RCON_CONFIG_FILE = path.join(DATA_DIR, "rcon.json");

/**
 * GET /api/rcon/test
 * Tests current RCON connection and triggers a full server status sync.
 */
export async function GET() {
  const config = getRconConfig();
  const syncResult = await syncServerStatusViaRcon();

  if (syncResult.online) {
    return NextResponse.json({
      success: true,
      message: `Successfully connected to Minecraft server via RCON (${config.host}:${config.port})`,
      status: syncResult.status,
    });
  } else {
    return NextResponse.json({
      success: false,
      message: `Failed to connect to Minecraft server via RCON at ${config.host}:${config.port}`,
      error: syncResult.error,
      config: {
        host: config.host,
        port: config.port,
      },
    }, { status: 502 });
  }
}

/**
 * POST /api/rcon/test
 * Updates RCON credentials and validates them against the Minecraft server.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const host = body.host || "127.0.0.1";
    const port = parseInt(body.port || "25575");
    const password = body.password;
    const serverId = body.serverId || "survival-01";
    const serverName = body.serverName || "Survival";

    if (!password) {
      return NextResponse.json({ success: false, error: "RCON password is required" }, { status: 400 });
    }

    // Test connection with provided credentials
    const testResult = await executeRconCommand("list", { host, port, password });
    if (!testResult.success) {
      return NextResponse.json({
        success: false,
        error: `Could not connect to ${host}:${port} - ${testResult.error}`,
      }, { status: 502 });
    }

    // Save verified configuration to data/rcon.json
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(RCON_CONFIG_FILE, JSON.stringify({
      host,
      port,
      password,
      serverId,
      serverName,
      updatedAt: new Date().toISOString(),
    }, null, 2), "utf-8");

    // Immediately sync server status
    const status = await syncServerStatusViaRcon();

    return NextResponse.json({
      success: true,
      message: "RCON connection verified and saved successfully!",
      output: testResult.response,
      status: status.status,
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

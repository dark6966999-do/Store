import { NextResponse } from "next/server";
import { readTheme, writeTheme } from "@/lib/theme";
import { getSession } from "@/lib/auth";

export async function GET() {
  try {
    const theme = readTheme();
    return NextResponse.json(theme);
  } catch (error) {
    console.error("Failed to fetch theme config:", error);
    return NextResponse.json(
      { error: "Failed to fetch theme config" },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const current = readTheme();

    const updated = {
      ...current,
      ...body,
      updatedAt: new Date().toISOString(),
    };

    writeTheme(updated);
    return NextResponse.json(updated);
  } catch (error) {
    console.error("Failed to update theme config:", error);
    return NextResponse.json(
      { error: "Failed to update theme config" },
      { status: 500 }
    );
  }
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export async function GET() {
  try {
    let config = await prisma.storeConfig.findUnique({ where: { id: "main" } });

    if (!config) {
      config = await prisma.storeConfig.create({
        data: {
          id: "main",
          serverIp: "play.pika-network.net",
          serverName: "PikaNetwork",
          logoUrl: "/logo.png",
          discordUrl: "",
          forumUrl: "",
          voteLinks: "[]",
          socialLinks: "{}",
        },
      });
    }

    return NextResponse.json({
      ...config,
      voteLinks: JSON.parse(config.voteLinks),
      socialLinks: JSON.parse(config.socialLinks),
    });
  } catch (error: unknown) {
    console.error("Failed to fetch config:", error);
    return NextResponse.json(
      { error: "Failed to fetch config", details: error instanceof Error ? error.message : String(error) },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { serverIp, serverName, logoUrl, discordUrl, forumUrl, voteLinks, socialLinks } = body;

    const config = await prisma.storeConfig.upsert({
      where: { id: "main" },
      update: {
        ...(serverIp !== undefined && { serverIp }),
        ...(serverName !== undefined && { serverName }),
        ...(logoUrl !== undefined && { logoUrl }),
        ...(discordUrl !== undefined && { discordUrl }),
        ...(forumUrl !== undefined && { forumUrl }),
        ...(voteLinks !== undefined && { voteLinks: JSON.stringify(voteLinks) }),
        ...(socialLinks !== undefined && { socialLinks: JSON.stringify(socialLinks) }),
      },
      create: {
        id: "main",
        serverIp: serverIp || "play.pika-network.net",
        serverName: serverName || "PikaNetwork",
        logoUrl: logoUrl || "/logo.png",
        discordUrl: discordUrl || "",
        forumUrl: forumUrl || "",
        voteLinks: voteLinks ? JSON.stringify(voteLinks) : "[]",
        socialLinks: socialLinks ? JSON.stringify(socialLinks) : "{}",
      },
    });

    return NextResponse.json({
      ...config,
      voteLinks: JSON.parse(config.voteLinks),
      socialLinks: JSON.parse(config.socialLinks),
    });
  } catch (error) {
    console.error("Failed to update config:", error);
    return NextResponse.json(
      { error: "Failed to update config" },
      { status: 500 }
    );
  }
}

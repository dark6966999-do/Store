import { NextResponse } from "next/server";
import {
  createDiscordToken,
  DISCORD_COOKIE_NAME,
  DiscordUser,
} from "@/lib/discord-auth";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { username, id, globalName, avatarUrl } = body;

    if (!username || typeof username !== "string" || !username.trim()) {
      return NextResponse.json({ error: "Discord username is required" }, { status: 400 });
    }

    const cleanUsername = username.trim().replace(/^@/, "");
    // Ensure Snowflake ID format (defaults to a mock numeric snowflake if none given)
    const cleanId = id && String(id).trim() ? String(id).trim() : `${Math.floor(Date.now() * 1000 + Math.random() * 999)}`;

    const userAvatar = avatarUrl && String(avatarUrl).startsWith("http")
      ? avatarUrl
      : `https://cdn.discordapp.com/embed/avatars/${Math.floor(Math.random() * 5)}.png`;

    const discordUser: DiscordUser = {
      id: cleanId,
      username: cleanUsername,
      globalName: globalName ? String(globalName).trim() : cleanUsername,
      avatarUrl: userAvatar,
      linkedAt: new Date().toISOString(),
    };

    const token = createDiscordToken(discordUser);

    const response = NextResponse.json({
      success: true,
      user: discordUser,
      message: "Discord account linked successfully",
    });

    response.cookies.set(DISCORD_COOKIE_NAME, token, {
      httpOnly: false,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60, // 30 days
      path: "/",
    });

    return response;
  } catch (error) {
    console.error("Dev discord login failed:", error);
    return NextResponse.json({ error: "Failed to login with Discord" }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { DISCORD_COOKIE_NAME } from "@/lib/discord-auth";

export async function POST() {
  const response = NextResponse.json({ success: true, message: "Logged out from Discord successfully" });
  response.cookies.set(DISCORD_COOKIE_NAME, "", {
    httpOnly: false,
    path: "/",
    maxAge: 0,
  });
  return response;
}

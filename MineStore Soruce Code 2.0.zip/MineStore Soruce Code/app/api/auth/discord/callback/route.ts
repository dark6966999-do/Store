import { NextResponse } from "next/server";
import {
  getDiscordConfig,
  createDiscordToken,
  DISCORD_COOKIE_NAME,
  DiscordUser,
} from "@/lib/discord-auth";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const code = searchParams.get("code");
  const state = searchParams.get("state") || "/";
  const error = searchParams.get("error");

  const host = request.headers.get("host") || "store.localhost:3000";
  const config = getDiscordConfig(host);

  if (error || !code) {
    console.error("Discord OAuth error or denied:", error);
    const returnUrl = new URL(state.startsWith("http") ? state : `http://${host}${state}`);
    returnUrl.searchParams.set("discord_error", error || "access_denied");
    return NextResponse.redirect(returnUrl);
  }

  try {
    // 1. Exchange code for access token
    const tokenRes = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        client_id: config.clientId,
        client_secret: config.clientSecret,
        grant_type: "authorization_code",
        code,
        redirect_uri: config.redirectUri,
      }),
    });

    if (!tokenRes.ok) {
      const errText = await tokenRes.text();
      console.error("Discord token exchange failed:", errText);
      const returnUrl = new URL(state.startsWith("http") ? state : `http://${host}${state}`);
      returnUrl.searchParams.set("discord_error", "token_exchange_failed");
      return NextResponse.redirect(returnUrl);
    }

    const tokenData = await tokenRes.json();
    const accessToken = tokenData.access_token;

    // 2. Fetch Discord user profile
    const userRes = await fetch("https://discord.com/api/users/@me", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!userRes.ok) {
      console.error("Failed to fetch Discord user");
      const returnUrl = new URL(state.startsWith("http") ? state : `http://${host}${state}`);
      returnUrl.searchParams.set("discord_error", "fetch_user_failed");
      return NextResponse.redirect(returnUrl);
    }

    const discordProfile = await userRes.json();

    // 3. Generate Avatar URL
    let avatarUrl = "https://cdn.discordapp.com/embed/avatars/0.png";
    if (discordProfile.avatar) {
      const isAnimated = discordProfile.avatar.startsWith("a_");
      avatarUrl = `https://cdn.discordapp.com/avatars/${discordProfile.id}/${discordProfile.avatar}.${isAnimated ? "gif" : "png"}?size=128`;
    } else {
      const defaultIndex = Number(BigInt(discordProfile.id || "0") % BigInt(5));
      avatarUrl = `https://cdn.discordapp.com/embed/avatars/${defaultIndex}.png`;
    }

    const discordUser: DiscordUser = {
      id: discordProfile.id,
      username: discordProfile.username,
      globalName: discordProfile.global_name || discordProfile.username,
      avatar: discordProfile.avatar,
      avatarUrl,
      email: discordProfile.email,
      accessToken,
      linkedAt: new Date().toISOString(),
    };

    // 4. Create and set cookie
    const token = createDiscordToken(discordUser);
    const destination = state.startsWith("http") ? state : `http://${host}${state}`;
    const response = NextResponse.redirect(destination);

    response.cookies.set(DISCORD_COOKIE_NAME, token, {
      httpOnly: false, // Accessible to client-side react
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60, // 30 days
      path: "/",
    });

    return response;
  } catch (err) {
    console.error("Discord callback exception:", err);
    const returnUrl = new URL(state.startsWith("http") ? state : `http://${host}${state}`);
    returnUrl.searchParams.set("discord_error", "server_error");
    return NextResponse.redirect(returnUrl);
  }
}

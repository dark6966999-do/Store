import { NextResponse } from "next/server";
import { getDiscordConfig } from "@/lib/discord-auth";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const host = request.headers.get("host") || "store.localhost:3000";
  const returnUrl = searchParams.get("returnUrl") || `http://${host}/`;
  const forceDev = searchParams.get("dev") === "true";

  const config = getDiscordConfig(host);

  if (config.isConfigured && !forceDev) {
    const scope = encodeURIComponent("identify email guilds.join");
    const redirectUri = encodeURIComponent(config.redirectUri);
    const state = encodeURIComponent(returnUrl);

    const discordAuthUrl = `https://discord.com/oauth2/authorize?client_id=${config.clientId}&response_type=code&redirect_uri=${redirectUri}&scope=${scope}&state=${state}&prompt=consent`;

    return NextResponse.redirect(discordAuthUrl);
  }

  // If Discord credentials not yet added to .env, redirect to the store's built-in Discord Login modal or dev page
  const devLoginUrl = new URL("/login/discord", request.url);
  devLoginUrl.searchParams.set("returnUrl", returnUrl);
  if (!config.isConfigured) {
    devLoginUrl.searchParams.set("needsConfig", "true");
  }
  return NextResponse.redirect(devLoginUrl);
}

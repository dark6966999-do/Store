import { NextResponse } from "next/server";
import { getDiscordSession, getDiscordConfig } from "@/lib/discord-auth";

export async function GET(request: Request) {
  try {
    const user = await getDiscordSession();
    const host = request.headers.get("host") || "";
    const config = getDiscordConfig(host);

    return NextResponse.json({
      user,
      isConfigured: config.isConfigured,
      clientId: config.clientId ? `${config.clientId.slice(0, 4)}...` : null,
    });
  } catch (error) {
    console.error("Error reading discord session:", error);
    return NextResponse.json({ user: null, isConfigured: false }, { status: 500 });
  }
}

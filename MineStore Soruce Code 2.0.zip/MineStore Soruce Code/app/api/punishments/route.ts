import { NextRequest, NextResponse } from "next/server";
import {
  readPunishments,
  writePunishments,
  scanConsoleLogsForPunishments,
  PunishmentRecord,
  formatDateToPika,
  parseDurationToExpiry,
} from "@/lib/punishments";

/**
 * GET /api/punishments
 * Query parameters:
 *  - tab: "bans" | "kicks" | "mutes" | "warnings" | "all"
 *  - search: Minecraft username or staff name
 *  - page: number (1-based, default 1)
 *  - limit: number (default 15)
 * Every request scans recent console output for confirmed punishment events.
 */
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const tab = (searchParams.get("tab") || "bans").toLowerCase();
    const search = (searchParams.get("search") || "").trim().toLowerCase();
    const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10));
    const limit = Math.max(1, Math.min(100, parseInt(searchParams.get("limit") || "15", 10)));
    // Import confirmed punishment events from the stored console output.
    scanConsoleLogsForPunishments();
    const all = readPunishments();

    // Calculate total counts per category for the tabs
    const counts = {
      bans: all.filter((p) => p.type === "BAN").length,
      kicks: all.filter((p) => p.type === "KICK").length,
      mutes: all.filter((p) => p.type === "MUTE").length,
      warnings: all.filter((p) => p.type === "WARN").length,
      total: all.length,
    };

    // Filter by tab
    let filtered = all;
    if (tab === "bans") {
      filtered = all.filter((p) => p.type === "BAN");
    } else if (tab === "kicks") {
      filtered = all.filter((p) => p.type === "KICK");
    } else if (tab === "mutes") {
      filtered = all.filter((p) => p.type === "MUTE");
    } else if (tab === "warnings" || tab === "warns") {
      filtered = all.filter((p) => p.type === "WARN");
    }

    // Filter by search query (user or staff)
    if (search) {
      filtered = filtered.filter(
        (p) =>
          p.player.toLowerCase().includes(search) ||
          p.staff.toLowerCase().includes(search) ||
          p.reason.toLowerCase().includes(search)
      );
    }

    // Pagination
    const totalItems = filtered.length;
    const totalPages = Math.ceil(totalItems / limit) || 1;
    const startIndex = (page - 1) * limit;
    const paginatedItems = filtered.slice(startIndex, startIndex + limit);

    return NextResponse.json({
      success: true,
      punishments: paginatedItems,
      pagination: {
        page,
        limit,
        totalItems,
        totalPages,
        hasPrev: page > 1,
        hasNext: page < totalPages,
      },
      counts,
    });
  } catch (err: any) {
    console.error("GET /api/punishments error:", err);
    return NextResponse.json(
      { success: false, error: err.message || "Failed to fetch punishments" },
      { status: 500 }
    );
  }
}

/**
 * POST /api/punishments
 * Allows direct logging of punishments (e.g. from RCON command monitor, in-game plugin, or admin dashboard).
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    if (!body.player) {
      return NextResponse.json({ success: false, error: "Player name is required" }, { status: 400 });
    }

    const now = new Date();
    const type = (body.type || "BAN").toUpperCase();
    const duration = body.duration || (type === "KICK" ? "Instant" : "Permanent");
    const { durationFormatted, expiresFormatted } = parseDurationToExpiry(duration);

    const newRecord: PunishmentRecord = {
      id: `punish_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      serverId: body.serverId || "survival-01",
      serverName: body.serverName || "Survival",
      player: body.player.trim(),
      playerUuid: body.playerUuid || "",
      type,
      reason: body.reason || "No reason specified",
      staff: body.staff || "CONSOLE",
      duration: durationFormatted,
      expires: type === "KICK" ? "Expired" : expiresFormatted,
      dateFormatted: formatDateToPika(now),
      timestamp: now.getTime(),
      receivedAt: now.toISOString(),
    };

    const current = readPunishments();
    current.unshift(newRecord);
    writePunishments(current);

    return NextResponse.json({
      success: true,
      message: "Punishment recorded successfully",
      record: newRecord,
    });
  } catch (err: any) {
    console.error("POST /api/punishments error:", err);
    return NextResponse.json(
      { success: false, error: err.message || "Failed to create punishment" },
      { status: 500 }
    );
  }
}

import { NextResponse } from "next/server";
import { getTebexConfig, saveTebexConfig } from "@/lib/tebex";

export async function GET() {
  const config = getTebexConfig();
  let connectionValid = false;
  let errorMsg = null;

  if (config.publicToken) {
    try {
      const res = await fetch(`https://headless.tebex.io/api/accounts/${config.publicToken}`, {
        headers: { Accept: "application/json" },
      });
      if (res.ok) {
        connectionValid = true;
      } else {
        errorMsg = `Tebex API returned HTTP ${res.status}`;
      }
    } catch (err: any) {
      errorMsg = err.message;
    }
  }

  return NextResponse.json({
    config: {
      publicToken: config.publicToken ? `${config.publicToken.slice(0, 4)}...${config.publicToken.slice(-4)}` : "",
      hasSecretKey: Boolean(config.secretKey),
      hasWebhookSecret: Boolean(config.webhookSecret),
      sandbox: config.sandbox,
      enabled: config.enabled,
    },
    connectionValid,
    error: errorMsg,
    webhookUrl: "/api/tebex/webhook",
  });
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const updated = saveTebexConfig({
      publicToken: body.publicToken,
      secretKey: body.secretKey,
      webhookSecret: body.webhookSecret,
      sandbox: body.sandbox !== undefined ? Boolean(body.sandbox) : undefined,
      enabled: body.enabled !== undefined ? Boolean(body.enabled) : undefined,
    });

    return NextResponse.json({ success: true, config: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

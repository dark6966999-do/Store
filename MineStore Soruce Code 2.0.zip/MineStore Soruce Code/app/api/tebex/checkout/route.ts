import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getDiscordSession, verifyDiscordToken } from "@/lib/discord-auth";
import {
  getTebexConfig,
  createTebexBasket,
  addPackageToTebexBasket,
  getTebexCheckoutUrl,
} from "@/lib/tebex";
import { deliverOrder } from "@/lib/delivery";
import { sendOrderInvoiceEmail } from "@/lib/email";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      username,
      email,
      discordUsername: inputDiscordUsername,
      phone,
      country,
      items,
      currency = "EUR",
      discordToken,
      returnUrl: clientReturnUrl,
    } = body;

    // 1. Validation
    if (!username || typeof username !== "string" || username.trim().length === 0) {
      return NextResponse.json(
        { error: "Please enter a valid Minecraft username" },
        { status: 400 }
      );
    }

    if (!email || typeof email !== "string" || !email.includes("@")) {
      return NextResponse.json(
        { error: "Please enter a valid email address to receive your order invoice" },
        { status: 400 }
      );
    }

    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: "Your cart is empty" }, { status: 400 });
    }

    // Discord resolution
    let discordUser = await getDiscordSession();
    if (!discordUser && discordToken) {
      discordUser = verifyDiscordToken(discordToken);
    }
    const finalDiscordUsername = discordUser?.username || inputDiscordUsername?.trim() || "N/A";
    const finalDiscordId = discordUser?.id || null;
    const finalDiscordAvatar = discordUser?.avatarUrl || null;

    // 2. Fetch products & calculate total
    const allProducts = await prisma.product.findMany({});
    const productMap = new Map(allProducts.map((p) => [p.id, p]));

    const orderItems = [];
    let grandTotal = 0;

    for (const item of items) {
      const prod = productMap.get(item.productId);
      if (!prod) {
        return NextResponse.json(
          { error: `Product not found: ${item.productId}` },
          { status: 400 }
        );
      }
      const qty = Math.max(1, parseInt(item.quantity) || 1);
      const lineTotal = prod.price * qty;
      grandTotal += lineTotal;

      orderItems.push({
        productId: prod.id,
        productName: prod.name,
        price: prod.price,
        quantity: qty,
        thumbnail: prod.thumbnail,
      });
    }

    const invoiceId = `INV-2026-${Math.floor(100000 + Math.random() * 900000)}`;
    const tebexConfig = getTebexConfig();

    // Default return URL
    const origin = request.headers.get("origin") || request.headers.get("referer") || "http://localhost:3000";
    const targetReturnUrl =
      clientReturnUrl || `${origin}/store/cart?payment=success&invoiceId=${invoiceId}&username=${encodeURIComponent(username.trim())}`;

    // 3. If Live Tebex Public Token configured, attempt official Tebex Basket Checkout
    if (tebexConfig.publicToken && !tebexConfig.sandbox) {
      const clientIp = request.headers.get("x-forwarded-for")?.split(",")[0] || "127.0.0.1";
      const basket = await createTebexBasket(tebexConfig.publicToken, username.trim(), clientIp);

      if (basket?.ident) {
        // Attempt to add packages
        for (const i of orderItems) {
          await addPackageToTebexBasket(basket.ident, i.productId, i.quantity);
        }

        const checkoutUrl = await getTebexCheckoutUrl(
          tebexConfig.publicToken,
          basket.ident,
          targetReturnUrl
        );

        if (checkoutUrl) {
          // Create pending order
          await prisma.order.create({
            data: {
              invoiceId,
              username: username.trim(),
              email: email.trim(),
              phone: phone ? phone.trim() : undefined,
              country: country ? country.trim() : undefined,
              total: Math.round(grandTotal * 100) / 100,
              currency,
              status: "pending_tebex",
              discordId: finalDiscordId || undefined,
              discordUsername: finalDiscordUsername,
              discordAvatar: finalDiscordAvatar || undefined,
              items: {
                create: orderItems.map((oi) => ({
                  productId: oi.productId,
                  price: oi.price,
                  quantity: oi.quantity,
                })),
              },
            },
          });

          return NextResponse.json({
            success: true,
            provider: "tebex_live",
            checkoutUrl,
            invoiceId,
            basketIdent: basket.ident,
          });
        }
      }
    }

    // 4. Sandbox / Direct Instant Mode (when Tebex is in sandbox or keys pending setup)
    // Execute automated server delivery and create complete order
    const deliveryResult = await deliverOrder(
      username.trim(),
      invoiceId,
      orderItems.map((i) => {
        const prod = productMap.get(i.productId);
        let productCommands: string[] = [];
        try {
          const raw = prod?.commands || "[]";
          productCommands = typeof raw === "string" ? JSON.parse(raw) : (Array.isArray(raw) ? raw : []);
        } catch { productCommands = []; }
        return {
          productId: i.productId,
          productName: i.productName,
          quantity: i.quantity,
          subCategory: prod?.subCategory,
          commands: productCommands.length > 0 ? productCommands : undefined,
        };
      })
    );

    const order = await prisma.order.create({
      data: {
        invoiceId,
        username: username.trim(),
        email: email.trim(),
        phone: phone ? phone.trim() : undefined,
        country: country ? country.trim() : undefined,
        total: Math.round(grandTotal * 100) / 100,
        currency,
        status: "completed",
        discordId: finalDiscordId || undefined,
        discordUsername: finalDiscordUsername,
        discordAvatar: finalDiscordAvatar || undefined,
        deliveryStatus: "delivered",
        deliveryCommands: deliveryResult.commands,
        items: {
          create: orderItems.map((oi) => ({
            productId: oi.productId,
            price: oi.price,
            quantity: oi.quantity,
          })),
        },
      },
    });

    // Send confirmation email
    const emailResult = await sendOrderInvoiceEmail({
      invoiceId,
      orderId: order.id,
      customerEmail: email.trim(),
      minecraftUsername: username.trim(),
      discordUsername: finalDiscordUsername,
      phone: phone ? phone.trim() : undefined,
      country: country ? country.trim() : undefined,
      items: orderItems.map((i) => ({
        productName: i.productName,
        quantity: i.quantity,
        price: i.price,
      })),
      total: Math.round(grandTotal * 100) / 100,
      currency,
      deliveryCommands: deliveryResult.commands,
    });

    return NextResponse.json({
      success: true,
      provider: "tebex_sandbox",
      invoiceId,
      order,
      delivery: {
        status: "delivered",
        commands: deliveryResult.commands,
        logs: deliveryResult.logs,
      },
      emailSent: emailResult.success,
      customerEmail: email.trim(),
    });
  } catch (err: any) {
    console.error("[Tebex Checkout API Error]:", err);
    return NextResponse.json(
      { error: err.message || "Failed to initiate Tebex checkout" },
      { status: 500 }
    );
  }
}

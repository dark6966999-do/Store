import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getTebexConfig, verifyTebexWebhookSignature } from "@/lib/tebex";
import { deliverOrder } from "@/lib/delivery";
import { sendOrderInvoiceEmail } from "@/lib/email";

export async function POST(request: Request) {
  try {
    const rawBody = await request.text();
    const signature = request.headers.get("x-bc-signature") || request.headers.get("x-tebex-signature");
    const tebexConfig = getTebexConfig();

    // Verify signature if secret is configured
    if (tebexConfig.webhookSecret && !verifyTebexWebhookSignature(rawBody, signature, tebexConfig.webhookSecret)) {
      console.warn("[Tebex Webhook] Invalid signature rejected");
      return NextResponse.json({ error: "Invalid webhook signature" }, { status: 401 });
    }

    let payload: any;
    try {
      payload = JSON.parse(rawBody);
    } catch {
      return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
    }

    const eventType = payload.type || payload.event || "payment.completed";

    // 1. Tebex Endpoint Validation Ping
    if (eventType === "validation.webhook") {
      console.log("[Tebex Webhook] Validation handshake received successfully");
      return NextResponse.json({ id: payload.id || "validation" });
    }

    // 2. Payment Completed Event
    if (eventType === "payment.completed") {
      const subject = payload.subject || payload;
      const customer = subject.customer || {};
      const username = customer.username || subject.player?.name || "Player";
      const customerEmail = customer.email || payload.email || "";
      const transactionId = subject.transaction_id || subject.id || `TX-${Date.now()}`;
      const amount = subject.price?.amount || subject.amount || 0;
      const currency = subject.price?.currency || subject.currency || "EUR";

      console.log(`[Tebex Webhook] Payment completed for ${username} (TX: ${transactionId})`);

      // Update matching order or create new record
      let existingOrder = await prisma.order.findFirst({
        where: {
          username,
          status: "pending_tebex",
        },
        orderBy: { createdAt: "desc" },
      });

      const invoiceId = existingOrder?.invoiceId || `INV-TBX-${transactionId}`;

      // Live delivery in Minecraft server via RCON
      const deliveryResult = await deliverOrder(username, invoiceId, [
        {
          productId: "tebex_package",
          productName: "Tebex Store Package",
          quantity: 1,
        },
      ]);

      if (existingOrder) {
        await prisma.order.update({
          where: { id: existingOrder.id },
          data: {
            status: "completed",
            deliveryStatus: "delivered",
            deliveryCommands: deliveryResult.commands,
          },
        });
      } else {
        await prisma.order.create({
          data: {
            invoiceId,
            username,
            email: customerEmail,
            total: Number(amount),
            currency,
            status: "completed",
            deliveryStatus: "delivered",
            deliveryCommands: deliveryResult.commands,
          },
        });
      }

      // Send confirmation email if email available
      if (customerEmail) {
        await sendOrderInvoiceEmail({
          invoiceId,
          orderId: existingOrder?.id || transactionId,
          customerEmail,
          minecraftUsername: username,
          total: Number(amount),
          currency,
          items: [
            {
              productName: "Tebex Store Package",
              quantity: 1,
              price: Number(amount),
            },
          ],
          deliveryCommands: deliveryResult.commands,
        });
      }

      return NextResponse.json({ success: true, invoiceId, delivered: true });
    }

    return NextResponse.json({ received: true });
  } catch (err: any) {
    console.error("[Tebex Webhook Exception]:", err);
    return NextResponse.json({ error: err.message || "Webhook processing error" }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const status = searchParams.get("status") || "";
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");

    let allOrders = await prisma.order.findMany({
      orderBy: { createdAt: "desc" },
    });

    // Search filter
    if (search) {
      const q = search.toLowerCase();
      allOrders = allOrders.filter(
        (o) =>
          o.username.toLowerCase().includes(q) ||
          o.id.toLowerCase().includes(q) ||
          (o.invoiceId && o.invoiceId.toLowerCase().includes(q)) ||
          (o.email && o.email.toLowerCase().includes(q))
      );
    }

    // Status filter
    if (status) {
      allOrders = allOrders.filter((o) => o.status === status);
    }

    const total = allOrders.length;
    const totalPages = Math.ceil(total / limit);
    const paginated = allOrders.slice((page - 1) * limit, page * limit);

    // Summary stats
    const allOrdersFull = await prisma.order.findMany({
      orderBy: { createdAt: "desc" },
    });
    const totalRevenue = allOrdersFull.reduce((s, o) => s + o.total, 0);
    const completedCount = allOrdersFull.filter((o) => o.status === "completed").length;
    const pendingCount = allOrdersFull.filter((o) => o.status === "pending").length;
    const failedCount = allOrdersFull.filter(
      (o) => o.status !== "completed" && o.status !== "pending"
    ).length;

    const transactions = paginated.map((order) => ({
      id: order.id,
      invoiceId: order.invoiceId || order.id,
      username: order.username,
      avatar: `https://minotar.net/helm/${encodeURIComponent(order.username)}/64.png`,
      email: order.email || "",
      total: order.total,
      currency: order.currency,
      status: order.status,
      items: order.items || [],
      itemCount: Array.isArray(order.items) ? order.items.length : 0,
      createdAt: order.createdAt,
      deliveryStatus: order.deliveryStatus || "delivered",
    }));

    return NextResponse.json({
      transactions,
      total,
      totalPages,
      page,
      summary: {
        totalRevenue,
        totalOrders: allOrdersFull.length,
        completedCount,
        pendingCount,
        failedCount,
      },
    });
  } catch (error) {
    console.error("Failed to fetch transactions:", error);
    return NextResponse.json(
      { error: "Failed to fetch transactions" },
      { status: 500 }
    );
  }
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");

    const allOrders = await prisma.order.findMany({
      orderBy: { createdAt: "desc" },
    });

    // Aggregate customers from orders
    const customerMap = new Map<
      string,
      {
        username: string;
        avatar: string;
        totalSpent: number;
        currency: string;
        orderCount: number;
        lastOrder: string;
        firstOrder: string;
        email?: string;
        country?: string;
        statuses: Record<string, number>;
      }
    >();

    for (const order of allOrders) {
      const key = order.username.toLowerCase();
      const existing = customerMap.get(key);

      if (existing) {
        existing.totalSpent += order.total;
        existing.orderCount += 1;
        if (new Date(order.createdAt) > new Date(existing.lastOrder)) {
          existing.lastOrder = order.createdAt;
        }
        if (new Date(order.createdAt) < new Date(existing.firstOrder)) {
          existing.firstOrder = order.createdAt;
        }
        existing.statuses[order.status] = (existing.statuses[order.status] || 0) + 1;
        if (order.email && !existing.email) existing.email = order.email;
        if (order.country && !existing.country) existing.country = order.country;
      } else {
        customerMap.set(key, {
          username: order.username,
          avatar: `https://minotar.net/helm/${encodeURIComponent(order.username)}/64.png`,
          totalSpent: order.total,
          currency: order.currency,
          orderCount: 1,
          lastOrder: order.createdAt,
          firstOrder: order.createdAt,
          email: order.email,
          country: order.country,
          statuses: { [order.status]: 1 },
        });
      }
    }

    let customers = Array.from(customerMap.values());

    // Search filter
    if (search) {
      const q = search.toLowerCase();
      customers = customers.filter(
        (c) =>
          c.username.toLowerCase().includes(q) ||
          (c.email && c.email.toLowerCase().includes(q))
      );
    }

    // Sort by total spent descending
    customers.sort((a, b) => b.totalSpent - a.totalSpent);

    const total = customers.length;
    const totalPages = Math.ceil(total / limit);
    const paginated = customers.slice((page - 1) * limit, page * limit);

    return NextResponse.json({
      customers: paginated,
      total,
      totalPages,
      page,
    });
  } catch (error) {
    console.error("Failed to fetch customers:", error);
    return NextResponse.json(
      { error: "Failed to fetch customers" },
      { status: 500 }
    );
  }
}

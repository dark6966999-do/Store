import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import PikaStorePage from "../../page";

export default async function StoreCategoryPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const category = await prisma.category.findUnique({
    where: { slug },
    select: { id: true, slug: true },
  });
  const activeProductCount = category
    ? await prisma.product.count({ where: { categoryId: category.id, active: true } })
    : 0;

  if (!category || activeProductCount === 0) {
    notFound();
  }

  return <PikaStorePage initialCategorySlug={category.slug} />;
}

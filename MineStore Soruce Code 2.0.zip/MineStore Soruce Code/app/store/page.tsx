"use client";

import React, { useState, useEffect, useRef, useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { getMainSiteUrl } from "@/lib/urls";

// ─── Types ───────────────────────────────────────────────────────────────────

interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  color: string;
  order: number;
  _count?: { products: number };
}

interface SubCategory {
  idx: number;
  name: string;
  slug: string;
  description: string;
}

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  subCategory?: string;
  perks?: string[];
  purchases?: number;
  categoryId: string;
  thumbnail: string;
  featured: boolean;
  active: boolean;
  createdAt?: string;
  category?: Category;
}

interface CartItem {
  product: Product;
  quantity: number;
}

interface RecentPurchase {
  id: string;
  username: string;
  avatarUrl: string;
  productName: string;
  total: number;
  currency: string;
  createdAt: string;
}

interface DiscordUser {
  id: string;
  username: string;
  globalName?: string;
  avatarUrl: string;
  email?: string;
}

type Currency = "BDT" | "EUR" | "USD" | "GBP";

const CURRENCY_SYMBOLS: Record<Currency, string> = {
  BDT: "৳",
  EUR: "€",
  USD: "$",
  GBP: "£",
};

const CURRENCY_RATES: Record<Currency, number> = {
  BDT: 130.0,
  EUR: 1.0,
  USD: 1.08,
  GBP: 0.85,
};

const LANGUAGES = [
  { code: "en", name: "English", flag: "🇬🇧" },
  { code: "es", name: "Spanish", flag: "🇪🇸" },
  { code: "de", name: "German", flag: "🇩🇪" },
  { code: "fr", name: "French", flag: "🇫🇷" },
  { code: "ru", name: "Russian", flag: "🇷🇺" },
];

// ─── Constants ───────────────────────────────────────────────────────────────

const SERVER_IP = "play.pika-network.net";
const SITE_NAME = "PikaNetwork Store";
const LOGO_SRC = "/logo.png";

// ─── Static Data (MineStoreCMS v3 Categories & Packages) ────────────────────

const STATIC_CATEGORIES: {
  idx: number;
  name: string;
  slug: string;
  description: string;
  img: string | null;
  subcategories: { idx: number; name: string; slug: string; description: string; img: string | null }[];
}[] = [
  {
    idx: 1,
    name: "Prison Ranks",
    slug: "prison-ranks",
    description: "Unlock exclusive perks, powerful tools, and special privileges with our Prison Ranks, designed to enhance your progression and dominate the prison server.",
    img: "/img/categories/1.png",
    subcategories: [],
  },
  {
    idx: 2,
    name: "Factions",
    slug: "factions",
    description: "Dominate the battlefield and conquer rivals with our exclusive Factions packages and supplies.",
    img: "/img/categories/2.png",
    subcategories: [
      {
        idx: 16,
        name: "Tier Keys",
        slug: "factions/tier-keys",
        description: "Unlock the secrets of the realm with our specialized Keys. Each key is forged from unique materials found across the Overworld and the Nether, granting access to exclusive loot, rare enchantments, and powerful gear.",
        img: null,
      },
      {
        idx: 17,
        name: "Keys",
        slug: "factions/keys",
        description: "Unlock elite perks and enhanced features to dominate the battlefield and protect your faction with our exclusive Factions keys!",
        img: null,
      },
      {
        idx: 3,
        name: "Ranks",
        slug: "factions/ranks",
        description: "Unlock elite perks and enhanced features to dominate the battlefield and protect your faction with our exclusive Factions ranks!",
        img: null,
      },
    ],
  },
  {
    idx: 5,
    name: "Tokens",
    slug: "tokens",
    description: "Use our in-game tokens to unlock exclusive perks, powerful upgrades, and special items that enhance your gameplay and give you an edge over your competition!",
    img: "/img/categories/5.png",
    subcategories: [],
  },
  {
    idx: 6,
    name: "BedWars",
    slug: "bedwars",
    description: "Enhance your BedWars gameplay with exclusive kits, cosmetics, and power-ups.",
    img: null,
    subcategories: [
      { idx: 18, name: "Kits", slug: "bedwars/kits", description: "Unlock powerful starter kits for BedWars.", img: null },
      { idx: 19, name: "Cosmetics", slug: "bedwars/cosmetics", description: "Stand out with exclusive BedWars cosmetics.", img: null },
    ],
  },
  {
    idx: 7,
    name: "SkyBlock",
    slug: "skyblock",
    description: "Boost your SkyBlock island with premium upgrades and exclusive items.",
    img: null,
    subcategories: [],
  },
  {
    idx: 8,
    name: "Survival",
    slug: "survival-ranks",
    description: "Explore Survival ranks and unlock perks for your next adventure.",
    img: "https://store.pika-network.net/_next/image?url=%2Fcategories%2Fsurvival.webp&w=64&q=75",
    subcategories: [],
  },
];

const FEATURED_DEALS: {
  id: number;
  name: string;
  price: number;
  originalPrice: number;
  discount: number;
  image: string;
  isSubscription: boolean;
  description: string;
  quantityLimit: number | null;
}[] = [
  {
    id: 2,
    name: "Premium Rank",
    price: 11.69,
    originalPrice: 12.99,
    discount: 1.3,
    image: "/img/items/2.png",
    isSubscription: true,
    description: "The Premium Rank offers enhanced gameplay with early access, exclusive kits, increased permissions, premium lounge access, distinctive recognition, and priority support.",
    quantityLimit: null,
  },
  {
    id: 3,
    name: "Deluxe Rank",
    price: 19.99,
    originalPrice: 19.99,
    discount: 0,
    image: "/img/items/3.png",
    isSubscription: true,
    description: "The Deluxe Rank is the ultimate tier of membership, offering unparalleled benefits including exclusive access, custom kits, enhanced permissions, VIP lounge access, and top-tier support.",
    quantityLimit: 20,
  },
];

// Curated products for each category/subcategory
const CATEGORY_PRODUCTS_MAP: Record<string, Product[]> = {
  "prison-ranks": [
    {
      id: "pr-1",
      name: "Prison Citizen",
      description: "Get started on your prison climb with extra vault space, /feed, and a starter contraband kit.",
      price: 4.99,
      originalPrice: 6.99,
      categoryId: "1",
      thumbnail: "/img/items/2.png",
      featured: false,
      active: true,
    },
    {
      id: "pr-2",
      name: "Prison Guard",
      description: "Unlock guard ward privileges, 3 private mines, /fly in plots, and daily gem rewards.",
      price: 14.99,
      originalPrice: 19.99,
      categoryId: "1",
      thumbnail: "/img/items/3.png",
      featured: true,
      active: true,
    },
    {
      id: "pr-3",
      name: "Prison Warden",
      description: "The ultimate tier of prison authority with automated sell chest, exclusive warden pickaxe, and maximum perks.",
      price: 29.99,
      originalPrice: 39.99,
      categoryId: "1",
      thumbnail: "/img/items/2.png",
      featured: true,
      active: true,
    },
  ],
  "factions/tier-keys": [
    {
      id: "tk-1",
      name: "Tier I Key (x5)",
      description: "Five forged Tier I keys to unlock rare spawner and gear crates at warzone spawn.",
      price: 3.49,
      categoryId: "2",
      thumbnail: "/img/categories/2.png",
      featured: false,
      active: true,
    },
    {
      id: "tk-2",
      name: "Tier II Legendary Key (x10)",
      description: "Ten forged Tier II keys granting high chances of legendary armor sets and TNT bundles.",
      price: 8.99,
      originalPrice: 11.99,
      categoryId: "2",
      thumbnail: "/img/categories/2.png",
      featured: true,
      active: true,
    },
    {
      id: "tk-3",
      name: "Tier III Mythic Key (x20)",
      description: "Twenty supreme tier mythic keys forged in the Nether depths with guaranteed god-tier gear.",
      price: 19.99,
      originalPrice: 24.99,
      categoryId: "2",
      thumbnail: "/img/categories/2.png",
      featured: true,
      active: true,
    },
  ],
  "factions/keys": [
    {
      id: "fk-1",
      name: "Champion Factions Crate Key",
      description: "Open the Champion Crate for raid boosters, obsidian breakers, and money notes.",
      price: 2.99,
      categoryId: "2",
      thumbnail: "/img/categories/2.png",
      featured: false,
      active: true,
    },
    {
      id: "fk-2",
      name: "Titan Warzone Key Pack (x5)",
      description: "Bundle of 5 Titan crate keys packed with explosive power and defensive fortress blocks.",
      price: 9.99,
      originalPrice: 14.99,
      categoryId: "2",
      thumbnail: "/img/categories/2.png",
      featured: true,
      active: true,
    },
  ],
  "factions/ranks": [
    {
      id: "fr-1",
      name: "Factions Warrior",
      description: "Standard combat rank with /kit warrior, 4 set homes, and access to the warzone outpost.",
      price: 9.99,
      originalPrice: 12.99,
      categoryId: "2",
      thumbnail: "/img/items/2.png",
      featured: false,
      active: true,
    },
    {
      id: "fr-2",
      name: "Factions Overlord",
      description: "Supreme faction commander status with permanent strength buff in claimed land and /fly access.",
      price: 29.99,
      originalPrice: 39.99,
      categoryId: "2",
      thumbnail: "/img/items/3.png",
      featured: true,
      active: true,
    },
  ],
  "factions": [
    {
      id: "fac-bundle",
      name: "Factions Empire Starter Bundle",
      description: "Includes Warrior Rank + 10 Tier Keys + 2 Creeper Spawners to kickstart your faction.",
      price: 18.99,
      originalPrice: 26.99,
      categoryId: "2",
      thumbnail: "/img/categories/2.png",
      featured: true,
      active: true,
    },
  ],
  "tokens": [
    {
      id: "tok-1",
      name: "500 Store Tokens",
      description: "500 tokens to spend in the in-game /tokenshop on custom enchantments, tags, and gadgets.",
      price: 4.99,
      categoryId: "5",
      thumbnail: "/img/categories/5.png",
      featured: false,
      active: true,
    },
    {
      id: "tok-2",
      name: "1,500 Store Tokens (+20% Bonus)",
      description: "1,500 tokens including 300 free bonus tokens! Most popular among active players.",
      price: 11.99,
      originalPrice: 14.99,
      categoryId: "5",
      thumbnail: "/img/categories/5.png",
      featured: true,
      active: true,
    },
    {
      id: "tok-3",
      name: "5,000 Store Tokens (+50% Bonus)",
      description: "Huge token sack for top spenders. Unlock the ultimate custom enchants and titles instantly.",
      price: 34.99,
      originalPrice: 49.99,
      categoryId: "5",
      thumbnail: "/img/categories/5.png",
      featured: true,
      active: true,
    },
  ],
  "bedwars": [
    {
      id: "bw-pass",
      name: "BedWars Season Pass",
      description: "Unlock 50 tiers of exclusive kill messages, victory dances, and projectile trails.",
      price: 7.99,
      categoryId: "6",
      thumbnail: "/img/items/2.png",
      featured: true,
      active: true,
    },
  ],
  "bedwars/kits": [
    {
      id: "bw-k1",
      name: "Rusher Kit",
      description: "Spawn with speed I boots and bridge egg perks on all BedWars modes.",
      price: 3.99,
      categoryId: "6",
      thumbnail: "/img/items/2.png",
      featured: false,
      active: true,
    },
    {
      id: "bw-k2",
      name: "Iron Golem Master Kit",
      description: "Cheaper golem summoning and 20% increased defense while protecting your team bed.",
      price: 5.99,
      categoryId: "6",
      thumbnail: "/img/items/3.png",
      featured: true,
      active: true,
    },
  ],
  "bedwars/cosmetics": [
    {
      id: "bw-c1",
      name: "Dragon Breath Kill Effect",
      description: "Unleash a fiery purple Ender Dragon explosion whenever you eliminate an opponent.",
      price: 4.49,
      categoryId: "6",
      thumbnail: "/img/items/2.png",
      featured: false,
      active: true,
    },
    {
      id: "bw-c2",
      name: "Lightning Strike Victory Dance",
      description: "Summon thunderbolts and fireworks across the arena whenever your team wins.",
      price: 5.99,
      categoryId: "6",
      thumbnail: "/img/items/3.png",
      featured: true,
      active: true,
    },
  ],
  "skyblock": [
    {
      id: "sb-1",
      name: "SkyBlock Island Booster Pack",
      description: "Instantly expand your island border by +50 blocks and double minion production rates for 14 days.",
      price: 9.99,
      originalPrice: 13.99,
      categoryId: "7",
      thumbnail: "/img/items/3.png",
      featured: true,
      active: true,
    },
    {
      id: "sb-2",
      name: "Automated Minion Overdrive",
      description: "Automated storage compressor and fuel hopper for all active minions on your island.",
      price: 14.99,
      categoryId: "7",
      thumbnail: "/img/items/2.png",
      featured: false,
      active: true,
    },
  ],
};

const DONATION_GOALS = [
  { name: "Summer Sale", current: 66.66, goal: 99.99 },
];

const TOP_SUPPORTER = {
  username: "Baffettoh",
  avatar: "https://mc-heads.net/body/Baffettoh",
};

const RECENT_DONATORS_STATIC = [
  { username: "abdulabid", avatar: "https://mc-heads.net/avatar/abdulabid/75", amount: 15.58, currency: "USD" },
  { username: "owg", avatar: "https://mc-heads.net/avatar/owg/75", amount: 45.87, currency: "USD" },
  { username: "4epi", avatar: "https://mc-heads.net/avatar/4epi/75", amount: 39.98, currency: "USD" },
  { username: "SzDominikk", avatar: "https://mc-heads.net/avatar/SzDominikk/75", amount: 28.96, currency: "USD" },
  { username: "MrAndreps", avatar: "https://mc-heads.net/avatar/MrAndreps/75", amount: 40.96, currency: "USD" },
  { username: "dom2231", avatar: "https://mc-heads.net/avatar/dom2231/75", amount: 84.95, currency: "USD" },
  { username: "Dominiiikk_", avatar: "https://mc-heads.net/avatar/Dominiiikk_/75", amount: 23.67, currency: "USD" },
  { username: "ObezKdy", avatar: "https://mc-heads.net/avatar/ObezKdy/75", amount: 87.96, currency: "USD" },
];

const PAYMENT_METHODS_INFO = [
  { name: "PayPal", desc: "PayPal balance, Banks, All Credit/Debit Cards" },
  { name: "Stripe", desc: "Visa, Mastercard, +100 Others" },
];

// ─── MineStoreCMS v3 Product Card Component ──────────────────────────────────

interface ProductCardProps {
  product: Product | (typeof FEATURED_DEALS)[0];
  onSelect: () => void;
  onAddToCart: (isSub?: boolean) => void;
  currency: Currency;
  convertPrice: (priceEur: number) => string;
}

function ProductCard({ product, onSelect, onAddToCart, currency, convertPrice }: ProductCardProps) {
  const discountPercent =
    product.originalPrice && product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : "discount" in product && product.discount && product.originalPrice
      ? Math.round((product.discount / product.originalPrice) * 100)
      : 0;

  const quantityLimit = "quantityLimit" in product ? product.quantityLimit : null;
  const imageSrc = "image" in product ? product.image : product.thumbnail || "/img/items/3.png";

  return (
    <div className="group relative rounded-2xl bg-[#1c1511] hover:bg-[#221a15] border border-[#34261b] hover:border-[#ff7300]/50 p-5 sm:p-6 flex flex-col justify-between items-center text-center transition-all duration-300 hover:-translate-y-1 shadow-xl hover:shadow-[0_12px_32px_rgba(255,115,0,0.15)]">
      {/* Top Stock / Items Left Pill matching user screenshot */}
      <div className="w-full flex justify-center mb-2 min-h-[28px]">
        {quantityLimit ? (
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#5c1c24] border border-[#7d212d] text-white text-xs font-bold tracking-wide shadow-sm">
            <svg className="w-3.5 h-3.5 text-white flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
            </svg>
            <span>{quantityLimit} items left</span>
          </div>
        ) : discountPercent > 0 ? (
          <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#5c1c24] border border-[#7d212d] text-white text-xs font-bold tracking-wide shadow-sm">
            <span>SALE -{discountPercent}%</span>
          </div>
        ) : product.featured ? (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#5c1c24] border border-[#7d212d] text-white text-xs font-bold tracking-wide shadow-sm">
            <svg className="w-3.5 h-3.5 text-white flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
            </svg>
            <span>20 items left</span>
          </div>
        ) : (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#34241a] text-[#ff9500] text-xs font-bold tracking-wide border border-[#483325]">
            <span>FEATURED</span>
          </div>
        )}
      </div>

      {/* Center Image with Ambient Glow matching user screenshot */}
      <div className="w-full flex items-center justify-center my-3 relative">
        <div className="absolute w-24 h-24 bg-[#ff7300]/10 rounded-full blur-2xl pointer-events-none -z-0" />
        <img
          src={imageSrc}
          alt={product.name}
          className="w-28 h-28 sm:w-32 sm:h-32 object-contain drop-shadow-[0_12px_24px_rgba(0,0,0,0.8)] group-hover:scale-105 transition-transform duration-300 relative z-10"
          onError={(e) => { (e.target as HTMLImageElement).src = "/img/items/3.png"; }}
        />
      </div>

      {/* Title & Price */}
      <div className="flex flex-col items-center mt-1 mb-4">
        <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-lg sm:text-xl tracking-tight leading-tight">
          {product.name}
        </h3>
        <div className="text-sm sm:text-base font-extrabold text-[#22c55e] tracking-wide mt-1">
          {convertPrice(product.price)} {currency}
        </div>
      </div>

      {/* Buttons Area matching user screenshot */}
      <div className="w-full flex flex-col gap-2.5 mt-auto">
        {/* Row 1: Info (i) button + Add to Cart button */}
        <div className="flex items-center gap-2.5 w-full">
          {/* Circular Info Button */}
          <button
            onClick={onSelect}
            className="w-10 h-10 sm:w-11 sm:h-11 rounded-full border border-white/20 hover:border-white/50 bg-white/[0.04] hover:bg-white/10 text-white flex items-center justify-center flex-shrink-0 transition-all cursor-pointer group/info"
            title="View details"
          >
            <svg className="w-5 h-5 text-white/90 group-hover/info:text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
              <circle cx="12" cy="12" r="9" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 8.5v.01M12 11.5v4" />
            </svg>
          </button>

          {/* Add to Cart Button */}
          <button
            onClick={() => onAddToCart(false)}
            className="flex-1 h-10 sm:h-11 rounded-xl bg-[#ff7300] hover:bg-[#ff851a] active:scale-95 text-black font-['Plus_Jakarta_Sans',sans-serif] font-black text-xs sm:text-sm tracking-wide flex items-center justify-center gap-1.5 sm:gap-2 px-2 sm:px-3 whitespace-nowrap transition-all shadow-[0_4px_16px_rgba(255,115,0,0.3)] hover:shadow-[0_6px_22px_rgba(255,115,0,0.45)] cursor-pointer"
          >
            <svg className="w-4 h-4 fill-none stroke-current flex-shrink-0" viewBox="0 0 24 24" strokeWidth="2.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121 0 2.09-.773 2.34-1.867l1.582-6.918A1.125 1.125 0 0020.766 4.5H5.25M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
            </svg>
            <span className="truncate">Add to Cart</span>
          </button>
        </div>

        {/* Row 2: Full width Subscribe button */}
        <button
          onClick={() => onAddToCart(true)}
          className="w-full h-10 sm:h-11 rounded-xl bg-[#ff7300] hover:bg-[#ff851a] active:scale-95 text-black font-['Plus_Jakarta_Sans',sans-serif] font-black text-xs sm:text-sm tracking-wide flex items-center justify-center gap-1.5 sm:gap-2 px-2 sm:px-3 whitespace-nowrap transition-all shadow-[0_4px_16px_rgba(255,115,0,0.3)] hover:shadow-[0_6px_22px_rgba(255,115,0,0.45)] cursor-pointer"
        >
          <svg className="w-4 h-4 fill-none stroke-current flex-shrink-0" viewBox="0 0 24 24" strokeWidth="2.5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121 0 2.09-.773 2.34-1.867l1.582-6.918A1.125 1.125 0 0020.766 4.5H5.25M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
          </svg>
          <span className="truncate">Subscribe</span>
        </button>
      </div>
    </div>
  );
}

// ─── Store Page Component ────────────────────────────────────────────────────

export default function PikaStorePage() {
  const router = useRouter();

  // State
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [recentPurchases, setRecentPurchases] = useState<RecentPurchase[]>([]);
  const [selectedCategorySlug, setSelectedCategorySlug] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [currency, setCurrency] = useState<Currency>("USD");
  const [currencyOpen, setCurrencyOpen] = useState(false);
  const [selectedLang, setSelectedLang] = useState("en");
  const [langOpen, setLangOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [expandedCategory, setExpandedCategory] = useState<string | null>("factions");
  const [giftCardCode, setGiftCardCode] = useState("");
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedIp, setCopiedIp] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<typeof FEATURED_DEALS[0] | Product | null>(null);
  const [mcUsername, setMcUsername] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [playerCount, setPlayerCount] = useState<number>(2845);
  const [discordOnlineCount, setDiscordOnlineCount] = useState<number>(313);

  // Discord & Account Modal States
  const [discordUser, setDiscordUser] = useState<DiscordUser | null>(null);
  const [discordIsConfigured, setDiscordIsConfigured] = useState<boolean>(false);
  const [isDiscordConnecting, setIsDiscordConnecting] = useState<boolean>(false);
  const [showAccountModal, setShowAccountModal] = useState<boolean>(false);
  const [loginTab, setLoginTab] = useState<"discord" | "minecraft">("discord");
  const [tempMinecraftIgn, setTempMinecraftIgn] = useState<string>("");
  const [customDiscordName, setCustomDiscordName] = useState<string>("");
  const [copiedDiscordId, setCopiedDiscordId] = useState<boolean>(false);

  // Current Language Object
  const currentLang = LANGUAGES.find((l) => l.code === selectedLang) || LANGUAGES[0];

  // ─── Helpers ─────────────────────────────────────────────────────────────

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage((cur) => (cur === msg ? null : cur)), 3000);
  };

  const copyServerIp = () => {
    navigator.clipboard.writeText(SERVER_IP);
    setCopiedIp(true);
    showToast("Server IP copied to clipboard!");
    setTimeout(() => setCopiedIp(false), 2500);
  };

  const convertPrice = (priceEur: number) => {
    const rate = CURRENCY_RATES[currency] || 1;
    return (priceEur * rate).toFixed(2);
  };

  const sym = CURRENCY_SYMBOLS[currency] || "$";

  // ─── Cart Helpers ────────────────────────────────────────────────────────

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const addToCart = (product: Product, isSub = false) => {
    const existing = cart.find((item) => item.product.id === product.id);
    const nextCart = existing
      ? cart.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      : [...cart, { product, quantity: 1 }];

    setCart(nextCart);
    try {
      localStorage.setItem("minestore_cart", JSON.stringify(nextCart));
    } catch {}
    showToast(`${product.name}${isSub ? " (Subscription)" : ""} added to cart!`);
  };

  const removeFromCart = (productId: string) => {
    const nextCart = cart.filter((item) => item.product.id !== productId);
    setCart(nextCart);
    try {
      localStorage.setItem("minestore_cart", JSON.stringify(nextCart));
    } catch {}
    showToast("Item removed from cart!");
  };

  // ─── Fetch Categories & Live Stats ───────────────────────────────────────

  useEffect(() => {
    try {
      const savedCart = localStorage.getItem("minestore_cart");
      if (savedCart) {
        const parsedCart = JSON.parse(savedCart);
        if (Array.isArray(parsedCart)) setCart(parsedCart);
      }
    } catch {}

    // Check bridge heartbeat for live player count
    fetch("/api/bridge/heartbeat", { cache: "no-store" })
      .then((r) => r.json())
      .then((data) => {
        if (data?.rcon?.online && typeof data.rcon.onlinePlayers === "number") {
          setPlayerCount(data.rcon.onlinePlayers);
        }
      })
      .catch(() => {});

    // Categories
    fetch("/api/categories?activeOnly=true")
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setCategories(data);
        }
      })
      .catch(() => {});

    // Products
    fetch("/api/products?limit=100&active=true")
      .then((r) => r.json())
      .then((data) => {
        if (data && Array.isArray(data.products) && data.products.length > 0) {
          setProducts(data.products);
        }
      })
      .catch(() => {});

    // Recent purchases
    fetch("/api/store/recent-purchases")
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setRecentPurchases(data);
        }
      })
      .catch(() => {});

    // Load cached session for instant UX
    try {
      const savedUser = localStorage.getItem("minestore_discord_user");
      if (savedUser) {
        setDiscordUser(JSON.parse(savedUser));
        setIsLoggedIn(true);
      }
      const savedIgn = localStorage.getItem("minestore_mc_username");
      if (savedIgn) {
        setMcUsername(savedIgn);
        setTempMinecraftIgn(savedIgn);
      }
    } catch {}

    // Check Discord session on server
    fetch("/api/auth/discord/me")
      .then((r) => r.json())
      .then((data) => {
        if (data.user) {
          setDiscordUser(data.user);
          setIsLoggedIn(true);
          try {
            localStorage.setItem("minestore_discord_user", JSON.stringify(data.user));
          } catch {}
        }
        setDiscordIsConfigured(Boolean(data.isConfigured));
      })
      .catch(() => {});
  }, []);

  // ─── Discord Login & Account Handlers ────────────────────────────────────

  const handleDiscordLogin = async () => {
    setIsDiscordConnecting(true);
    if (discordIsConfigured) {
      window.location.href = `/api/auth/discord?returnUrl=${encodeURIComponent(window.location.href)}`;
      return;
    }

    // Direct fallback login for development / demo
    try {
      const res = await fetch("/api/auth/discord/dev-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: customDiscordName.trim() || "DiscordUser",
          globalName: customDiscordName.trim() || "Discord User",
          id: `${Math.floor(Date.now() * 1000 + Math.random() * 999)}`,
        }),
      });
      const data = await res.json();
      if (res.ok && data.user) {
        setDiscordUser(data.user);
        setIsLoggedIn(true);
        try {
          localStorage.setItem("minestore_discord_user", JSON.stringify(data.user));
        } catch {}
        setShowLoginModal(false);
        showToast(`Connected as ${data.user.username}`);
      } else {
        showToast(data.error || "Failed to connect Discord");
      }
    } catch {
      showToast("Discord connection failed");
    } finally {
      setIsDiscordConnecting(false);
    }
  };

  const handleCustomDiscordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customDiscordName.trim()) {
      showToast("Please enter a Discord username");
      return;
    }
    await handleDiscordLogin();
  };

  const handleMinecraftLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (mcUsername.trim()) {
      setIsLoggedIn(true);
      setShowLoginModal(false);
      try {
        localStorage.setItem("minestore_mc_username", mcUsername.trim());
      } catch {}
      showToast(`Logged in as ${mcUsername.trim()}`);
    }
  };

  const handleSaveMinecraftIgn = () => {
    if (tempMinecraftIgn.trim()) {
      setMcUsername(tempMinecraftIgn.trim());
      try {
        localStorage.setItem("minestore_mc_username", tempMinecraftIgn.trim());
      } catch {}
      showToast(`Linked Minecraft IGN: ${tempMinecraftIgn.trim()}`);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/discord/logout", { method: "POST" });
    } catch {}
    localStorage.removeItem("minestore_discord_user");
    setDiscordUser(null);
    setIsLoggedIn(false);
    setShowAccountModal(false);
    showToast("Logged out successfully");
  };

  const copyDiscordId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedDiscordId(true);
    showToast("Discord ID copied to clipboard!");
    setTimeout(() => setCopiedDiscordId(false), 2000);
  };

  // ─── Donation Goal ───────────────────────────────────────────────────────

  const goalProgress = DONATION_GOALS.length > 0
    ? Math.min((DONATION_GOALS[0].current / DONATION_GOALS[0].goal) * 100, 100)
    : 0;

  // ─── Filtered products ──────────────────────────────────────────────────

  const activeCategoryProducts = useMemo(() => {
    if (!selectedCategorySlug) return [];
    
    // Check if we have curated static products for this category/subcategory
    const curated = CATEGORY_PRODUCTS_MAP[selectedCategorySlug];
    if (curated && curated.length > 0) {
      if (!searchQuery) return curated;
      return curated.filter((p) => p.name.toLowerCase().includes(searchQuery.toLowerCase()));
    }

    // Otherwise filter from database products
    const dbFiltered = products.filter((p) => {
      if (!p.active) return false;
      const categorySlug = p.category?.slug ?? categories.find((c) => c.id === p.categoryId)?.slug;
      if (categorySlug !== selectedCategorySlug) return false;
      if (searchQuery && !p.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      return true;
    });

    return dbFiltered;
  }, [products, categories, selectedCategorySlug, searchQuery]);

  return (
    <div className="min-h-screen bg-[#09090b] text-[#e4e4e7] antialiased" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* ═══════════════════════════════════════════════════════════════════
          TOAST NOTIFICATION
      ═══════════════════════════════════════════════════════════════════ */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-[100] animate-slideUp">
          <div className="bg-[#18181b]/95 border border-[#ff7300]/40 text-white px-5 py-3 rounded-xl shadow-[0_10px_40px_rgba(255,115,0,0.25)] flex items-center gap-3 backdrop-blur-xl text-sm font-medium">
            <svg className="w-5 h-5 text-[#ff7300] flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          LOGIN MODAL
      ═══════════════════════════════════════════════════════════════════ */}
      {showLoginModal && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/75 backdrop-blur-sm p-4" onClick={() => setShowLoginModal(false)}>
          <div className="bg-[#18181b] border border-[#27272a] rounded-2xl p-8 max-w-md w-full shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-[#ff7300]/20 flex items-center justify-center">
                <svg className="w-5 h-5 text-[#ff7300]" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Log In</h3>
                <p className="text-sm text-[#a1a1aa]">Enter your Minecraft Username to start shopping</p>
              </div>
            </div>
            <form onSubmit={handleLogin} className="flex flex-col gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#a1a1aa] uppercase tracking-wider mb-1.5">Username</label>
                <input
                  value={mcUsername}
                  onChange={(e) => setMcUsername(e.target.value)}
                  placeholder="Minecraft Username"
                  className="w-full px-4 py-3 rounded-xl bg-[#09090b] text-white text-sm border border-[#27272a] focus:border-[#ff7300] focus:outline-none focus:ring-1 focus:ring-[#ff7300]/30 transition-all placeholder:text-[#52525b]"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ff7300] to-[#ff9500] hover:from-[#ff8000] hover:to-[#ffa000] text-white font-bold text-sm shadow-[0_0_20px_rgba(255,115,0,0.3)] transition-all hover:shadow-[0_0_30px_rgba(255,115,0,0.45)] cursor-pointer"
              >
                Continue
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          PRODUCT DETAIL MODAL
      ═══════════════════════════════════════════════════════════════════ */}
      {selectedProduct && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/75 backdrop-blur-sm p-4" onClick={() => setSelectedProduct(null)}>
          <div className="bg-[#18181b] border border-[#27272a] rounded-2xl p-8 max-w-lg w-full shadow-2xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-4">
                <img
                  src={'thumbnail' in selectedProduct ? selectedProduct.thumbnail : (selectedProduct as any).image}
                  alt={selectedProduct.name}
                  className="w-16 h-16 rounded-xl object-contain bg-[#27272a] p-2"
                  onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                />
                <div>
                  <h3 className="text-xl font-bold text-white">{selectedProduct.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    {selectedProduct.originalPrice && selectedProduct.originalPrice > selectedProduct.price && (
                      <span className="text-sm text-[#71717a] line-through">{sym}{convertPrice(selectedProduct.originalPrice)}</span>
                    )}
                    <span className="text-lg font-bold text-[#ff7300]">{sym}{convertPrice(selectedProduct.price)}</span>
                    {'isSubscription' in selectedProduct && (selectedProduct as any).isSubscription && (
                      <span className="px-2 py-0.5 rounded bg-[#ff7300]/20 text-[#ff7300] text-xs font-bold">Subscription</span>
                    )}
                  </div>
                </div>
              </div>
              <button onClick={() => setSelectedProduct(null)} className="text-[#71717a] hover:text-white transition-colors cursor-pointer">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="text-sm text-[#a1a1aa] leading-relaxed mb-6" dangerouslySetInnerHTML={{ __html: selectedProduct.description }} />
            <button
              onClick={() => {
                addToCart({
                  id: String(selectedProduct.id),
                  name: selectedProduct.name,
                  description: selectedProduct.description,
                  price: selectedProduct.price,
                  originalPrice: selectedProduct.originalPrice,
                  categoryId: 'categoryId' in selectedProduct ? (selectedProduct as any).categoryId : "featured",
                  thumbnail: 'thumbnail' in selectedProduct ? selectedProduct.thumbnail : (selectedProduct as any).image,
                  featured: true,
                  active: true,
                } as Product);
                setSelectedProduct(null);
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ff7300] to-[#ff9500] hover:from-[#ff8000] hover:to-[#ffa000] text-white font-bold text-sm shadow-[0_0_20px_rgba(255,115,0,0.3)] transition-all hover:shadow-[0_0_30px_rgba(255,115,0,0.45)] cursor-pointer flex items-center justify-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z" />
              </svg>
              Add to Cart
            </button>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          HEADER HERO SECTION — Exactly Matches MineStoreCMS v3
      ═══════════════════════════════════════════════════════════════════ */}
      <header className="relative w-full overflow-visible">
        
        {/* TOP FLOATING NAVIGATION DOCK (Centered, Pill-Style from Screenshot) */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 z-40 flex items-center justify-center w-full px-2 sm:px-4 pointer-events-none">
          <div className="pointer-events-auto flex items-center gap-1.5 xs:gap-2 sm:gap-4 md:gap-5 bg-[#141416]/90 border-b border-x border-white/10 rounded-b-2xl px-2.5 sm:px-4 md:px-6 py-2 backdrop-blur-md shadow-[0_12px_36px_rgba(0,0,0,0.7)] text-xs max-w-full overflow-x-auto">
            
            {/* Currency Selector */}
            <div className="relative">
              <button
                onClick={() => { setCurrencyOpen(!currencyOpen); setLangOpen(false); }}
                className="flex items-center gap-1.5 cursor-pointer text-[#8b8b93] hover:text-white transition-colors"
              >
                <span className="text-[11px] font-semibold tracking-wider uppercase hidden sm:inline">CURRENCY</span>
                <span className="text-white font-bold">{currency}</span>
                <svg className="w-3 h-3 text-[#8b8b93]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              {currencyOpen && (
                <div className="absolute top-full mt-2 left-0 bg-[#18181b] border border-[#27272a] rounded-xl shadow-2xl py-1 z-50 min-w-[110px]">
                  {(Object.keys(CURRENCY_SYMBOLS) as Currency[]).map((c) => (
                    <button
                      key={c}
                      onClick={() => { setCurrency(c); setCurrencyOpen(false); }}
                      className={`w-full px-3 py-1.5 text-left text-xs hover:bg-[#27272a] transition-colors cursor-pointer flex items-center justify-between ${currency === c ? "text-[#ff7300] font-bold" : "text-[#a1a1aa]"}`}
                    >
                      <span>{c}</span>
                      <span className="font-mono text-[11px] text-[#71717a]">{CURRENCY_SYMBOLS[c]}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="w-[1px] h-3.5 bg-white/15 hidden sm:block" />

            {/* Language Selector */}
            <div className="relative">
              <button
                onClick={() => { setLangOpen(!langOpen); setCurrencyOpen(false); }}
                className="flex items-center gap-1.5 cursor-pointer text-[#8b8b93] hover:text-white transition-colors"
              >
                <span className="text-[11px] font-semibold tracking-wider uppercase hidden sm:inline">LANGUAGE</span>
                <span className="text-white font-bold flex items-center gap-1">
                  <span>{currentLang.flag}</span>
                  <span>{currentLang.name.toUpperCase()}</span>
                </span>
                <svg className="w-3 h-3 text-[#8b8b93]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              {langOpen && (
                <div className="absolute top-full mt-2 left-0 bg-[#18181b] border border-[#27272a] rounded-xl shadow-2xl py-1 z-50 min-w-[130px]">
                  {LANGUAGES.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => { setSelectedLang(l.code); setLangOpen(false); }}
                      className={`w-full px-3 py-1.5 text-left text-xs hover:bg-[#27272a] transition-colors cursor-pointer flex items-center gap-2 ${selectedLang === l.code ? "text-[#ff7300] font-bold" : "text-[#a1a1aa]"}`}
                    >
                      <span>{l.flag}</span>
                      <span>{l.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="w-[1px] h-3.5 bg-white/15 hidden xs:block" />

            {/* Shopping Cart */}
            <Link
              href="/store/cart"
              className="flex items-center gap-2 text-white hover:text-[#ff7300] transition-colors group"
            >
              <svg className="w-4 h-4 text-white group-hover:text-[#ff7300] transition-colors flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121 0 2.09-.773 2.34-1.867l1.582-6.918A1.125 1.125 0 0020.766 4.5H5.25M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
              </svg>
              <div className="flex flex-col sm:flex-row sm:items-center sm:gap-1.5 leading-none">
                <span className="text-[11px] font-bold uppercase tracking-wider hidden sm:inline">SHOPPING CART</span>
                <span className="text-[10px] text-[#22c55e] font-semibold">
                  {cartCount} <span className="hidden sm:inline">ITEMS FOR </span>{sym}{convertPrice(cartTotal)}
                </span>
              </div>
            </Link>

            <div className="w-[1px] h-3.5 bg-white/15 hidden xs:block" />

            {/* Login / Account & Logout */}
            {isLoggedIn || discordUser ? (
              <div className="flex items-center gap-2.5">
                <button
                  onClick={() => setShowAccountModal(true)}
                  className="flex items-center gap-1.5 text-white hover:text-[#ff9500] transition-colors font-bold uppercase text-[11px] tracking-wider cursor-pointer group"
                  title="View Account Information"
                >
                  {discordUser?.avatarUrl ? (
                    <img
                      src={discordUser.avatarUrl}
                      alt="Avatar"
                      className="w-4 h-4 rounded-full border border-[#5865F2]"
                    />
                  ) : (
                    <svg className="w-3.5 h-3.5 text-[#ff9500]" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
                    </svg>
                  )}
                  <span className="truncate max-w-[60px] sm:max-w-[110px] hidden sm:inline">
                    {discordUser?.globalName || discordUser?.username || mcUsername || "ACCOUNT"}
                  </span>
                </button>

                <div className="w-[1px] h-3 bg-white/20" />

                <button
                  onClick={handleLogout}
                  className="flex items-center gap-1 text-white/70 hover:text-[#ef4444] transition-colors font-bold uppercase text-[11px] tracking-wider cursor-pointer"
                  title="Logout"
                >
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                  </svg>
                  <span className="hidden sm:inline">LOGOUT</span>
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowLoginModal(true)}
                className="flex items-center gap-1.5 text-white hover:text-[#ff7300] transition-colors font-bold uppercase text-[11px] tracking-wider cursor-pointer"
              >
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                </svg>
                <span>LOGIN</span>
              </button>
            )}

            {/* Mobile menu icon */}
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden ml-1 px-2 py-1 rounded-lg bg-[#ff7300]/15 hover:bg-[#ff7300]/25 border border-[#ff7300]/40 text-[#ff9500] hover:text-white transition-all cursor-pointer flex items-center gap-1"
              title="Toggle Categories"
              aria-label="Toggle Categories"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
              <span className="text-[10px] font-bold uppercase hidden xs:inline">Menu</span>
            </button>
          </div>
        </div>

        {/* HERO BANNER WITH V3 BACKGROUND & EMBER PARTICLES */}
        <div
          className="relative w-full pt-20 pb-20 sm:pb-24 overflow-hidden"
          style={{
            backgroundImage: "url('/background.jpg')",
            backgroundPosition: "center top",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
          }}
        >
          {/* Subtle bottom dark vignette */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-[#09090b]/85 pointer-events-none" />

          {/* Floating animated ember particles */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {[...Array(24)].map((_, i) => (
              <span
                key={i}
                className="absolute rounded-full bg-[#ffb703] blur-[0.5px] ember-particle"
                style={{
                  width: `${i % 3 === 0 ? 3 : i % 2 === 0 ? 2 : 1.5}px`,
                  height: `${i % 3 === 0 ? 3 : i % 2 === 0 ? 2 : 1.5}px`,
                  left: `${2 + (i * 4.2)}%`,
                  top: `${20 + ((i * 19) % 65)}%`,
                  animationDuration: `${2.4 + (i % 5) * 0.6}s`,
                  animationDelay: `${(i * 0.18)}s`,
                }}
              />
            ))}
          </div>

          {/* MAIN HERO CONTENT ROW (Left IP, Center Logo, Right Discord - Tight & Centered as in Image 2) */}
          <div className="relative z-10 max-w-[1100px] mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6 md:gap-10 lg:gap-12 py-5 sm:py-6">
            
            {/* Left Side: Circular Orange Play Button with Black Arrow + Server IP */}
            <div
              onClick={copyServerIp}
              className="flex items-center gap-3 cursor-pointer group select-none flex-shrink-0 order-2 sm:order-1"
              title="Click to copy server IP"
            >
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#ff7300] flex items-center justify-center shadow-[0_0_18px_rgba(255,115,0,0.55)] group-hover:scale-105 group-hover:shadow-[0_0_26px_rgba(255,115,0,0.75)] transition-all flex-shrink-0">
                <svg className="w-4 h-4 sm:w-4.5 sm:h-4.5 fill-black ml-0.5" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
              </div>
              <div className="flex flex-col">
                <span className="text-sm sm:text-base md:text-[17px] font-black text-white tracking-wide group-hover:text-[#ff9500] transition-colors leading-tight">
                  {SERVER_IP}
                </span>
                <span className="text-[11px] sm:text-[13px] text-[#a1a1aa] font-medium leading-tight mt-1">
                  {copiedIp ? "Copied to clipboard!" : `${playerCount.toLocaleString()} Players Online`}
                </span>
              </div>
            </div>

            {/* Center: 3D Server Logo */}
            <div className="flex items-center justify-center my-0 relative flex-shrink-0 order-1 sm:order-2">
              {/* Radial ambient warmth behind logo */}
              <div className="absolute w-48 sm:w-60 md:w-80 h-24 sm:h-32 md:h-40 bg-gradient-to-r from-[#ff6a00]/20 via-[#ff9500]/25 to-[#ff6a00]/20 rounded-full blur-[50px] pointer-events-none -z-0 animate-pulse" />
              
              <Link href={getMainSiteUrl("/")} className="group relative z-10 flex flex-col items-center">
                <img
                  src={LOGO_SRC}
                  alt={SITE_NAME}
                  className="h-20 sm:h-28 md:h-36 lg:h-44 xl:h-48 max-w-[180px] sm:max-w-[240px] md:max-w-[320px] lg:max-w-[400px] w-auto object-contain logo-animated cursor-pointer transition-transform duration-300 group-hover:scale-105"
                  onError={(e) => { (e.target as HTMLImageElement).src = "/logo.png"; }}
                />
              </Link>
            </div>

            {/* Right Side: Discord Server + Members Online + Bare Orange Discord Icon */}
            <a
              href="https://pika-network.net/discord"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 group select-none flex-shrink-0 order-3"
              title="Join Discord Server"
            >
              <div className="flex flex-col text-right">
                <span className="text-sm sm:text-base md:text-[17px] font-black text-white tracking-wide group-hover:text-[#ff9500] transition-colors leading-tight">
                  Discord Server
                </span>
                <span className="text-[11px] sm:text-[13px] text-[#a1a1aa] font-medium leading-tight mt-1">
                  {discordOnlineCount.toLocaleString()} Members Online
                </span>
              </div>
              <div className="flex items-center justify-center flex-shrink-0">
                <svg className="w-8 h-8 sm:w-9 sm:h-9 md:w-10 md:h-10 fill-[#ff7300] drop-shadow-[0_2px_12px_rgba(255,115,0,0.5)] group-hover:scale-110 transition-transform duration-200" viewBox="0 0 127.14 96.36">
                  <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z"/>
                </svg>
              </div>
            </a>

          </div>
        </div>

        {/* BOTTOM OVERLAPPING CARDS (Summer Sale on left, YaHabivo profile on right) */}
        <div className="max-w-[1520px] mx-auto px-3 sm:px-5 -mt-6 sm:-mt-8 md:-mt-10 relative z-20 flex flex-col md:flex-row items-stretch md:items-end justify-between gap-3 sm:gap-4">
          
          {/* Left Orange Card: Summer Sale Goal */}
          <div className="w-full md:w-[370px] rounded-2xl md:rounded-t-2xl md:rounded-b-none bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] p-4 sm:p-5 shadow-[0_12px_36px_rgba(255,106,0,0.4)] border border-[#ffa04d]/40 md:border-b-0 md:border-t md:border-x transition-transform duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase drop-shadow-sm">
                Summer Sale
              </span>
              <span className="font-bold text-white text-sm bg-black/20 px-2 py-0.5 rounded-md">
                {goalProgress.toFixed(2)}%
              </span>
            </div>
            <div className="text-xs text-white/95 font-medium mt-1">
              {DONATION_GOALS[0].current.toFixed(2)} / {DONATION_GOALS[0].goal.toFixed(2)} USD
            </div>
            {/* Animated Shimmer Progress Bar */}
            <div className="w-full h-2.5 bg-black/25 rounded-full overflow-hidden mt-2.5 relative">
              <div
                className="h-full bg-white rounded-full transition-all duration-1000 shadow-sm relative overflow-hidden"
                style={{ width: `${goalProgress}%` }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/70 to-transparent progress-shimmer" />
              </div>
            </div>
          </div>

          {/* Right Card: Player Profile with Discord Login Option & Account Information */}
          {isLoggedIn || discordUser ? (
            /* ── LOGGED IN STATE: Shows Account Information + Minecraft Skin ── */
            <div
              onClick={() => setShowAccountModal(true)}
              className="w-full md:w-auto md:min-w-[310px] rounded-2xl md:rounded-t-2xl md:rounded-b-none bg-[#161618] hover:bg-[#1b1c20] border border-[#27272a] md:border-b-0 md:border-t md:border-x hover:border-[#ff7300]/40 px-4 sm:px-5 py-3 shadow-2xl flex items-center justify-between relative overflow-visible transition-all duration-300 hover:-translate-y-1 cursor-pointer group"
              title="Click to view full Account Information"
            >
              <div className="flex flex-col pr-3">
                <div className="flex items-center gap-2">
                  {discordUser?.avatarUrl ? (
                    <div className="relative">
                      <img
                        src={discordUser.avatarUrl}
                        alt="Discord Avatar"
                        className="w-6 h-6 rounded-full border border-[#5865F2] ring-2 ring-[#5865F2]/30 flex-shrink-0"
                      />
                      <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 ring-1 ring-black" />
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-[#ff7300]/20 border border-[#ff7300]/50 flex items-center justify-center text-[10px] font-bold text-[#ff7300]">
                      {(mcUsername || "P")[0].toUpperCase()}
                    </div>
                  )}

                  <div className="flex flex-col">
                    <span className="font-black text-white text-sm sm:text-base group-hover:text-[#ff9500] transition-colors truncate max-w-[140px] leading-tight">
                      {discordUser?.globalName || discordUser?.username || mcUsername || "Player"}
                    </span>
                    {discordUser && (
                      <span className="text-[10px] text-[#5865F2] font-semibold flex items-center gap-1">
                        @{discordUser.username}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 mt-1.5">
                  <span className="text-xs text-[#ff9500] font-bold flex items-center gap-1">
                    <span>0 QQ</span>
                    <span className="text-[10px] text-[#71717a] font-normal">· Coins</span>
                  </span>
                  <span className="text-[10px] text-[#38bdf8] font-semibold flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform">
                    <span>Account Info</span>
                    <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                    </svg>
                  </span>
                </div>
              </div>

              <div className="relative -mt-12 mr-1 flex-shrink-0">
                <img
                  src={`https://mc-heads.net/body/${mcUsername || (discordUser?.username ? discordUser.username : "Steve")}`}
                  alt="Player"
                  className="h-24 w-auto object-contain drop-shadow-[0_12px_20px_rgba(0,0,0,0.7)] player-animated hover:scale-110 transition-transform"
                  onError={(e) => { (e.target as HTMLImageElement).src = "https://mc-heads.net/body/Steve"; }}
                />
              </div>
            </div>
          ) : (
            /* ── NOT LOGGED IN: Prominent Discord Login Option ── */
            <div className="w-full md:w-auto md:min-w-[310px] rounded-2xl md:rounded-t-2xl md:rounded-b-none bg-[#161618] border border-[#27272a] md:border-b-0 md:border-t md:border-x px-4 sm:px-5 py-3 shadow-2xl flex items-center justify-between relative overflow-visible transition-transform duration-300 hover:-translate-y-1">
              <div className="flex flex-col gap-1.5 pr-2">
                {/* Discord Login Button */}
                <button
                  onClick={handleDiscordLogin}
                  disabled={isDiscordConnecting}
                  className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-[#5865F2] hover:bg-[#4752c4] active:scale-95 text-white font-black text-xs shadow-[0_0_18px_rgba(88,101,242,0.45)] hover:shadow-[0_0_24px_rgba(88,101,242,0.65)] transition-all cursor-pointer group"
                >
                  <svg className="w-4 h-4 fill-current group-hover:scale-110 transition-transform" viewBox="0 0 127.14 96.36">
                    <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z"/>
                  </svg>
                  <span>{isDiscordConnecting ? "Connecting..." : "Login with Discord"}</span>
                </button>

                <div className="flex items-center gap-1.5 text-[11px] text-[#a1a1aa]">
                  <span className="text-[#ff9500] font-semibold">0 QQ Coins</span>
                  <span className="text-[#52525b]">·</span>
                  <button
                    onClick={() => setShowLoginModal(true)}
                    className="text-[#71717a] hover:text-white underline transition-colors cursor-pointer"
                  >
                    or enter IGN
                  </button>
                </div>
              </div>

              <div
                className="relative -mt-12 mr-1 flex-shrink-0 cursor-pointer"
                onClick={() => setShowLoginModal(true)}
                title="Click to enter Minecraft IGN"
              >
                <img
                  src="https://mc-heads.net/body/Steve"
                  alt="Guest Player"
                  className="h-24 w-auto object-contain drop-shadow-[0_12px_20px_rgba(0,0,0,0.7)] player-animated hover:scale-110 transition-transform opacity-95 hover:opacity-100"
                />
              </div>
            </div>
          )}

        </div>

      </header>

      {/* ═══════════════════════════════════════════════════════════════════
          MAIN CONTENT AREA — Sidebar + Store Products
      ═══════════════════════════════════════════════════════════════════ */}
      <div className="max-w-[1520px] mx-auto px-3 sm:px-5 mt-4 sm:mt-6 flex flex-col lg:flex-row gap-4 sm:gap-6 pb-8 sm:pb-12">

        {/* ─── LEFT SIDEBAR ──────────────────────────────────────────── */}
        {/* ─── LEFT SIDEBAR (Exactly matches user screenshot) ──────────── */}
        <aside
          onClick={(e) => {
            if (e.target === e.currentTarget) setSidebarOpen(false);
          }}
          className={`${sidebarOpen ? "fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex justify-end lg:relative lg:inset-auto lg:bg-transparent lg:backdrop-blur-none lg:block" : "hidden lg:flex"} w-full lg:w-[300px] xl:w-[330px] flex-shrink-0`}
        >
          <div className={`${sidebarOpen ? "relative h-full w-[85%] max-w-[340px] sm:w-[320px] bg-[#09090b] border-l border-[#27272a] p-4 overflow-y-auto lg:relative lg:w-full lg:max-w-none lg:bg-transparent lg:border-0 lg:p-0 shadow-2xl" : ""} flex flex-col gap-3.5`}>
            {/* Mobile sidebar close button */}
            {sidebarOpen && (
              <button
                onClick={() => setSidebarOpen(false)}
                className="lg:hidden self-end p-2 mb-2 text-[#a1a1aa] hover:text-white transition-colors rounded-lg bg-[#18181b] border border-[#27272a] cursor-pointer"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}

          {/* 1. Category Buttons Stack */}
          <div className="flex flex-col gap-2.5">
            {/* Home Item */}
            <div className="relative">
              {selectedCategorySlug === "" && (
                <span className="absolute -left-2.5 top-1/2 -translate-y-1/2 w-1.5 h-7 bg-[#ff7300] rounded-r-full shadow-[0_0_10px_rgba(255,115,0,0.85)] z-20" />
              )}
              <button
                onClick={() => { setSelectedCategorySlug(""); setSidebarOpen(false); }}
                className={`w-full rounded-xl bg-[#231b14] hover:bg-[#2c2219] transition-all flex items-stretch overflow-hidden border ${
                  selectedCategorySlug === "" ? "border-[#ff7300]/50 shadow-[0_0_15px_rgba(255,115,0,0.15)]" : "border-[#34261b]"
                } cursor-pointer group`}
              >
                <div className="w-14 h-14 bg-[#1e1711] flex items-center justify-center border-r border-[#34261b] flex-shrink-0 group-hover:bg-[#261c14] transition-colors">
                  <svg className="w-7 h-7 fill-[#ff7300]" viewBox="0 0 24 24">
                    <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" />
                  </svg>
                </div>
                <div className="px-4 flex items-center justify-between flex-1">
                  <span className={`text-sm font-bold tracking-wide ${selectedCategorySlug === "" ? "text-[#ff7300]" : "text-white/90 group-hover:text-white"}`}>
                    Home
                  </span>
                </div>
              </button>
            </div>

            {/* Dynamic Categories */}
            {STATIC_CATEGORIES.map((cat) => {
              const isSelected = selectedCategorySlug === cat.slug;
              const isExpanded = expandedCategory === cat.slug;
              const hasSubs = cat.subcategories.length > 0;

              return (
                <div key={cat.idx} className="relative flex flex-col gap-1.5">
                  {isSelected && (
                    <span className="absolute -left-2.5 top-7 -translate-y-1/2 w-1.5 h-7 bg-[#ff7300] rounded-r-full shadow-[0_0_10px_rgba(255,115,0,0.85)] z-20" />
                  )}
                  <button
                    onClick={() => {
                      setSelectedCategorySlug(cat.slug);
                      if (hasSubs) {
                        setExpandedCategory(isExpanded ? null : cat.slug);
                      }
                      if (!hasSubs) setSidebarOpen(false);
                    }}
                    className={`w-full rounded-xl bg-[#231b14] hover:bg-[#2c2219] transition-all flex items-stretch overflow-hidden border ${
                      isSelected ? "border-[#ff7300]/50 shadow-[0_0_15px_rgba(255,115,0,0.15)]" : "border-[#34261b]"
                    } cursor-pointer group`}
                  >
                    <div className="w-14 h-14 bg-[#1e1711] flex items-center justify-center border-r border-[#34261b] p-2 flex-shrink-0 group-hover:bg-[#261c14] transition-colors">
                      {cat.img ? (
                        <img
                          src={cat.img}
                          alt={cat.name}
                          className="w-10 h-10 object-contain drop-shadow-[0_2px_8px_rgba(0,0,0,0.5)] group-hover:scale-105 transition-transform"
                          onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                        />
                      ) : (
                        <div className="w-9 h-9 rounded-lg bg-[#27272a] flex items-center justify-center text-sm font-black text-[#ff7300]">
                          {cat.name.charAt(0)}
                        </div>
                      )}
                    </div>
                    <div className="px-4 flex items-center justify-between flex-1">
                      <span className={`text-sm font-bold tracking-wide ${isSelected ? "text-[#ff7300]" : "text-white/90 group-hover:text-white"}`}>
                        {cat.name}
                      </span>
                      {hasSubs && (
                        <svg className={`w-4 h-4 text-[#8b827a] transition-transform ${isExpanded ? "rotate-180 text-[#ff7300]" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                      )}
                    </div>
                  </button>

                  {/* Subcategories */}
                  {hasSubs && isExpanded && (
                    <div className="ml-5 flex flex-col gap-1.5 pl-3 border-l-2 border-[#ff7300]/30 py-1">
                      {cat.subcategories.map((sub) => {
                        const isSubSelected = selectedCategorySlug === sub.slug;
                        return (
                          <button
                            key={sub.idx}
                            onClick={() => { setSelectedCategorySlug(sub.slug); setSidebarOpen(false); }}
                            className={`w-full px-3.5 py-2.5 rounded-lg text-left text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                              isSubSelected
                                ? "bg-[#ff7300]/20 text-[#ff7300] border border-[#ff7300]/40"
                                : "bg-[#231b14] text-[#a1a1aa] hover:text-white hover:bg-[#2c2219] border border-[#34261b]"
                            }`}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${isSubSelected ? "bg-[#ff7300]" : "bg-current"}`} />
                            <span>{sub.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* 2. Top Supporter & Recent Payments Combined Card */}
          <div className="rounded-2xl bg-[#1a140e] border border-[#2a1d13] p-4 flex flex-col gap-3.5 shadow-xl">
            
            {/* Top Supporter Header Pill */}
            <div className="rounded-lg bg-[#231b14] py-2 px-3 flex items-center justify-center gap-2 border border-[#34261b]">
              <svg className="w-4 h-4 fill-white" viewBox="0 0 24 24">
                <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5m14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z" />
              </svg>
              <span className="text-xs font-black text-white tracking-wide">Top Supporter</span>
            </div>

            {/* Top Supporter Profile */}
            <div className="flex items-center gap-3.5 px-2 py-1">
              <img
                src="https://mc-heads.net/body/Baffettoh"
                alt="Baffettoh"
                className="h-20 w-auto object-contain flex-shrink-0 drop-shadow-[0_4px_12px_rgba(0,0,0,0.6)]"
                onError={(e) => { (e.target as HTMLImageElement).src = "https://mc-heads.net/body/Steve"; }}
              />
              <div className="flex flex-col justify-center">
                <span className="text-base font-black text-[#ff7300] tracking-wide">
                  {TOP_SUPPORTER.username}
                </span>
                <span className="text-xs text-[#8c827a] font-medium leading-tight mt-0.5">
                  Spent the most this month
                </span>
              </div>
            </div>

            {/* Recent Payments Header Pill */}
            <div className="rounded-lg bg-[#231b14] py-2 px-3 flex items-center justify-center gap-2 border border-[#34261b]">
              <span className="text-xs font-black text-white tracking-wide">Recent Payments</span>
              <span className="text-sm">🚀</span>
            </div>

            {/* 2x5 Grid of Recent Donators (10 Avatars Matching Screenshot) */}
            <div className="grid grid-cols-5 gap-2 pt-0.5">
              {[
                { name: "Steve", url: "https://mc-heads.net/avatar/Steve/64" },
                { name: "Baffettoh", url: "https://mc-heads.net/avatar/Baffettoh/64" },
                { name: "Notch", url: "https://mc-heads.net/avatar/Notch/64" },
                { name: "PlayerOne", url: "https://mc-heads.net/avatar/Steve/64" },
                { name: "CraftKing", url: "https://mc-heads.net/avatar/Steve/64" },
                { name: "Alex", url: "https://mc-heads.net/avatar/Alex/64" },
                { name: "Dinnerbone", url: "https://mc-heads.net/avatar/Dinnerbone/64" },
                { name: "Jeb_", url: "https://mc-heads.net/avatar/Jeb_/64" },
                { name: "DiamondPro", url: "https://mc-heads.net/avatar/Steve/64" },
                { name: "YaHabivo", url: "https://mc-heads.net/avatar/YaHabivo/64" },
              ].map((donor, idx) => (
                <div
                  key={idx}
                  className="aspect-square rounded-lg bg-[#231b14] border border-[#34261b] hover:border-[#ff7300] overflow-hidden hover:scale-110 transition-all duration-200 cursor-pointer shadow-sm"
                  title={donor.name}
                >
                  <img
                    src={donor.url}
                    alt={donor.name}
                    className="w-full h-full object-cover"
                    onError={(e) => { (e.target as HTMLImageElement).src = "https://mc-heads.net/avatar/Steve/64"; }}
                  />
                </div>
              ))}
            </div>

          </div>

          {/* 3. Top Patrons Pickaxe Button */}
          <button
            onClick={() => showToast("Top patrons leaderboard opened")}
            className="w-full py-3.5 rounded-xl bg-[#231b14] border border-[#ff7300] hover:bg-[#ff7300] hover:text-black text-white font-bold text-sm tracking-wide flex items-center justify-center gap-2.5 transition-all shadow-[0_0_15px_rgba(255,115,0,0.15)] hover:shadow-[0_0_25px_rgba(255,115,0,0.5)] cursor-pointer group"
          >
            <svg className="w-4 h-4 fill-[#ff7300] group-hover:fill-black transition-colors" viewBox="0 0 24 24">
              <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6-9.9 9.9a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l9.9-9.9 1.6 1.6a1 1 0 0 0 1.4 0l1.4-1.4a1 1 0 0 0 0-1.4l-7.6-7.6a1 1 0 0 0-1.4 0l-1.4 1.4zM21.7 2.3a1 1 0 0 0-1.4 0l-2.6 2.6 2.8 2.8 2.6-2.6a1 1 0 0 0 0-1.4l-1.4-1.4z" />
            </svg>
            <span>Top Patrons</span>
          </button>

          </div>
        </aside>

        {/* ─── MAIN CONTENT ──────────────────────────────────────────── */}
        <main className="flex-1 min-w-0 flex flex-col gap-4 sm:gap-6 overflow-x-hidden">

          {/* Welcome / Alert Section (Shown on Home / No Category selected) */}
          {selectedCategorySlug === "" && (
            <div className="flex flex-col gap-4 sm:gap-5">
              
              {/* 1. Main Welcome & Announcement Hero Banner */}
              <div className="relative rounded-2xl bg-gradient-to-b from-[#1c140e] via-[#141210] to-[#0d0c0c] border border-[#ff7300]/30 overflow-hidden shadow-[0_12px_40px_rgba(0,0,0,0.65)] p-5 sm:p-7">
                {/* Top Subtle Glowing Orange Line */}
                <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#ff7300] to-transparent" />
                <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-32 bg-[#ff7300]/15 rounded-full blur-3xl pointer-events-none" />

                <div className="relative z-10 flex flex-col gap-4">
                  {/* Top Badge Strip */}
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#ff7300]/15 border border-[#ff7300]/35 text-[#ff9500] text-[11px] font-black uppercase tracking-wider shadow-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#ff7300] animate-pulse" />
                      Official Store Notice
                    </span>
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-white/80 text-[11px] font-semibold tracking-wide">
                      <svg className="w-3.5 h-3.5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                      </svg>
                      Instant In-Game Delivery
                    </span>
                  </div>

                  {/* Title & Description */}
                  <div>
                    <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-snug">
                      Welcome to the Official <span className="bg-gradient-to-r from-[#ff7300] via-[#ffa133] to-[#ffc04d] bg-clip-text text-transparent">PikaNetwork Store</span>
                    </h2>
                    <p className="text-xs sm:text-sm text-[#c0b3a8] leading-relaxed mt-1.5 max-w-3xl">
                      Select a category from the sidebar to browse our game modes, ranks, command perks, and exclusive crate keys. All rank purchases are a <span className="text-white font-bold underline decoration-[#ff7300]/60 underline-offset-2">one-time payment</span> that unlock permanent lifetime perks with zero recurring fees.
                    </p>
                  </div>

                  {/* Fast Stat Trust Strip */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
                    <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-white/[0.03] border border-white/5">
                      <div className="w-8 h-8 rounded-lg bg-[#ff7300]/15 border border-[#ff7300]/30 flex items-center justify-center text-[#ff7300] flex-shrink-0">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
                        </svg>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-white leading-tight">Instant Delivery</span>
                        <span className="text-[10px] text-[#8c827a]">Auto-synced in 1-5 mins</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-white/[0.03] border border-white/5">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 flex-shrink-0">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z" />
                        </svg>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-white leading-tight">Permanent Perks</span>
                        <span className="text-[10px] text-[#8c827a]">No recurring subscriptions</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-white/[0.03] border border-white/5">
                      <div className="w-8 h-8 rounded-lg bg-[#5865F2]/15 border border-[#5865F2]/30 flex items-center justify-center text-[#5865F2] flex-shrink-0">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
                        </svg>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-white leading-tight">256-Bit SSL Encrypted</span>
                        <span className="text-[10px] text-[#8c827a]">Trusted payment security</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. Professional 2x2 Information Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                
                {/* Info Card 1: Support / Questions */}
                <div className="rounded-2xl bg-[#141210] border border-[#2a2018] hover:border-[#ff7300]/40 p-4 sm:p-5 flex flex-col justify-between transition-all duration-200 group shadow-lg">
                  <div className="flex items-start gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-[#ff7300]/15 border border-[#ff7300]/30 flex items-center justify-center text-[#ff7300] flex-shrink-0 group-hover:scale-105 transition-transform">
                      <svg className="w-5 h-5 fill-current" viewBox="0 0 127.14 96.36">
                        <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z"/>
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-[#ff9500] transition-colors">
                        Need Help or Support?
                      </h3>
                      <p className="text-xs text-[#a89b8f] leading-relaxed mt-1">
                        Have pre-checkout questions or package inquiries? Our staff team and community are active 24/7 on Discord to resolve your issues immediately.
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-[#2a2018] flex items-center justify-between">
                    <span className="text-[11px] text-[#786c62] font-medium">Average reply: &lt;15 mins</span>
                    <a
                      href="https://pika-network.net/discord"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-[#ff9500] hover:text-[#ffaa33] font-bold flex items-center gap-1 group/btn"
                    >
                      <span>Discord Support</span>
                      <svg className="w-3.5 h-3.5 group-hover/btn:translate-x-0.5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                      </svg>
                    </a>
                  </div>
                </div>

                {/* Info Card 2: Refund Policy */}
                <div className="rounded-2xl bg-[#141210] border border-[#2a2018] hover:border-red-500/30 p-4 sm:p-5 flex flex-col justify-between transition-all duration-200 group shadow-lg">
                  <div className="flex items-start gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-red-500/15 border border-red-500/30 flex items-center justify-center text-red-400 flex-shrink-0 group-hover:scale-105 transition-transform">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m0-10.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285zM12 15.75h.007v.008H12v-.008z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-red-300 transition-colors">
                        Strict Refund Policy
                      </h3>
                      <p className="text-xs text-[#a89b8f] leading-relaxed mt-1">
                        All payments are final digital goods. Initiating a chargeback or opening a payment dispute results in an immediate and irreversible permanent ban across all network servers.
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-[#2a2018] flex items-center justify-between">
                    <span className="text-[11px] text-[#786c62] font-medium">Digital Goods Terms</span>
                    <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded bg-red-500/15 text-red-400 border border-red-500/25">
                      Non-Refundable
                    </span>
                  </div>
                </div>

                {/* Info Card 3: Automated In-Game Delivery */}
                <div className="rounded-2xl bg-[#141210] border border-[#2a2018] hover:border-emerald-500/30 p-4 sm:p-5 flex flex-col justify-between transition-all duration-200 group shadow-lg">
                  <div className="flex items-start gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 flex-shrink-0 group-hover:scale-105 transition-transform">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 006.16-12.12A14.98 14.98 0 009.631 8.41m5.96 5.96a14.926 14.926 0 01-5.841 2.58m-.119-8.54a6 6 0 00-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 00-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 01-2.448-2.448 14.9 14.9 0 01.06-.312m-2.24 2.39a4.493 4.493 0 00-1.757 4.306 4.493 4.493 0 004.306-1.758M16.5 9a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-emerald-300 transition-colors">
                        Automated Delivery (1–20 Mins)
                      </h3>
                      <p className="text-xs text-[#a89b8f] leading-relaxed mt-1">
                        Packages credit automatically to your Minecraft IGN. Please ensure your inventory has sufficient empty slots and you are logged in to receive items and keys.
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-[#2a2018] flex items-center justify-between">
                    <span className="text-[11px] text-[#786c62] font-medium">Automatic sync engine</span>
                    <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/25">
                      ✓ Auto Active
                    </span>
                  </div>
                </div>

                {/* Info Card 4: Compliance & Commercial Rights */}
                <div className="rounded-2xl bg-[#141210] border border-[#2a2018] hover:border-cyan-500/30 p-4 sm:p-5 flex flex-col justify-between transition-all duration-200 group shadow-lg">
                  <div className="flex items-start gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 flex-shrink-0 group-hover:scale-105 transition-transform">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                        Mojang EULA Compliant
                      </h3>
                      <p className="text-xs text-[#a89b8f] leading-relaxed mt-1">
                        Our packages and cosmetics are 100% compliant with Mojang commercial guidelines. All payments are verified with complete fraud protection and secure checkouts.
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-[#2a2018] flex items-center justify-between">
                    <span className="text-[11px] text-[#786c62] font-medium">Safe & fair play</span>
                    <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded bg-cyan-500/15 text-cyan-400 border border-cyan-500/25">
                      ✓ EULA Verified
                    </span>
                  </div>
                </div>

              </div>

              {/* 3. High-End Gift Card & Coupon Redeem Card */}
              <div className="rounded-2xl bg-gradient-to-r from-[#171412] via-[#151210] to-[#121113] border border-[#34261b] hover:border-[#ff7300]/40 p-4 sm:p-5 shadow-xl transition-all">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  {/* Left: Title & Description */}
                  <div className="flex items-center gap-3.5">
                    <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#ff7300] to-[#ff9500] text-black flex items-center justify-center shadow-[0_4px_16px_rgba(255,115,0,0.35)] flex-shrink-0">
                      <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                        <path d="M20 6h-2.18c.11-.31.18-.65.18-1a3 3 0 0 0-3-3c-1.05 0-1.96.54-2.5 1.35l-.5.65-.5-.65C10.96 2.54 10.05 2 9 2a3 3 0 0 0-3 3c0 .35.07.69.18 1H4a2 2 0 0 0-2 2v3a1 1 0 0 0 1 1h1v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-9h1a1 1 0 0 0 1-1V8a2 2 0 0 0-2-2zM9 4a1 1 0 0 1 1 1c0 .55-.45 1-1 1s-1-.45-1-1a1 1 0 0 1 1-1zm6 0a1 1 0 0 1 1 1c0 .55-.45 1-1 1s-1-.45-1-1a1 1 0 0 1 1-1zm3 16H6v-9h12v9z"/>
                      </svg>
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-white tracking-wide">
                        Redeem Gift Card or Voucher
                      </h4>
                      <p className="text-xs text-[#a89b8f] mt-0.5">
                        Have a promotional voucher, store gift card, or creator discount code?
                      </p>
                    </div>
                  </div>

                  {/* Right: Input and Button */}
                  <div className="flex items-center gap-2 w-full md:w-auto">
                    <div className="relative flex-1 md:w-64">
                      <input
                        value={giftCardCode}
                        onChange={(e) => setGiftCardCode(e.target.value.toUpperCase())}
                        placeholder="ENTER CODE (E.G. PIKA2026)"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#09090b] text-white text-xs font-mono font-bold tracking-wider border border-[#34261b] focus:border-[#ff7300] focus:ring-1 focus:ring-[#ff7300]/50 focus:outline-none transition-all placeholder:text-[#52525b] placeholder:font-sans placeholder:normal-case placeholder:tracking-normal"
                      />
                    </div>
                    <button
                      onClick={() => {
                        if (giftCardCode.trim()) {
                          showToast(`Checking gift card "${giftCardCode.trim()}"...`);
                          setTimeout(() => {
                            showToast("Gift card code invalid or expired.");
                          }, 700);
                        } else {
                          showToast("Please enter a card code first.");
                        }
                      }}
                      className="px-5 py-2.5 rounded-xl bg-[#ff7300] hover:bg-[#ff851a] active:scale-95 text-black font-['Plus_Jakarta_Sans',sans-serif] font-black text-xs tracking-wide shadow-[0_4px_16px_rgba(255,115,0,0.3)] transition-all cursor-pointer flex-shrink-0"
                    >
                      Redeem
                    </button>
                  </div>
                </div>
              </div>

              {/* 4. Sleek Payment Gateways Showcase */}
              <div className="rounded-2xl bg-[#141210] border border-[#2a2018] p-4 sm:p-5 shadow-lg">
                <div className="flex items-center justify-between pb-3.5 mb-3.5 border-b border-[#2a2018]">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-black uppercase text-[#ff9500] tracking-wider">
                      Accepted Payment Methods
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] text-[#22c55e] font-semibold">
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z" />
                    </svg>
                    <span>256-Bit SSL Secured</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {/* PayPal */}
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-[#1b1714] border border-[#34261b] hover:border-[#0079C1]/50 transition-all group">
                    <div className="w-9 h-9 rounded-lg bg-[#003087]/20 border border-[#003087]/40 flex items-center justify-center flex-shrink-0 text-[#0079C1] group-hover:scale-105 transition-transform">
                      <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                        <path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944.901C5.006.402 5.43 0 5.933 0h7.822c3.483 0 5.674 1.745 5.093 5.344-.45 2.791-2.14 4.542-4.787 4.542h-2.138l-1.082 6.84-.286 1.81a.641.641 0 0 1-.633.541H7.076zM15.42 4.908c.24-1.488-.592-2.316-2.315-2.316H7.818L6.47 11.13h2.645c2.404 0 4.148-1.05 4.606-3.882.23-1.424-.04-2.02-.3-2.34z"/>
                      </svg>
                    </div>
                    <div className="overflow-hidden">
                      <span className="text-xs font-black text-white block leading-tight">PayPal</span>
                      <span className="text-[10px] text-[#8c827a] block truncate">Balance & Bank</span>
                    </div>
                  </div>

                  {/* Visa & Mastercard */}
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-[#1b1714] border border-[#34261b] hover:border-[#ff7300]/50 transition-all group">
                    <div className="w-9 h-9 rounded-lg bg-[#ff7300]/15 border border-[#ff7300]/30 flex items-center justify-center flex-shrink-0 text-[#ff7300] group-hover:scale-105 transition-transform">
                      <svg className="w-4 h-4 fill-none stroke-current" viewBox="0 0 24 24" strokeWidth="2">
                        <rect x="2" y="5" width="20" height="14" rx="3" />
                        <line x1="2" y1="10" x2="22" y2="10" />
                      </svg>
                    </div>
                    <div className="overflow-hidden">
                      <span className="text-xs font-black text-white block leading-tight">Cards</span>
                      <span className="text-[10px] text-[#8c827a] block truncate">Visa, Mastercard</span>
                    </div>
                  </div>

                  {/* Stripe */}
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-[#1b1714] border border-[#34261b] hover:border-[#635BFF]/50 transition-all group">
                    <div className="w-9 h-9 rounded-lg bg-[#635BFF]/15 border border-[#635BFF]/30 flex items-center justify-center flex-shrink-0 text-[#635BFF] group-hover:scale-105 transition-transform">
                      <span className="text-xs font-black tracking-tighter">stripe</span>
                    </div>
                    <div className="overflow-hidden">
                      <span className="text-xs font-black text-white block leading-tight">Stripe</span>
                      <span className="text-[10px] text-[#8c827a] block truncate">100+ Gateways</span>
                    </div>
                  </div>

                  {/* Crypto & Wallets */}
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-[#1b1714] border border-[#34261b] hover:border-amber-500/50 transition-all group">
                    <div className="w-9 h-9 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center flex-shrink-0 text-amber-400 group-hover:scale-105 transition-transform">
                      <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                        <path d="M23.638 14.904c-1.602 6.43-8.113 10.34-14.542 8.736C2.67 22.05-1.244 15.525.362 9.105 1.962 2.67 8.475-1.243 14.9.358c6.43 1.605 10.342 8.115 8.738 14.546zM15.4 10.373c.224-1.498-.918-2.304-2.48-2.842l.507-2.032-1.238-.31-.493 1.978c-.326-.081-.662-.16-1-.237l.498-1.992-1.237-.31-.508 2.035c-.269-.061-.533-.122-.789-.187l.002-.007-1.708-.426-.33 1.323s.92.21.9.224c.502.125.593.457.578.72l-.58 2.325c.035.008.08.02.13.041l-.134-.033-.812 3.257c-.062.152-.218.381-.57.293.02.029-.9.225-.9.225l-.616 1.42 1.611.402c.3.075.594.153.882.227l-.513 2.06 1.237.31.508-2.037c.338.092.666.177.986.257l-.504 2.02 1.238.31.513-2.057c2.112.4 3.7.239 4.368-1.672.54-1.539-.027-2.427-1.14-3.006.811-.188 1.42-.72 1.584-1.821zm-2.836 3.978c-.383 1.54-2.977.708-3.818.5l.681-2.731c.841.21 3.535.626 3.137 2.231zm.384-3.992c-.35 1.4-2.51.688-3.212.513l.618-2.477c.703.175 2.955.503 2.594 1.964z"/>
                      </svg>
                    </div>
                    <div className="overflow-hidden">
                      <span className="text-xs font-black text-white block leading-tight">Crypto & Web3</span>
                      <span className="text-[10px] text-[#8c827a] block truncate">BTC, ETH, USDT</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* ─── FEATURED DEALS (On Home Page) ─────────────────────── */}
          {selectedCategorySlug === "" && (
            <div className="pt-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-5 pb-3 border-b border-[#34261b]/60">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-sm">
                    <svg className="w-4.5 h-4.5 fill-current" viewBox="0 0 24 24">
                      <path d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279L12 19.771l-7.416 3.642 1.48-8.279L0 9.306l8.332-1.151z" />
                    </svg>
                  </div>
                  <div>
                    <h2 className="text-lg sm:text-xl font-['Plus_Jakarta_Sans',sans-serif] font-black text-white tracking-wide uppercase leading-tight">
                      Featured Packages
                    </h2>
                    <p className="text-xs text-[#8c827a] font-medium leading-none mt-0.5">
                      Most popular rank upgrades and bundles chosen by players
                    </p>
                  </div>
                </div>

                <span className="text-[11px] font-bold text-[#ff9500] uppercase tracking-wider hidden sm:inline-block">
                  ⚡ Lifetime Upgrades
                </span>
              </div>
              <div className="grid grid-cols-1 xs:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-5">
                {FEATURED_DEALS.map((deal) => (
                  <ProductCard
                    key={deal.id}
                    product={deal}
                    onSelect={() => setSelectedProduct(deal)}
                    onAddToCart={(isSub) =>
                      addToCart({
                        id: String(deal.id),
                        name: deal.name,
                        description: deal.description,
                        price: deal.price,
                        originalPrice: deal.originalPrice,
                        categoryId: "featured",
                        thumbnail: deal.image,
                        featured: true,
                        active: true,
                      } as Product, isSub)
                    }
                    currency={currency}
                    convertPrice={convertPrice}
                  />
                ))}
              </div>
            </div>
          )}

          {/* ─── CATEGORY PRODUCTS VIEW ──────────────────────────────── */}
          {selectedCategorySlug !== "" && (
            <div>
              {/* Category Header banner */}
              <div className="relative rounded-2xl bg-gradient-to-r from-[#1c140e] via-[#161210] to-[#121113] border border-[#ff7300]/30 p-5 sm:p-6 mb-5 sm:mb-6 shadow-xl overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#ff7300] to-transparent" />
                {(() => {
                  const cat = STATIC_CATEGORIES.find((c) => c.slug === selectedCategorySlug);
                  const subCat = STATIC_CATEGORIES.flatMap((c) => c.subcategories).find((s) => s.slug === selectedCategorySlug);
                  const displayCat = cat || subCat;
                  return displayCat ? (
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                        {cat?.img ? (
                          <div className="w-14 h-14 rounded-2xl bg-[#231b14] border border-[#34261b] p-2 flex items-center justify-center flex-shrink-0 shadow-lg">
                            <img src={cat.img} alt="" className="w-10 h-10 object-contain drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)]" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                          </div>
                        ) : (
                          <div className="w-14 h-14 rounded-2xl bg-[#ff7300]/15 border border-[#ff7300]/30 flex items-center justify-center text-[#ff7300] text-xl font-black flex-shrink-0 shadow-lg">
                            ★
                          </div>
                        )}
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-bold text-[#ff9500] uppercase tracking-wider">
                              Category View
                            </span>
                            <span className="text-[#52525b]">·</span>
                            <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                              Active Perks
                            </span>
                          </div>
                          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">{displayCat.name}</h2>
                          <div className="text-xs sm:text-sm text-[#a89b8f] mt-1 leading-relaxed max-w-2xl" dangerouslySetInnerHTML={{ __html: displayCat.description }} />
                        </div>
                      </div>

                      <button
                        onClick={() => setSelectedCategorySlug("")}
                        className="self-start sm:self-center px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
                        </svg>
                        <span>Back to Home</span>
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <h2 className="text-xl font-bold text-white capitalize">{selectedCategorySlug.replace(/-/g, " ")}</h2>
                      <button
                        onClick={() => setSelectedCategorySlug("")}
                        className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white text-xs font-bold transition-all cursor-pointer"
                      >
                        Back to Home
                      </button>
                    </div>
                  );
                })()}
              </div>

              {/* Product grid */}
              {loading ? (
                <div className="flex items-center justify-center py-20">
                  <div className="w-8 h-8 border-3 border-[#ff7300]/30 border-t-[#ff7300] rounded-full animate-spin" />
                </div>
              ) : activeCategoryProducts.length > 0 ? (
                <div className="grid grid-cols-1 xs:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-5">
                  {activeCategoryProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onSelect={() => setSelectedProduct(product)}
                      onAddToCart={(isSub) => addToCart(product, isSub)}
                      currency={currency}
                      convertPrice={convertPrice}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-20 text-[#71717a]">
                  No products found for this category.
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* Floating Category Drawer Button (Mobile Only) */}
      <div className="lg:hidden fixed bottom-5 right-5 z-40">
        <button
          onClick={() => setSidebarOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#ff7300] hover:bg-[#ff851a] active:scale-95 text-black font-extrabold text-xs shadow-[0_6px_24px_rgba(255,115,0,0.65)] transition-all cursor-pointer border-2 border-black"
          aria-label="Browse Categories"
        >
          <svg className="w-4 h-4 fill-none stroke-current" viewBox="0 0 24 24" strokeWidth="2.5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
          </svg>
          <span>Categories</span>
        </button>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════
          FOOTER SECTION — Identical to Main Page Footer (As Requested)
      ═══════════════════════════════════════════════════════════════════ */}
      <footer className="w-full bg-[#0a0503] mt-10 sm:mt-20 pt-8 sm:pt-10 pb-8 sm:pb-12 border-t border-[#ff6a00]/20 relative z-20">
        <div className="max-w-[1320px] mx-auto px-3 sm:px-4 md:px-6 flex flex-col gap-8 sm:gap-10">
          
          {/* Top Banner Strip in Orange Theme */}
          <div className="w-full rounded-2xl bg-gradient-to-r from-[#d84315] via-[#ff6a00] to-[#e65100] px-4 sm:px-5 md:px-8 py-3 sm:py-3.5 md:py-4 flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4 shadow-[0_8px_32px_rgba(255,106,0,0.45)] border border-[#ffa04d]/40 relative">
            
            {/* Left: 3D Mascot Logo + Server IP Text */}
            <div
              onClick={copyServerIp}
              className="flex items-center gap-3.5 cursor-pointer group"
              title="Click to copy server IP"
            >
              <img
                alt="PikaNetwork"
                className="w-10 sm:w-14 md:w-16 lg:w-20 h-auto object-contain -mt-4 sm:-mt-6 md:-mt-8 -mb-1 sm:-mb-2 drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)] group-hover:scale-105 transition-transform"
                src={LOGO_SRC}
              />
              
              <div className="flex flex-col">
                <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base sm:text-lg md:text-xl tracking-wider leading-tight group-hover:text-[#ffe4a0] transition-colors drop-shadow-sm">
                  {SERVER_IP.toUpperCase()}
                </span>
                <span className="flex items-center gap-1.5 text-[11px] font-black text-[#ffe4a0] tracking-wider uppercase drop-shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse"></span>
                  {copiedIp ? "COPIED TO CLIPBOARD!" : "ONLINE - CLICK TO COPY"}
                </span>
              </div>
            </div>

            {/* Right: Social Media Icons */}
            <div className="flex items-center gap-4 text-white">
              {/* Discord */}
              <a
                href="https://pika-network.net/discord"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#ffea00] hover:scale-110 transition-all"
                aria-label="Discord"
              >
                <svg className="w-6 h-6 fill-current" viewBox="0 0 127.14 96.36">
                  <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z"/>
                </svg>
              </a>

              {/* X / Twitter */}
              <a
                href="https://twitter.com/PikaNetworkMC"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#ffea00] hover:scale-110 transition-all"
                aria-label="X (Twitter)"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </a>

              {/* Instagram */}
              <a
                href="https://instagram.com/pikanetworkmc"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#ffea00] hover:scale-110 transition-all"
                aria-label="Instagram"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>
            </div>

          </div>

          {/* Main 3 Columns */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10 pt-4">
            
            {/* Column 1: ABOUT US */}
            <div className="flex flex-col gap-3">
              <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase">
                ABOUT US
              </h3>
              <p className="text-sm text-[#c9a48f] leading-relaxed">
                PikaNetwork is one of the largest Minecraft servers! Since the day PikaNetwork was formed, back in 2014, we have focused on bringing joy to the community. We offer many game modes, these being BedWars, OneBlock, KitPvP, OP Factions, OP Lifesteal, OP Prison, OP SkyBlock, Practice, SkyPvP, Survival and SkyMines!
              </p>
              <div className="text-sm text-white pt-1">
                <span className="text-[#c9a48f]">Come play at: </span>
                <strong className="text-[#ffea00] font-mono cursor-pointer hover:underline" onClick={copyServerIp}>
                  {SERVER_IP}
                </strong>
              </div>
            </div>

            {/* Column 2: LINKS */}
            <div className="flex flex-col gap-3">
              <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase">
                LINKS
              </h3>
              <ul className="flex flex-col gap-2 text-sm text-[#c9a48f]">
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Back to Top</span>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors">
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <a href={getMainSiteUrl("/")} className="hover:text-[#ffea00] transition-colors font-medium">
                    Home
                  </a>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer" onClick={() => showToast("Contact support form opened")}>
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Contact Us</span>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer" onClick={() => showToast("Terms & Conditions")}>
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Terms and Conditions</span>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer" onClick={() => showToast("Privacy Policy")}>
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Privacy Policy</span>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer" onClick={() => showToast("Responsible disclosure guidelines")}>
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Responsible disclosure</span>
                </li>
              </ul>
            </div>

            {/* Column 3: SUPPORT US */}
            <div className="flex flex-col gap-3">
              <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase">
                SUPPORT US
              </h3>
              <p className="text-sm text-[#c9a48f] leading-relaxed">
                Have you had a fun time here? Support us by purchasing packages such as ranks, commands, crate keys, and more!
              </p>
              <div className="pt-2">
                <button
                  onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
                  className="inline-flex items-center justify-center bg-[#ffea00] hover:bg-[#ffd700] text-[#1c1803] font-['Plus_Jakarta_Sans',sans-serif] font-extrabold text-sm px-7 py-2.5 rounded-xl shadow-[0_4px_16px_rgba(255,234,0,0.35)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
                >
                  Shop Now
                </button>
              </div>
            </div>

          </div>

          {/* Bottom Copyright & Disclaimer Row */}
          <div className="pt-4 sm:pt-6 border-t border-[#ff6a00]/15 flex items-start gap-3 sm:gap-3.5 text-xs text-[#8c7262]">
            <div className="w-8 h-8 rounded-lg bg-[#221008] border border-white/10 flex items-center justify-center text-slate-400 font-bold text-base flex-shrink-0 shadow-inner">
              G
            </div>

            <div className="flex flex-col gap-0.5">
              <div className="text-white font-bold">
                Copyright © CraftiGames B.V. 2026
              </div>
              <div className="text-[11px] text-[#8c7262]">
                We are not affiliated with Mojang or Minecraft.
              </div>
              <div className="text-[11px] text-[#8c7262]">
                We are not affiliated with Nintendo Co., Ltd.
              </div>
            </div>
          </div>

        </div>
      </footer>

      {/* ═══════════════════════════════════════════════════════════════════
          ACCOUNT INFORMATION MODAL
      ═══════════════════════════════════════════════════════════════════ */}
      {showAccountModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
          <div className="bg-[#141416] border border-[#27272a] rounded-2xl max-w-[500px] w-full p-4 sm:p-6 shadow-2xl relative animate-slideUp text-left max-h-[92vh] flex flex-col">
            {/* Close Button */}
            <button
              onClick={() => setShowAccountModal(false)}
              className="absolute top-4 right-4 text-[#71717a] hover:text-white transition-colors p-1.5 rounded-lg hover:bg-white/5 cursor-pointer"
              aria-label="Close"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            {/* Modal Header */}
            <div className="flex items-center gap-3 pb-4 border-b border-[#27272a]">
              <div className="w-10 h-10 rounded-xl bg-[#5865F2]/20 border border-[#5865F2]/40 flex items-center justify-center text-[#5865F2]">
                <svg className="w-6 h-6 fill-current" viewBox="0 0 127.14 96.36">
                  <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z"/>
                </svg>
              </div>
              <div>
                <h2 className="text-lg font-black text-white tracking-wide">Account Information</h2>
                <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Authenticated Session</span>
                </div>
              </div>
            </div>

            {/* Profile Information Body */}
            <div className="flex flex-col gap-4 py-4 max-h-[70vh] overflow-y-auto pr-1">
              
              {/* 1. Discord Profile Card */}
              {discordUser ? (
                <div className="p-4 rounded-xl bg-[#1a1b22] border border-[#5865F2]/30 flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-[#5865F2] uppercase tracking-wider flex items-center gap-1.5">
                      <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 127.14 96.36">
                        <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z"/>
                      </svg>
                      Discord Account
                    </span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-500/40">
                      Connected
                    </span>
                  </div>

                  <div className="flex items-center gap-3.5">
                    <img
                      src={discordUser.avatarUrl}
                      alt={discordUser.username}
                      className="w-14 h-14 rounded-full border-2 border-[#5865F2] ring-4 ring-[#5865F2]/20 object-cover shadow-lg"
                    />
                    <div className="flex flex-col">
                      <span className="font-extrabold text-white text-base leading-tight">
                        {discordUser.globalName || discordUser.username}
                      </span>
                      <span className="text-xs text-[#a1a1aa] font-medium">
                        @{discordUser.username}
                      </span>
                      {discordUser.email && (
                        <span className="text-[11px] text-[#71717a] mt-0.5">
                          {discordUser.email}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Discord User ID row */}
                  <div className="flex items-center justify-between bg-black/30 rounded-lg px-3 py-2 text-xs border border-white/5">
                    <span className="text-[#a1a1aa]">Discord ID:</span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-white/90 text-xs">{discordUser.id}</span>
                      <button
                        onClick={() => copyDiscordId(discordUser.id)}
                        className="text-[#ff9500] hover:text-[#ffaa33] transition-colors p-1 cursor-pointer"
                        title="Copy Discord ID"
                      >
                        {copiedDiscordId ? (
                          <span className="text-[10px] text-emerald-400 font-bold">Copied!</span>
                        ) : (
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.257c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184" />
                          </svg>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-[#1a1b22] border border-[#27272a] flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-[#5865F2]/20 flex items-center justify-center text-[#5865F2]">
                      <svg className="w-4 h-4 fill-current" viewBox="0 0 127.14 96.36">
                        <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z"/>
                      </svg>
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white block">Discord not connected</span>
                      <span className="text-[11px] text-[#71717a]">Link your Discord to sync roles & perks</span>
                    </div>
                  </div>
                  <button
                    onClick={handleDiscordLogin}
                    className="px-3 py-1.5 rounded-lg bg-[#5865F2] hover:bg-[#4752c4] text-white text-xs font-bold transition-all shadow-md cursor-pointer"
                  >
                    Link Discord
                  </button>
                </div>
              )}

              {/* 2. Minecraft In-Game Name Link */}
              <div className="p-4 rounded-xl bg-[#18181b] border border-[#27272a] flex flex-col gap-3">
                <span className="text-[11px] font-bold text-[#ff9500] uppercase tracking-wider">
                  Minecraft In-Game Identity
                </span>
                
                <div className="flex items-center gap-3">
                  <img
                    src={`https://mc-heads.net/avatar/${tempMinecraftIgn || mcUsername || "Steve"}/56`}
                    alt="Player Head"
                    className="w-12 h-12 rounded-lg border border-white/10 shadow-md bg-black/40"
                  />
                  <div className="flex-1">
                    <label className="text-[11px] text-[#a1a1aa] block mb-1">
                      Minecraft Username (Required for in-game delivery)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={tempMinecraftIgn}
                        onChange={(e) => setTempMinecraftIgn(e.target.value)}
                        placeholder="e.g. Steve"
                        className="flex-1 bg-black/40 border border-[#27272a] focus:border-[#ff7300] rounded-lg px-3 py-1.5 text-xs text-white outline-none transition-colors"
                      />
                      <button
                        onClick={handleSaveMinecraftIgn}
                        className="px-3 py-1.5 rounded-lg bg-[#ff7300] hover:bg-[#ff851a] text-white font-bold text-xs transition-colors cursor-pointer shadow-sm"
                      >
                        Save
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* 3. Wallet & Balance Stats */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-[#18181b] border border-[#27272a] flex flex-col">
                  <span className="text-[11px] text-[#71717a] font-medium">QQ Coin Balance</span>
                  <span className="text-lg font-black text-[#ff9500] mt-0.5">0 QQ</span>
                  <span className="text-[10px] text-[#52525b]">Earn coins with every purchase</span>
                </div>
                <div className="p-3.5 rounded-xl bg-[#18181b] border border-[#27272a] flex flex-col">
                  <span className="text-[11px] text-[#71717a] font-medium">Store Tier</span>
                  <span className="text-lg font-black text-white mt-0.5">Member</span>
                  <span className="text-[10px] text-emerald-400 font-semibold">Active Member</span>
                </div>
              </div>

            </div>

            {/* Modal Footer / Logout Actions */}
            <div className="pt-4 border-t border-[#27272a] flex items-center justify-between">
              <button
                onClick={handleLogout}
                className="px-4 py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 hover:text-red-300 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
                </svg>
                <span>Log Out</span>
              </button>

              <button
                onClick={() => setShowAccountModal(false)}
                className="px-5 py-2 rounded-xl bg-[#27272a] hover:bg-[#3f3f46] text-white font-bold text-xs transition-colors cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          LOGIN MODAL (Discord OAuth + Minecraft IGN)
      ═══════════════════════════════════════════════════════════════════ */}
      {showLoginModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
          <div className="bg-[#141416] border border-[#27272a] rounded-2xl max-w-[440px] w-full p-4 sm:p-6 shadow-2xl relative animate-slideUp text-left max-h-[92vh] overflow-y-auto">
            {/* Close Button */}
            <button
              onClick={() => setShowLoginModal(false)}
              className="absolute top-4 right-4 text-[#71717a] hover:text-white transition-colors p-1.5 rounded-lg hover:bg-white/5 cursor-pointer"
              aria-label="Close"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            {/* Modal Title */}
            <div className="mb-5">
              <h2 className="text-xl font-black text-white tracking-wide">Sign In to Store</h2>
              <p className="text-xs text-[#71717a] mt-1">
                Connect via Discord or enter your Minecraft in-game name
              </p>
            </div>

            {/* Tabs */}
            <div className="flex rounded-xl bg-black/40 p-1 border border-[#27272a] mb-5">
              <button
                onClick={() => setLoginTab("discord")}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  loginTab === "discord"
                    ? "bg-[#5865F2] text-white shadow-md shadow-[#5865F2]/30"
                    : "text-[#a1a1aa] hover:text-white"
                }`}
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 127.14 96.36">
                  <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z"/>
                </svg>
                <span>Discord</span>
              </button>
              <button
                onClick={() => setLoginTab("minecraft")}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  loginTab === "minecraft"
                    ? "bg-[#ff7300] text-white shadow-md shadow-[#ff7300]/30"
                    : "text-[#a1a1aa] hover:text-white"
                }`}
              >
                <span>Minecraft IGN</span>
              </button>
            </div>

            {/* Tab 1: Discord Content */}
            {loginTab === "discord" && (
              <div className="flex flex-col gap-4">
                <button
                  onClick={handleDiscordLogin}
                  disabled={isDiscordConnecting}
                  className="w-full py-3 px-4 rounded-xl bg-[#5865F2] hover:bg-[#4752c4] active:scale-[0.99] text-white font-extrabold text-sm flex items-center justify-center gap-2.5 transition-all shadow-lg shadow-[#5865F2]/25 cursor-pointer disabled:opacity-50"
                >
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 127.14 96.36">
                    <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z"/>
                  </svg>
                  <span>{isDiscordConnecting ? "Connecting to Discord..." : "Continue with Discord"}</span>
                </button>

                <div className="flex items-center gap-3 my-1">
                  <div className="flex-1 h-[1px] bg-[#27272a]" />
                  <span className="text-[11px] text-[#71717a] uppercase font-bold">Or Quick Sign-in</span>
                  <div className="flex-1 h-[1px] bg-[#27272a]" />
                </div>

                {/* Instant Dev / Demo username login */}
                <form onSubmit={handleCustomDiscordLogin} className="flex flex-col gap-2.5">
                  <label className="text-xs text-[#a1a1aa] font-medium">
                    Discord Username / Handle
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={customDiscordName}
                      onChange={(e) => setCustomDiscordName(e.target.value)}
                      placeholder="e.g. YaHabivo"
                      className="flex-1 bg-black/40 border border-[#27272a] focus:border-[#5865F2] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none transition-colors"
                    />
                    <button
                      type="submit"
                      disabled={isDiscordConnecting}
                      className="px-4 py-2.5 rounded-xl bg-[#27272a] hover:bg-[#3f3f46] text-white font-bold text-xs transition-colors cursor-pointer disabled:opacity-50"
                    >
                      Connect
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Tab 2: Minecraft IGN Content */}
            {loginTab === "minecraft" && (
              <form onSubmit={handleMinecraftLogin} className="flex flex-col gap-4">
                <div className="flex items-center gap-3 p-3 rounded-xl bg-black/40 border border-[#27272a]">
                  <img
                    src={`https://mc-heads.net/avatar/${mcUsername || "Steve"}/64`}
                    alt="Player Head"
                    className="w-12 h-12 rounded-lg border border-white/10 shadow bg-black/50"
                  />
                  <div className="flex-1">
                    <label className="text-[11px] text-[#a1a1aa] block font-medium">
                      Enter Minecraft In-Game Name
                    </label>
                    <input
                      type="text"
                      value={mcUsername}
                      onChange={(e) => {
                        setMcUsername(e.target.value);
                        setTempMinecraftIgn(e.target.value);
                      }}
                      placeholder="e.g. Steve, Alex, YaHabivo"
                      required
                      className="w-full bg-transparent border-b border-[#3f3f46] focus:border-[#ff7300] py-1 text-sm text-white font-bold outline-none transition-colors"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 px-4 rounded-xl bg-[#ff7300] hover:bg-[#ff851a] active:scale-[0.99] text-white font-black text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#ff7300]/25 cursor-pointer"
                >
                  <span>Continue to Store</span>
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          PRODUCT DETAILS MODAL
      ═══════════════════════════════════════════════════════════════════ */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
          <div className="bg-[#18181b] border border-[#27272a] rounded-2xl max-w-lg w-full p-4 sm:p-6 shadow-2xl relative animate-slideUp text-left max-h-[92vh] overflow-y-auto">
            <button
              onClick={() => setSelectedProduct(null)}
              className="absolute top-4 right-4 text-[#71717a] hover:text-white transition-colors p-1"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            <div className="flex items-center gap-4 mb-4">
              <img
                src={selectedProduct.thumbnail || "/img/categories/1.png"}
                alt={selectedProduct.name}
                className="w-16 h-16 rounded-xl object-cover bg-black/40 border border-[#27272a]"
              />
              <div>
                <h2 className="text-lg font-black text-white">{selectedProduct.name}</h2>
                <div className="text-base font-bold text-[#ff7300] mt-0.5">
                  {sym}{convertPrice(selectedProduct.price)}
                </div>
              </div>
            </div>

            <p className="text-xs text-[#a1a1aa] leading-relaxed mb-5">
              {selectedProduct.description}
            </p>

            <button
              onClick={() => {
                addToCart(selectedProduct as Product);
                setSelectedProduct(null);
              }}
              className="w-full py-2.5 rounded-xl bg-[#ff7300] hover:bg-[#ff851a] text-white font-extrabold text-sm transition-all shadow-lg shadow-[#ff7300]/25 cursor-pointer"
            >
              Add to Cart
            </button>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          CSS ANIMATIONS
      ═══════════════════════════════════════════════════════════════════ */}
      <style jsx>{`
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-slideUp {
          animation: slideUp 0.3s ease-out;
        }

        /* 3D Floating Server Logo with dynamic glow */
        @keyframes logoFloat {
          0%, 100% {
            transform: translateY(0px) scale(1);
            filter: drop-shadow(0 16px 28px rgba(0, 0, 0, 0.85)) drop-shadow(0 0 25px rgba(255, 115, 0, 0.35));
          }
          50% {
            transform: translateY(-12px) scale(1.02);
            filter: drop-shadow(0 26px 42px rgba(0, 0, 0, 0.9)) drop-shadow(0 0 45px rgba(255, 115, 0, 0.55));
          }
        }
        .logo-animated {
          animation: logoFloat 4.2s ease-in-out infinite;
        }

        /* Ember Particles Rising & Swaying */
        @keyframes emberRise {
          0% {
            transform: translateY(20px) translateX(0) scale(0.6);
            opacity: 0;
          }
          25% {
            opacity: 0.9;
          }
          75% {
            opacity: 0.7;
          }
          100% {
            transform: translateY(-90px) translateX(16px) scale(1.2);
            opacity: 0;
          }
        }
        .ember-particle {
          animation: emberRise ease-in-out infinite;
        }

        /* Progress Bar Light Shimmer */
        @keyframes shimmer {
          0% {
            transform: translateX(-100%);
          }
          100% {
            transform: translateX(250%);
          }
        }
        .progress-shimmer {
          animation: shimmer 2.2s infinite ease-in-out;
        }

        /* Minecraft Character Idle Sway */
        @keyframes playerSway {
          0%, 100% {
            transform: translateY(0) rotate(0deg);
          }
          50% {
            transform: translateY(-6px) rotate(1deg);
          }
        }
        .player-animated {
          animation: playerSway 3.6s ease-in-out infinite;
        }

        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .border-l-3 {
          border-left-width: 3px;
        }
        .border-3 {
          border-width: 3px;
        }
      `}</style>
    </div>
  );
}

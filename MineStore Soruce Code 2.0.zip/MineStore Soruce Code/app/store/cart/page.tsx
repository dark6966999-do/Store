"use client";

import React, { useState, useEffect, useMemo, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { getMainSiteUrl } from "@/lib/urls";

interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  color: string;
  order: number;
}

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  subCategory?: string;
  perks?: string[];
  purchases?: number;
  categoryId: string;
  thumbnail: string;
  featured: boolean;
  active: boolean;
  createdAt?: string;
  category?: Category;
}

interface CartItem {
  product: Product;
  quantity: number;
}

interface DiscordUser {
  id: string;
  username: string;
  globalName?: string;
  avatarUrl: string;
  email?: string;
}

type Currency = "BDT" | "EUR" | "USD" | "GBP";

const CURRENCY_SYMBOLS: Record<Currency, string> = {
  BDT: "৳",
  EUR: "€",
  USD: "$",
  GBP: "£",
};

const CURRENCY_RATES: Record<Currency, number> = {
  BDT: 130.0,
  EUR: 1.0,
  USD: 1.08,
  GBP: 0.85,
};

export default function MinecraftCartPage() {
  const [cart, setCart] = useState<CartItem[]>(() => {
    if (typeof window !== "undefined") {
      try {
        const saved = localStorage.getItem("minestore_cart");
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) return parsed;
        }
      } catch {}
    }
    return [];
  });
  const cartLoadedRef = useRef<boolean>(false);
  const [currency, setCurrency] = useState<Currency>("BDT");
  const [currencyOpen, setCurrencyOpen] = useState<boolean>(false);
  const [discordUser, setDiscordUser] = useState<DiscordUser | null>(null);
  const [minecraftUsername, setMinecraftUsername] = useState<string>("dwwd");
  const [couponCode, setCouponCode] = useState<string>("");
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [couponApplied, setCouponApplied] = useState<boolean>(false);
  const [couponError, setCouponError] = useState<string | null>(null);
  const [checkingOut, setCheckingOut] = useState<boolean>(false);
  const [orderSuccess, setOrderSuccess] = useState<any | null>(null);
  const [discordModalOpen, setDiscordModalOpen] = useState<boolean>(false);
  const [discordConnecting, setDiscordConnecting] = useState<boolean>(false);
  const [discordIsConfigured, setDiscordIsConfigured] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [language, setLanguage] = useState<string>("US English");
  const [languageOpen, setLanguageOpen] = useState<boolean>(false);
  const [themeLight, setThemeLight] = useState<boolean>(false);
  const [discordMenuOpen, setDiscordMenuOpen] = useState<boolean>(false);
  const [storeHome, setStoreHome] = useState<string>("/store");

  // Secure Checkout Modal States
  const [secureCheckoutModalOpen, setSecureCheckoutModalOpen] = useState<boolean>(false);
  const [checkoutEmail, setCheckoutEmail] = useState<string>("");
  const [checkoutDiscord, setCheckoutDiscord] = useState<string>("");
  const [checkoutPhone, setCheckoutPhone] = useState<string>("");
  const [checkoutCountry, setCheckoutCountry] = useState<string>("");
  const [agreeTerms, setAgreeTerms] = useState<boolean>(false);
  const [agreeAge, setAgreeAge] = useState<boolean>(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [copiedInvoice, setCopiedInvoice] = useState<boolean>(false);

  useEffect(() => {
    if (typeof window !== "undefined" && window.location.hostname.startsWith("store.")) {
      setStoreHome("/");
    }
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((cur) => (cur === msg ? null : cur));
    }, 3000);
  };

  // Load state from localStorage on mount safely
  useEffect(() => {
    try {
      const saved = localStorage.getItem("minestore_cart");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          setCart(parsed);
        }
      }
    } catch {}
    cartLoadedRef.current = true;

    try {
      const savedCurrency = localStorage.getItem("minestore_currency");
      if (savedCurrency && (savedCurrency in CURRENCY_SYMBOLS)) {
        setCurrency(savedCurrency as Currency);
      }
    } catch {}

    try {
      const savedUser = localStorage.getItem("minestore_discord_user");
      if (savedUser) setDiscordUser(JSON.parse(savedUser));
    } catch {}

    try {
      const savedIgn = localStorage.getItem("minestore_mc_username");
      if (savedIgn) setMinecraftUsername(savedIgn);
    } catch {}

    // Check for Tebex payment return parameters
    if (typeof window !== "undefined") {
      const urlParams = new URLSearchParams(window.location.search);
      const isSuccess = urlParams.get("payment") === "success" || urlParams.get("tebex_success") === "true";
      const invoiceId = urlParams.get("invoiceId");
      const usernameParam = urlParams.get("username");

      if (isSuccess && invoiceId) {
        setOrderSuccess({
          invoiceId,
          username: usernameParam || "Player",
          total: 0,
        });
        setCart([]);
        try {
          localStorage.setItem("minestore_cart", "[]");
        } catch {}
        window.history.replaceState({}, document.title, window.location.pathname);
      }
    }
  }, []);

  // Listen for storage events (e.g. if item added from store page or another tab)
  useEffect(() => {
    const handleStorage = () => {
      try {
        const saved = localStorage.getItem("minestore_cart");
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            setCart(parsed);
          }
        }
      } catch {}
    };
    window.addEventListener("storage", handleStorage);
    return () => window.removeEventListener("storage", handleStorage);
  }, []);

  // Sync cart changes back to localStorage ONLY after initial mount load completes
  useEffect(() => {
    if (!cartLoadedRef.current) return;
    try {
      localStorage.setItem("minestore_cart", JSON.stringify(cart));
    } catch {}
  }, [cart]);

  // Sync Minecraft username back to localStorage
  useEffect(() => {
    try {
      localStorage.setItem("minestore_mc_username", minecraftUsername);
    } catch {}
  }, [minecraftUsername]);

  // Sync currency changes
  useEffect(() => {
    try {
      localStorage.setItem("minestore_currency", currency);
    } catch {}
  }, [currency]);

  // Check Discord session
  useEffect(() => {
    fetch("/api/auth/discord/me")
      .then((r) => r.json())
      .then((data) => {
        if (data.user) {
          setDiscordUser(data.user);
          try {
            localStorage.setItem("minestore_discord_user", JSON.stringify(data.user));
          } catch {}
        }
        setDiscordIsConfigured(Boolean(data.isConfigured));
      })
      .catch(() => {});
  }, []);

  const formatPrice = (eurAmount: number) => {
    const converted = eurAmount * CURRENCY_RATES[currency];
    const symbol = CURRENCY_SYMBOLS[currency];
    if (currency === "BDT") {
      return `${converted.toFixed(2)}৳`;
    }
    return `${symbol}${converted.toFixed(2)}`;
  };

  const updateCartQty = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const cartCount = useMemo(() => {
    return cart.reduce((acc, item) => acc + item.quantity, 0);
  }, [cart]);

  const rawSubtotal = useMemo(() => {
    return cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  }, [cart]);

  const discountAmount = useMemo(() => {
    return (rawSubtotal * discountPercent) / 100;
  }, [rawSubtotal, discountPercent]);

  const finalTotal = useMemo(() => {
    return Math.max(0, rawSubtotal - discountAmount);
  }, [rawSubtotal, discountAmount]);

  const applyCoupon = () => {
    setCouponError(null);
    const code = couponCode.trim().toUpperCase();
    if (!code) return;
    if (code === "AUTUMN20" || code === "PIKA20" || code === "PIKA") {
      setDiscountPercent(20);
      setCouponApplied(true);
      showToast("Coupon applied! 20% discount added.");
    } else if (code === "SURVIVAL10" || code === "PIKA10") {
      setDiscountPercent(10);
      setCouponApplied(true);
      showToast("Coupon applied! 10% discount added.");
    } else {
      setCouponError("Invalid or expired coupon code");
    }
  };

  const handleContinueWithDiscord = async () => {
    setDiscordConnecting(true);

    if (discordIsConfigured) {
      window.location.href = `/api/auth/discord?returnUrl=${encodeURIComponent(window.location.href)}`;
      return;
    }

    try {
      const res = await fetch("/api/auth/discord/dev-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: "DiscordUser",
          id: `${Math.floor(Date.now() * 1000 + Math.random() * 999)}`,
          globalName: "Discord User",
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed to connect Discord");
        setDiscordConnecting(false);
        return;
      }

      setDiscordUser(data.user);
      try {
        localStorage.setItem("minestore_discord_user", JSON.stringify(data.user));
      } catch {}
      setDiscordModalOpen(false);
      showToast("Signed in with Discord!");
    } catch {
      showToast("Discord login failed");
    }
    setDiscordConnecting(false);
  };

  const handleOpenCheckout = () => {
    if (!minecraftUsername.trim()) {
      showToast("Please enter your Minecraft username first!");
      return;
    }
    if (cart.length === 0) {
      showToast("Your cart is empty!");
      return;
    }
    if (discordUser?.username && !checkoutDiscord) {
      setCheckoutDiscord(discordUser.username);
    }
    setCheckoutError(null);
    setSecureCheckoutModalOpen(true);
  };

  const handlePaySecurely = async () => {
    setCheckoutError(null);

    if (!checkoutEmail.trim() || !checkoutEmail.includes("@")) {
      setCheckoutError("Please enter a valid email address.");
      return;
    }

    if (!checkoutDiscord.trim()) {
      setCheckoutError("Please enter your Discord username.");
      return;
    }

    if (!agreeTerms) {
      setCheckoutError("You must agree to the Terms of Service.");
      return;
    }

    if (!agreeAge) {
      setCheckoutError("You must confirm you are over 16 or have guardian permission.");
      return;
    }

    setCheckingOut(true);
    try {
      const res = await fetch("/api/tebex/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: minecraftUsername.trim(),
          email: checkoutEmail.trim(),
          discordUsername: checkoutDiscord.trim(),
          phone: checkoutPhone.trim() || undefined,
          country: checkoutCountry.trim() || undefined,
          items: cart.map((i) => ({ productId: i.product.id, quantity: i.quantity })),
          currency,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setCheckoutError(data.error || "Checkout failed");
        showToast(data.error || "Checkout failed");
        return;
      }

      // If Tebex returns an external checkout redirect URL (Live Mode)
      if (data.checkoutUrl) {
        setCart([]);
        try {
          localStorage.setItem("minestore_cart", "[]");
        } catch {}
        showToast("Redirecting to Tebex Checkout...");
        window.location.href = data.checkoutUrl;
        return;
      }

      // Sandbox or instant delivery completion
      setOrderSuccess(data.order || {
        invoiceId: data.invoiceId,
        username: minecraftUsername.trim(),
        email: checkoutEmail.trim(),
        total: cartTotal,
      });
      setSecureCheckoutModalOpen(false);
      setCart([]);
      try {
        localStorage.setItem("minestore_cart", "[]");
      } catch {}
      showToast(`Order complete! Invoice #${data.invoiceId || data.order?.invoiceId}`);
    } catch (err: any) {
      console.error("Checkout error:", err);
      setCheckoutError("Checkout failed. Please try again.");
      showToast("Checkout failed. Please try again.");
    } finally {
      setCheckingOut(false);
    }
  };

  // Avatar calculation
  const playerAvatar = useMemo(() => {
    const cleanIgn = minecraftUsername.trim() || "Steve";
    return `https://mc-heads.net/avatar/${encodeURIComponent(cleanIgn)}/48`;
  }, [minecraftUsername]);

  return (
    <div
      className="min-h-screen flex flex-col justify-between text-white selection:bg-[#ff5722] selection:text-white"
      style={{
        backgroundColor: "#090b16",
        backgroundImage: `
          radial-gradient(ellipse at 50% 0%, rgba(255, 87, 34, 0.15) 0%, transparent 60%),
          radial-gradient(circle at 100% 100%, rgba(255, 145, 0, 0.08) 0%, transparent 40%)
        `,
        fontFamily: "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif",
      }}
    >
      {/* Pixel Minecraft Font */}
      {/* eslint-disable-next-line @next/next/no-page-custom-font */}
      <link
        href="https://fonts.googleapis.com/css2?family=Press+Start+2P&family=Plus+Jakarta+Sans:wght@500;600;700;800;900&display=swap"
        rel="stylesheet"
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div
          className="fixed bottom-10 right-6 z-[9999] bg-[#14172f] border-2 border-[#ff5722] rounded-xl px-5 py-3 shadow-[0_8px_24px_rgba(255,87,34,0.4)] text-xs font-bold flex items-center gap-2 animate-bounce text-white"
          style={{ fontFamily: "'Press Start 2P', monospace", fontSize: "10px" }}
        >
          <span className="text-[#ff9100]">⚡</span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Clean Pika Network Top Navigation Bar */}
      <header className="w-full bg-[#35160e] border-b border-[#220d07] relative z-40 shadow-md">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 h-14 sm:h-16 flex items-center justify-between">
          
          {/* Left: Hanging Logo & Nav Links */}
          <div className="flex items-center gap-4 sm:gap-6 md:gap-8">
            <Link
              href="/"
              className="relative z-30 flex-shrink-0 -mb-5 sm:-mb-6 group"
              title="Pika Network"
            >
              <div className="relative w-14 h-14 sm:w-16 sm:h-16 md:w-[72px] md:h-[72px] transition-transform duration-200 group-hover:scale-105 filter drop-shadow-[0_4px_10px_rgba(0,0,0,0.6)]">
                <Image
                  src="/logo.png"
                  alt="Pika Network"
                  fill
                  className="object-contain"
                  sizes="80px"
                  priority
                />
              </div>
            </Link>

            {/* Nav links right beside logo */}
            <nav className="flex items-center gap-4 sm:gap-6 text-xs sm:text-sm font-bold text-white/95">
              <Link
                href={getMainSiteUrl("/")}
                className="flex items-center gap-1.5 hover:text-[#ff9100] transition-colors py-1 group"
              >
                <svg className="w-4 h-4 fill-current transition-transform group-hover:-translate-x-0.5" viewBox="0 0 24 24">
                  <path d="M10 9V5l-7 7 7 7v-4.1c5 0 8.5 1.6 11 5.1-1-5-4-10-11-11z" />
                </svg>
                <span>Home</span>
              </Link>

              <a
                href={getMainSiteUrl("/staff")}
                className="flex items-center gap-1.5 hover:text-[#ff9100] transition-colors py-1 group"
              >
                <svg className="w-4 h-4 stroke-current fill-none stroke-[2.2] transition-transform group-hover:scale-110" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
                <span className="hidden xs:inline">Help & Support</span>
                <span className="xs:hidden">Support</span>
              </a>

              <a
                href="https://discord.gg/pikanetwork"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 hover:text-[#ff9100] transition-colors py-1 group"
              >
                <svg className="w-4 h-4 fill-current transition-transform group-hover:scale-110" viewBox="0 0 127.14 96.36">
                  <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z" />
                </svg>
                <span>Discord</span>
              </a>
            </nav>
          </div>

          {/* Right: Language Selector, Theme Toggle, Store Link, Login Button */}
          <div className="flex items-center gap-3 sm:gap-4">
            
            {/* Language Dropdown */}
            <div className="relative">
              <button
                onClick={() => setLanguageOpen(!languageOpen)}
                className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-white/80 hover:text-white transition-colors cursor-pointer py-1"
                aria-label="Select Language"
              >
                <svg className="w-4 h-4 opacity-75" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418" />
                </svg>
                <span className="hidden sm:inline">{language}</span>
                <span className="sm:hidden">EN</span>
                <svg className="w-3 h-3 opacity-60" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {languageOpen && (
                <div className="absolute right-0 mt-2 w-48 rounded-xl bg-[#271009] border border-white/10 shadow-2xl py-1.5 z-50 animate-fadeIn">
                  <div className="px-3 py-1 text-[10px] font-bold text-white/40 uppercase tracking-wider">
                    Language & Region
                  </div>
                  {[
                    { label: "US English", code: "US English" },
                    { label: "UK English", code: "UK English" },
                    { label: "Español", code: "Español" },
                    { label: "Deutsch", code: "Deutsch" },
                    { label: "Français", code: "Français" },
                    { label: "বাংলা (Bengali)", code: "বাংলা" },
                  ].map((l) => (
                    <button
                      key={l.code}
                      onClick={() => {
                        setLanguage(l.code);
                        setLanguageOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-1.5 text-xs font-medium flex items-center justify-between hover:bg-white/10 transition-colors ${
                        language === l.code ? "text-[#ff9100] font-bold" : "text-white/80"
                      }`}
                    >
                      <span>{l.label}</span>
                      {language === l.code && <span>✓</span>}
                    </button>
                  ))}

                  <div className="border-t border-white/10 my-1 pt-1">
                    <div className="px-3 py-1 text-[10px] font-bold text-white/40 uppercase tracking-wider">
                      Currency
                    </div>
                    {(["EUR", "USD", "GBP", "BDT"] as Currency[]).map((c) => (
                      <button
                        key={c}
                        onClick={() => {
                          setCurrency(c);
                          setLanguageOpen(false);
                        }}
                        className={`w-full text-left px-3.5 py-1.5 text-xs font-medium flex items-center justify-between hover:bg-white/10 transition-colors ${
                          currency === c ? "text-[#ff9100] font-bold" : "text-white/80"
                        }`}
                      >
                        <span>{c} ({CURRENCY_SYMBOLS[c]})</span>
                        {currency === c && <span>✓</span>}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Sun / Theme Icon */}
            <button
              onClick={() => {
                setThemeLight(!themeLight);
                showToast(themeLight ? "Switched to Dark mode" : "Switched to Light mode");
              }}
              className="text-white/80 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
              aria-label="Toggle Theme"
              title="Toggle Theme"
            >
              <svg className="w-4 h-4 fill-none stroke-current stroke-2" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="5" />
                <path strokeLinecap="round" d="M12 1v2m0 18v2M4.22 4.22l1.42 1.42m12.72 12.72l1.42 1.42M1 12h2m18 0h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" />
              </svg>
            </button>

            {/* Link back to Store */}
            <Link
              href={storeHome}
              className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-white/80 hover:text-white transition-colors py-1"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
              <span>Store</span>
            </Link>

            {/* Login Button */}
            {!discordUser ? (
              <button
                onClick={() => setDiscordModalOpen(true)}
                className="flex items-center gap-1.5 sm:gap-2 px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-lg bg-[#e65100] hover:bg-[#f4511e] active:scale-95 text-white text-xs sm:text-sm font-bold shadow-[0_2px_10px_rgba(230,81,0,0.35)] transition-all cursor-pointer"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.4" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l3 3m0 0l-3 3m3-3H3" />
                </svg>
                <span>Login</span>
              </button>
            ) : (
              <div className="relative">
                <button
                  onClick={() => setDiscordMenuOpen(!discordMenuOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-black/30 hover:bg-black/40 border border-white/10 text-xs sm:text-sm font-bold text-white transition-all cursor-pointer"
                >
                  <img
                    src={discordUser.avatarUrl}
                    alt={discordUser.username}
                    className="w-5 h-5 rounded-full object-cover border border-[#e65100]"
                  />
                  <span className="max-w-[90px] truncate">{discordUser.username}</span>
                  <svg className="w-3 h-3 opacity-60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>

                {discordMenuOpen && (
                  <div className="absolute right-0 mt-2 w-60 rounded-xl bg-[#271009] border border-white/15 shadow-2xl p-3 z-50 animate-fadeIn space-y-2.5">
                    <div className="flex items-center gap-3 pb-2.5 border-b border-white/10">
                      <img src={discordUser.avatarUrl} alt="" className="w-9 h-9 rounded-full border border-[#e65100]" />
                      <div className="overflow-hidden">
                        <p className="text-xs font-bold text-white truncate">@{discordUser.username}</p>
                        <p className="text-[10px] text-white/50 font-mono truncate">ID: {discordUser.id}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        setDiscordUser(null);
                        try {
                          localStorage.removeItem("minestore_discord_user");
                        } catch {}
                        setDiscordMenuOpen(false);
                        showToast("Disconnected Discord");
                      }}
                      className="w-full py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 font-bold text-xs transition-colors text-center"
                    >
                      Disconnect
                    </button>
                  </div>
                )}
              </div>
            )}

          </div>

        </div>
      </header>

        {/* MAIN BODY CONTENT */}
        <main className="max-w-6xl mx-auto px-4 sm:px-8 pt-8 pb-16">
          {/* Cart Title Section with Pika Orange Cart Icon */}
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 bg-gradient-to-br from-[#ff5722] to-[#ff9100] border-2 border-black rounded-2xl flex items-center justify-center shadow-[4px_4px_0px_#000] flex-shrink-0">
              <svg className="w-7 h-7 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z" />
              </svg>
            </div>
            <div>
              <h1
                className="text-2xl sm:text-3xl font-bold text-white tracking-tight"
                style={{ fontFamily: "'Press Start 2P', monospace", fontSize: "20px" }}
              >
                Cart
              </h1>
              <p
                className="text-xs text-[#ff9100] mt-1 font-bold"
                style={{ fontFamily: "'Press Start 2P', monospace", fontSize: "10px" }}
              >
                {cartCount} {cartCount === 1 ? "item" : "items"}
              </p>
            </div>
          </div>

          {/* Minecraft Username and Discord Status Bar (Pika Theme) */}
          <div className="bg-[#14172f] border-2 border-black border-[#ff5722]/30 rounded-2xl p-4 sm:p-5 mb-8 shadow-[4px_4px_0px_#000] flex flex-wrap items-center justify-between gap-4">
            {/* Minecraft Username Input with live face preview */}
            <div className="flex items-center gap-3.5 flex-1 min-w-[280px]">
              <div className="w-11 h-11 rounded-xl border-2 border-black overflow-hidden bg-[#1f244a] flex-shrink-0">
                <img
                  src={playerAvatar}
                  alt="Player Skin"
                  className="w-full h-full object-cover"
                  style={{ imageRendering: "pixelated" }}
                />
              </div>
              <div className="flex-1">
                <label
                  className="block text-[8px] font-bold text-[#ff9100] uppercase mb-1"
                  style={{ fontFamily: "'Press Start 2P', monospace" }}
                >
                  Minecraft Username (IGN) *
                </label>
                <input
                  type="text"
                  placeholder="Enter exact Minecraft username..."
                  value={minecraftUsername}
                  onChange={(e) => setMinecraftUsername(e.target.value)}
                  className="w-full bg-[#0d0f1d] border-2 border-black rounded-xl px-3.5 py-2 text-xs font-bold text-white outline-none focus:border-[#ff5722] transition-colors"
                  style={{ fontFamily: "'Press Start 2P', monospace", fontSize: "10px" }}
                />
              </div>
            </div>

            {/* Discord Connection Status */}
            <div className="flex items-center gap-2.5">
              {!discordUser ? (
                <button
                  onClick={() => setDiscordModalOpen(true)}
                  className="px-4 py-2.5 bg-[#5865F2] hover:bg-[#4752c4] text-white rounded-xl border-2 border-black font-bold text-[9px] shadow-[2px_2px_0px_#000] active:translate-y-[1px] flex items-center gap-2 cursor-pointer transition-all"
                  style={{ fontFamily: "'Press Start 2P', monospace" }}
                >
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 127.14 96.36">
                    <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z" />
                  </svg>
                  <span>Connect Discord</span>
                </button>
              ) : (
                <div
                  className="px-3.5 py-2 bg-[#0d0f1d] border-2 border-black rounded-xl flex items-center gap-2.5 text-[9px] font-bold shadow-[2px_2px_0px_#000]"
                  style={{ fontFamily: "'Press Start 2P', monospace" }}
                >
                  <img
                    src={discordUser.avatarUrl}
                    alt=""
                    className="w-5 h-5 rounded-full border border-[#5865F2]"
                  />
                  <span className="text-[#5865F2]">@{discordUser.username}</span>
                  <span className="text-emerald-400">✓ Linked</span>
                </div>
              )}
            </div>
          </div>

          {/* Grid Layout: Cart Items (left) + Summary (right) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left 7-8 cols: Cart Items */}
            <div className="lg:col-span-8 space-y-4">
              {cart.length === 0 ? (
                <div className="bg-[#14172f] border-2 border-black rounded-2xl p-12 text-center shadow-[4px_4px_0px_#000] border-[#ff5722]/30">
                  <div className="text-4xl mb-4">🛒</div>
                  <h3
                    className="text-sm font-bold text-white mb-3"
                    style={{ fontFamily: "'Press Start 2P', monospace" }}
                  >
                    Your cart is empty!
                  </h3>
                  <p className="text-xs text-gray-400 mb-6">
                    Add ranks, packages, or bundles from the store to proceed to checkout.
                  </p>
                  <Link
                    href={storeHome}
                    className="inline-block px-6 py-3 bg-[#ff5722] hover:bg-[#ff7043] text-white font-bold text-xs rounded-xl border-2 border-black shadow-[3px_3px_0px_#000] active:translate-y-[1px] transition-all"
                    style={{ fontFamily: "'Press Start 2P', monospace" }}
                  >
                    Browse Store
                  </Link>
                </div>
              ) : (
                cart.map((item) => (
                  <div
                    key={item.product.id}
                    className="bg-[#14172f] border-2 border-black rounded-2xl p-4 shadow-[4px_4px_0px_#000] flex flex-wrap sm:flex-nowrap items-center justify-between gap-4 border-[#ff5722]/30 transition-transform hover:translate-x-0.5"
                  >
                    {/* Thumbnail & Title */}
                    <div className="flex items-center gap-3.5 flex-1 min-w-[200px]">
                      <div className="w-14 h-14 bg-[#0d0f1d] border-2 border-black rounded-xl flex items-center justify-center p-2 flex-shrink-0 overflow-hidden">
                        {item.product.thumbnail ? (
                          <img
                            src={item.product.thumbnail}
                            alt={item.product.name}
                            className="max-w-full max-h-full object-contain"
                            style={{ imageRendering: "pixelated" }}
                          />
                        ) : (
                          <span className="text-2xl">🔥</span>
                        )}
                      </div>
                      <div className="overflow-hidden">
                        <h4
                          className="text-xs sm:text-sm font-bold text-white truncate leading-tight"
                          style={{ fontFamily: "'Press Start 2P', monospace" }}
                        >
                          {item.product.name}
                        </h4>
                        <p
                          className="text-[9px] text-[#ff9100] font-bold mt-1"
                          style={{ fontFamily: "'Press Start 2P', monospace" }}
                        >
                          {item.product.subCategory || "One Time Package"}
                        </p>
                      </div>
                    </div>

                    {/* Quantity controls + Price + Delete button */}
                    <div className="flex items-center gap-3 sm:gap-4 flex-shrink-0">
                      {/* Quantity [-] [count] [+] */}
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => updateCartQty(item.product.id, -1)}
                          className="w-8 h-8 bg-[#0d0f1d] hover:bg-[#ff5722] hover:text-white border-2 border-black rounded-lg flex items-center justify-center font-bold text-sm shadow-[1px_1px_0px_#000] active:scale-95 cursor-pointer text-white transition-colors"
                          aria-label="Decrease quantity"
                        >
                          -
                        </button>
                        <span
                          className="w-7 text-center font-bold text-xs text-white"
                          style={{ fontFamily: "'Press Start 2P', monospace" }}
                        >
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateCartQty(item.product.id, 1)}
                          className="w-8 h-8 bg-[#0d0f1d] hover:bg-[#ff5722] hover:text-white border-2 border-black rounded-lg flex items-center justify-center font-bold text-sm shadow-[1px_1px_0px_#000] active:scale-95 cursor-pointer text-white transition-colors"
                          aria-label="Increase quantity"
                        >
                          +
                        </button>
                      </div>

                      {/* Price */}
                      <div
                        className="font-bold text-xs sm:text-sm text-[#ff9100] min-w-[75px] text-right"
                        style={{ fontFamily: "'Press Start 2P', monospace" }}
                      >
                        {formatPrice(item.product.price * item.quantity)}
                      </div>

                      {/* Red Trash Delete Button matching screenshot */}
                      <button
                        onClick={() => removeFromCart(item.product.id)}
                        className="w-8 h-8 rounded-lg bg-[#E5484D] hover:bg-[#d4373c] border-2 border-black flex items-center justify-center text-white shadow-[1px_1px_0px_#000] active:scale-95 flex-shrink-0 cursor-pointer transition-colors"
                        title="Remove from cart"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Right 4 cols: Summary Box (Pika Theme) */}
            <div className="lg:col-span-4">
              <div className="bg-[#14172f] border-2 border-black border-[#ff5722]/30 rounded-2xl p-5 sm:p-6 shadow-[4px_4px_0px_#000] space-y-4 sticky top-24">
                <h3
                  className="text-sm sm:text-base font-bold text-white flex items-center justify-between pb-3 border-b border-white/10"
                  style={{ fontFamily: "'Press Start 2P', monospace" }}
                >
                  <span>Summary</span>
                  <span className="text-[#ff9100] text-xs">PIKA</span>
                </h3>

                {/* Subtotal */}
                <div className="flex items-center justify-between text-xs pt-1">
                  <span className="font-bold text-gray-400">Subtotal</span>
                  <span
                    className="font-bold text-white"
                    style={{ fontFamily: "'Press Start 2P', monospace", fontSize: "10px" }}
                  >
                    {formatPrice(rawSubtotal)}
                  </span>
                </div>

                {/* Discount (if applicable) */}
                {discountAmount > 0 && (
                  <div className="flex items-center justify-between text-xs text-emerald-400">
                    <span className="font-bold">Discount ({discountPercent}%)</span>
                    <span
                      className="font-bold"
                      style={{ fontFamily: "'Press Start 2P', monospace", fontSize: "10px" }}
                    >
                      -{formatPrice(discountAmount)}
                    </span>
                  </div>
                )}

                {/* Total */}
                <div className="flex items-center justify-between text-xs pt-2 pb-2 border-t border-white/10">
                  <span className="font-bold text-white">Total</span>
                  <span
                    className="font-bold text-[#ff9100]"
                    style={{ fontFamily: "'Press Start 2P', monospace", fontSize: "12px" }}
                  >
                    {formatPrice(finalTotal)}
                  </span>
                </div>

                {/* Coupon Code Input & Apply Button matching screenshot */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-[#0d0f1d] border-2 border-black rounded-xl px-3 py-2 flex items-center gap-2">
                      <svg className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                      </svg>
                      <input
                        type="text"
                        placeholder="COUPON CODE"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                        className="w-full bg-transparent text-[9px] font-bold text-white placeholder-gray-500 outline-none uppercase"
                        style={{ fontFamily: "'Press Start 2P', monospace" }}
                      />
                    </div>
                    <button
                      onClick={applyCoupon}
                      className="px-4 py-2.5 bg-[#0d0f1d] hover:bg-[#ff5722] hover:text-white border-2 border-black rounded-xl text-[#ff9100] font-bold text-[9px] uppercase shadow-[2px_2px_0px_#000] active:translate-y-[1px] cursor-pointer transition-colors"
                      style={{ fontFamily: "'Press Start 2P', monospace" }}
                    >
                      Apply
                    </button>
                  </div>
                  {couponApplied && (
                    <p className="text-[9px] text-emerald-400 font-bold" style={{ fontFamily: "'Press Start 2P', monospace" }}>
                      ✓ {discountPercent}% discount applied!
                    </p>
                  )}
                  {couponError && (
                    <p className="text-[9px] text-red-400 font-bold" style={{ fontFamily: "'Press Start 2P', monospace" }}>
                      ✕ {couponError}
                    </p>
                  )}
                </div>

                {/* Checkout Button */}
                <button
                  disabled={cart.length === 0 || checkingOut || !minecraftUsername.trim()}
                  onClick={handleOpenCheckout}
                  className="w-full py-4 bg-gradient-to-r from-[#00dfc4] via-[#00c5ad] to-[#00bda6] hover:from-[#00ecd0] hover:to-[#00d0b7] active:translate-y-[2px] border-2 border-black rounded-xl text-black font-black text-xs tracking-wider shadow-[4px_4px_0px_#000] active:shadow-[1px_1px_0px_#000] transition-all flex items-center justify-center gap-2.5 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                  style={{ fontFamily: "'Press Start 2P', monospace", fontSize: "11px" }}
                >
                  <svg className="w-4 h-4 text-black" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z" />
                  </svg>
                  <span>Checkout Now</span>
                </button>
              </div>
            </div>
          </div>
        </main>

      {/* OFFICIAL PIKANETWORK MAIN SITE FOOTER */}
      <footer className="w-full bg-[#0a0503] mt-20 pt-10 pb-12 border-t border-[#ff6a00]/20 relative z-20">
        <div className="max-w-[1320px] mx-auto px-4 sm:px-6 flex flex-col gap-10">
          
          {/* Top Banner Strip in Orange Theme */}
          <div className="w-full rounded-2xl bg-gradient-to-r from-[#d84315] via-[#ff6a00] to-[#e65100] px-5 sm:px-8 py-3.5 sm:py-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-[0_8px_32px_rgba(255,106,0,0.45)] border border-[#ffa04d]/40 relative">
            
            {/* Left: Mascot Floating Logo + Server IP Text */}
            <div
              onClick={() => {
                navigator.clipboard.writeText("play.pika-network.net");
                showToast("Server IP copied to clipboard! (play.pika-network.net)");
              }}
              className="flex items-center gap-3.5 cursor-pointer group"
              title="Click to copy server IP"
            >
              <img
                alt="PikaNetwork"
                className="w-14 sm:w-16 md:w-20 h-auto object-contain -mt-6 sm:-mt-8 -mb-2 drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)] group-hover:scale-105 transition-transform"
                src="/logo.png"
              />
              
              <div className="flex flex-col">
                <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base sm:text-lg md:text-xl tracking-wider leading-tight group-hover:text-[#ffe4a0] transition-colors drop-shadow-sm">
                  PLAY.PIKA-NETWORK.NET
                </span>
                <span className="flex items-center gap-1.5 text-[11px] font-black text-[#ffe4a0] tracking-wider uppercase drop-shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse"></span>
                  ONLINE - CLICK TO COPY
                </span>
              </div>
            </div>

            {/* Right: Social Media Icons */}
            <div className="flex items-center gap-4 text-white">
              {/* Discord */}
              <a
                href="https://pika-network.net/discord"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#ffea00] hover:scale-110 transition-all"
                aria-label="Discord"
              >
                <svg className="w-6 h-6 fill-current" viewBox="0 0 127.14 96.36">
                  <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z"/>
                </svg>
              </a>

              {/* X / Twitter */}
              <a
                href="https://twitter.com/PikaNetworkMC"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#ffea00] hover:scale-110 transition-all"
                aria-label="X (Twitter)"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </a>

              {/* Instagram */}
              <a
                href="https://instagram.com/pikanetworkmc"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#ffea00] hover:scale-110 transition-all"
                aria-label="Instagram"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>
            </div>

          </div>

          {/* Main 3 Columns */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10 pt-4">
            
            {/* Column 1: ABOUT US */}
            <div className="flex flex-col gap-3">
              <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase">
                ABOUT US
              </h3>
              <p className="text-sm text-[#c9a48f] leading-relaxed">
                PikaNetwork is one of the largest Minecraft servers! Since the day PikaNetwork was formed, back in 2014, we have focused on bringing joy to the community. We offer many game modes, these being BedWars, OneBlock, KitPvP, OP Factions, OP Lifesteal, OP Prison, OP SkyBlock, Practice, SkyPvP, Survival and SkyMines!
              </p>
              <div className="text-sm text-white pt-1">
                <span className="text-[#c9a48f]">Come play at: </span>
                <strong
                  className="text-[#ffea00] font-mono cursor-pointer hover:underline"
                  onClick={() => {
                    navigator.clipboard.writeText("play.pika-network.net");
                    showToast("Server IP copied to clipboard!");
                  }}
                >
                  PLAY.PIKA-NETWORK.NET
                </strong>
              </div>
            </div>

            {/* Column 2: LINKS */}
            <div className="flex flex-col gap-3">
              <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase">
                LINKS
              </h3>
              <ul className="flex flex-col gap-2 text-sm text-[#c9a48f]">
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Back to Top</span>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors">
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <Link href={storeHome} className="hover:text-[#ffea00] transition-colors font-medium">
                    Store (store.localhost:3000)
                  </Link>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors">
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <a href={getMainSiteUrl("/")} className="hover:text-[#ffea00] transition-colors font-medium">
                    Home Portal
                  </a>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors">
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <a href={getMainSiteUrl("/staff")} className="hover:text-[#ffea00] transition-colors font-medium">
                    Staff Team
                  </a>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors">
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <a href={getMainSiteUrl("/vote")} className="hover:text-[#ffea00] transition-colors font-medium">
                    Vote for Server
                  </a>
                </li>
              </ul>
            </div>

            {/* Column 3: SUPPORT US */}
            <div className="flex flex-col gap-3">
              <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase">
                SUPPORT US
              </h3>
              <p className="text-sm text-[#c9a48f] leading-relaxed">
                Have you had a fun time here? Support us by purchasing packages such as ranks, commands, crate keys, and more!
              </p>
              <div className="pt-2">
                <Link
                  href={storeHome}
                  className="inline-flex items-center justify-center bg-[#ffea00] hover:bg-[#ffd700] text-[#1c1803] font-['Plus_Jakarta_Sans',sans-serif] font-extrabold text-sm px-7 py-2.5 rounded-xl shadow-[0_4px_16px_rgba(255,234,0,0.35)] hover:scale-105 active:scale-95 transition-all"
                >
                  Visit Store
                </Link>
              </div>
            </div>

          </div>

          {/* Bottom Copyright & Disclaimer Row */}
          <div className="pt-6 border-t border-[#ff6a00]/15 flex items-start gap-3.5 text-xs text-[#8c7262]">
            <div className="w-8 h-8 rounded-lg bg-[#221008] border border-white/10 flex items-center justify-center text-slate-400 font-bold text-base flex-shrink-0 shadow-inner">
              G
            </div>

            <div className="flex flex-col gap-0.5">
              <div className="text-white font-bold">
                Copyright © CraftiGames B.V. 2026
              </div>
              <div className="text-[11px] text-[#8c7262]">
                We are not affiliated with Mojang or Minecraft.
              </div>
              <div className="text-[11px] text-[#8c7262]">
                We are not affiliated with Nintendo Co., Ltd.
              </div>
            </div>
          </div>

        </div>
      </footer>

      {/* DISCORD SIGN IN MODAL matching user image 1 */}
      {discordModalOpen && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-fadeIn"
          onClick={() => setDiscordModalOpen(false)}
        >
          <div
            className="bg-[#111216] border border-white/[0.08] text-white rounded-2xl max-w-[420px] w-full p-6 sm:p-7 shadow-2xl relative"
            style={{ fontFamily: "system-ui, -apple-system, sans-serif" }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              onClick={() => setDiscordModalOpen(false)}
              className="absolute top-5 right-5 text-gray-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-white/5 cursor-pointer"
              aria-label="Close"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            {/* Title & Subtitle */}
            <div className="text-left mb-6 pr-6">
              <h2 className="text-2xl sm:text-[28px] font-bold text-white tracking-tight leading-tight">Sign In</h2>
              <p className="text-sm text-gray-400 mt-1.5 leading-normal">
                Enter your email to continue to your panel.
              </p>
            </div>

            {/* Continue with Discord Button */}
            <button
              onClick={handleContinueWithDiscord}
              disabled={discordConnecting}
              className="w-full py-3 px-4 rounded-xl bg-[#5865F2] hover:bg-[#4752c4] active:scale-[0.99] text-white font-semibold text-sm sm:text-[15px] flex items-center justify-center gap-2.5 transition-all shadow-md shadow-[#5865F2]/20 disabled:opacity-50 cursor-pointer"
            >
              <svg className="w-5 h-5 fill-current" viewBox="0 0 127.14 96.36">
                <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z" />
              </svg>
              <span>{discordConnecting ? "Connecting..." : "Continue with Discord"}</span>
            </button>
          </div>
        </div>
      )}

      {/* SECURE CHECKOUT MODAL MATCHING USER REFERENCE IMAGE */}
      {secureCheckoutModalOpen && (
        <div
          className="fixed inset-0 z-[120] flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-fadeIn overflow-y-auto"
          onClick={() => setSecureCheckoutModalOpen(false)}
        >
          <div
            className="bg-white rounded-3xl p-4 sm:p-7 max-w-[440px] w-full border-2 border-black shadow-[6px_6px_0px_#000] relative text-slate-800 my-4 sm:my-8 animate-scaleUp max-h-[92vh] overflow-y-auto"
            style={{ fontFamily: "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif" }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-5">
              <div className="flex items-center gap-3">
                {/* Cyan Shield Icon */}
                <div className="w-11 h-11 rounded-full bg-[#00dfc4] border-2 border-black flex items-center justify-center flex-shrink-0 shadow-[2px_2px_0px_#000]">
                  <svg className="w-6 h-6 text-black" fill="none" stroke="currentColor" strokeWidth="2.4" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z" />
                  </svg>
                </div>
                <div>
                  <h2
                    className="text-lg sm:text-xl font-black text-black tracking-tight"
                    style={{ fontFamily: "'Press Start 2P', monospace", fontSize: "13px" }}
                  >
                    Secure Checkout
                  </h2>
                  <p className="text-xs text-gray-500 font-medium mt-1">
                    Final step to claim your digital goods.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSecureCheckoutModalOpen(false)}
                className="text-gray-400 hover:text-black transition-colors p-1 rounded-lg cursor-pointer"
                aria-label="Close"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Error Message */}
            {checkoutError && (
              <div className="mb-4 p-3 rounded-xl bg-red-50 border-2 border-red-500 text-red-700 text-xs font-bold flex items-center gap-2">
                <span>⚠️</span>
                <span>{checkoutError}</span>
              </div>
            )}

            {/* Form Fields */}
            <div className="space-y-3.5">
              
              {/* Field 1: Email Address */}
              <div className="border-2 border-black rounded-xl bg-[#fafafa] flex items-center px-3.5 py-3 shadow-[2px_2px_0px_#000] focus-within:bg-white focus-within:border-[#00dfc4] focus-within:shadow-[3px_3px_0px_#00dfc4] transition-all">
                <div className="w-7 flex items-center justify-center text-gray-600 flex-shrink-0">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
                  </svg>
                </div>
                <input
                  type="email"
                  required
                  value={checkoutEmail}
                  onChange={(e) => setCheckoutEmail(e.target.value)}
                  placeholder="Email address *"
                  className="w-full bg-transparent text-sm text-black placeholder-gray-400 font-semibold focus:outline-none pl-2"
                />
              </div>

              {/* Field 2: Discord Username */}
              <div className="border-2 border-black rounded-xl bg-[#fafafa] flex items-center px-3.5 py-3 shadow-[2px_2px_0px_#000] focus-within:bg-white focus-within:border-[#00dfc4] focus-within:shadow-[3px_3px_0px_#00dfc4] transition-all">
                <div className="w-7 flex items-center justify-center text-gray-600 font-black text-sm flex-shrink-0">
                  @
                </div>
                <input
                  type="text"
                  required
                  value={checkoutDiscord}
                  onChange={(e) => setCheckoutDiscord(e.target.value)}
                  placeholder="Discord Username *"
                  className="w-full bg-transparent text-sm text-black placeholder-gray-400 font-semibold focus:outline-none pl-2"
                />
              </div>

              {/* Field 3: Phone (Optional) */}
              <div className="border-2 border-black rounded-xl bg-[#fafafa] flex items-center px-3.5 py-3 shadow-[2px_2px_0px_#000] focus-within:bg-white focus-within:border-[#00dfc4] focus-within:shadow-[3px_3px_0px_#00dfc4] transition-all">
                <div className="w-7 flex items-center justify-center text-gray-600 flex-shrink-0">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
                  </svg>
                </div>
                <input
                  type="tel"
                  value={checkoutPhone}
                  onChange={(e) => setCheckoutPhone(e.target.value)}
                  placeholder="Phone (Optional)"
                  className="w-full bg-transparent text-sm text-black placeholder-gray-400 font-semibold focus:outline-none pl-2"
                />
              </div>

              {/* Field 4: Country (Optional) */}
              <div className="border-2 border-black rounded-xl bg-[#fafafa] flex items-center px-3.5 py-3 shadow-[2px_2px_0px_#000] focus-within:bg-white focus-within:border-[#00dfc4] focus-within:shadow-[3px_3px_0px_#00dfc4] transition-all">
                <div className="w-7 flex items-center justify-center text-gray-600 flex-shrink-0">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418" />
                  </svg>
                </div>
                <input
                  type="text"
                  value={checkoutCountry}
                  onChange={(e) => setCheckoutCountry(e.target.value)}
                  placeholder="Country (Optional)"
                  className="w-full bg-transparent text-sm text-black placeholder-gray-400 font-semibold focus:outline-none pl-2"
                />
              </div>

              {/* Checkbox 1: Terms */}
              <label className="border-2 border-black rounded-xl p-3 bg-white flex items-start gap-3 cursor-pointer shadow-[2px_2px_0px_#000] hover:bg-gray-50 transition-colors">
                <input
                  type="checkbox"
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="w-4 h-4 mt-0.5 accent-[#00dfc4] rounded cursor-pointer flex-shrink-0"
                />
                <span className="text-xs text-gray-700 font-semibold leading-relaxed">
                  I agree to the <span className="text-[#00bda6] hover:underline font-bold">Terms of Service</span>
                </span>
              </label>

              {/* Checkbox 2: Age Consent */}
              <label className="border-2 border-black rounded-xl p-3 bg-white flex items-start gap-3 cursor-pointer shadow-[2px_2px_0px_#000] hover:bg-gray-50 transition-colors">
                <input
                  type="checkbox"
                  checked={agreeAge}
                  onChange={(e) => setAgreeAge(e.target.checked)}
                  className="w-4 h-4 mt-0.5 accent-[#00dfc4] rounded cursor-pointer flex-shrink-0"
                />
                <span className="text-xs text-gray-700 font-semibold leading-relaxed">
                  I confirm that I am either over 16 or have guardian permission, and I consent to the collection and use of my data for this purchase
                </span>
              </label>

              {/* Action Button: Pay via Tebex */}
              <button
                disabled={checkingOut}
                onClick={handlePaySecurely}
                className="w-full py-3.5 bg-gradient-to-r from-[#ff7300] to-[#ff851a] hover:from-[#ff8000] hover:to-[#ff9500] active:scale-[0.99] text-black font-extrabold rounded-xl shadow-[0_4px_18px_rgba(255,115,0,0.35)] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 mt-2 text-sm"
              >
                <svg className="w-4 h-4 text-black" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z" />
                </svg>
                <span>{checkingOut ? "Redirecting..." : "Pay via Tebex Checkout"}</span>
              </button>

              {/* Secure payments via */}
              <div className="text-center pt-2 space-y-2">
                <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider flex items-center justify-center gap-1.5">
                  <span>Powered by</span>
                  <span className="font-extrabold text-[#0f172a] tracking-tight">tebex</span>
                  <span>· 256-Bit SSL</span>
                </p>
                <div className="flex items-center justify-center gap-1.5 flex-wrap">
                  <span className="px-2 py-0.5 bg-white border border-gray-200 rounded text-[10px] font-bold text-gray-800">Cards</span>
                  <span className="px-2 py-0.5 bg-white border border-gray-200 rounded text-[10px] font-bold text-[#003087]">PayPal</span>
                  <span className="px-2 py-0.5 bg-white border border-gray-200 rounded text-[10px] font-bold text-emerald-700">Paysafecard</span>
                  <span className="px-2 py-0.5 bg-white border border-gray-200 rounded text-[10px] font-bold text-gray-700">Apple Pay</span>
                  <span className="px-2 py-0.5 bg-white border border-gray-200 rounded text-[10px] font-bold text-gray-700">Google Pay</span>
                </div>
                <div>
                  <button
                    onClick={() => setSecureCheckoutModalOpen(false)}
                    className="text-xs font-bold text-gray-500 hover:text-black transition-colors pt-1 cursor-pointer"
                  >
                    Go back
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* ORDER SUCCESS & INVOICE MODAL */}
      {orderSuccess && (
        <div
          className="fixed inset-0 z-[130] flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-4 animate-fadeIn overflow-y-auto"
          onClick={() => setOrderSuccess(null)}
        >
          <div
            className="bg-[#141416] border border-white/10 rounded-2xl max-w-md w-full p-6 sm:p-7 text-center shadow-[0_24px_64px_rgba(0,0,0,0.85)] text-white relative my-4 sm:my-8 animate-scaleUp font-['Plus_Jakarta_Sans',sans-serif]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Minimalist Verified Checkmark Badge */}
            <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-emerald-400 mb-3.5 shadow-sm">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.4">
                <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
              </svg>
            </div>

            {/* Title & Description */}
            <div>
              <h3 className="text-xl font-extrabold text-white tracking-tight">
                Payment Complete
              </h3>
              <p className="text-xs text-[#94a3b8] mt-1 leading-relaxed">
                Thank you, <span className="text-white font-bold">{orderSuccess.username}</span>. Your transaction has been verified and items have been credited in-game.
              </p>
            </div>

            {/* Clean Receipt Card */}
            <div className="bg-[#18191d] border border-white/5 rounded-xl p-4 text-left space-y-3 mt-5">
              {/* Invoice Reference Header */}
              <div className="flex items-center justify-between pb-3 border-b border-white/5">
                <div>
                  <span className="text-[10px] font-semibold text-[#71717a] uppercase tracking-wider block">
                    Invoice Reference
                  </span>
                  <span className="text-sm sm:text-base font-mono font-bold text-white tracking-wide">
                    {orderSuccess.invoiceId || orderSuccess.id}
                  </span>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(orderSuccess.invoiceId || orderSuccess.id);
                    setCopiedInvoice(true);
                    showToast("Invoice ID copied to clipboard");
                    setTimeout(() => setCopiedInvoice(false), 2500);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-white/90 hover:text-white transition-all cursor-pointer flex items-center gap-1.5"
                >
                  {copiedInvoice ? (
                    <span className="text-emerald-400 font-bold">Copied! ✓</span>
                  ) : (
                    <>
                      <svg className="w-3.5 h-3.5 text-[#94a3b8]" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.257c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184" />
                      </svg>
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>

              {/* Order Metadata Rows */}
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between text-[#a1a1aa]">
                  <span>Minecraft Account:</span>
                  <span className="font-semibold text-white">{orderSuccess.username}</span>
                </div>

                <div className="flex items-center justify-between text-[#a1a1aa]">
                  <span>Server Destination:</span>
                  <span className="font-mono text-white/90">play.pika-network.net</span>
                </div>

                {orderSuccess.email && (
                  <div className="flex items-center justify-between text-[#a1a1aa]">
                    <span>Email Receipt:</span>
                    <div className="flex items-center gap-1.5 max-w-[200px]">
                      <span className="truncate text-white/90">{orderSuccess.email}</span>
                      <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20 font-semibold flex-shrink-0">
                        Sent
                      </span>
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between text-[#a1a1aa]">
                  <span>Delivery Status:</span>
                  <span className="text-emerald-400 font-semibold flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Delivered in-game</span>
                  </span>
                </div>

                <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                  <span className="text-xs text-[#a1a1aa] font-medium">Grand Total Paid:</span>
                  <span className="text-base font-extrabold text-white">
                    {formatPrice(orderSuccess.total)}
                  </span>
                </div>
              </div>
            </div>

            {/* In-Game Help Note */}
            <div className="p-3 bg-white/[0.02] border border-white/5 rounded-xl text-[11px] text-[#94a3b8] leading-relaxed text-left flex items-start gap-2.5 mt-3.5">
              <svg className="w-4 h-4 text-[#ff7300] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
              </svg>
              <span>
                Your perks activate automatically upon connecting to the server. You can type <code className="text-white font-mono bg-white/5 px-1 py-0.5 rounded">/ranks</code> in-game to verify your rewards.
              </span>
            </div>

            {/* Action Buttons */}
            <div className="pt-4">
              <Link
                href={storeHome}
                onClick={() => setOrderSuccess(null)}
                className="w-full py-3 rounded-xl bg-[#ff7300] hover:bg-[#ff851a] active:scale-95 text-black font-extrabold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 shadow-[0_4px_16px_rgba(255,115,0,0.3)] hover:shadow-[0_6px_20px_rgba(255,115,0,0.45)]"
              >
                <span>Continue Shopping</span>
                <svg className="w-3.5 h-3.5 stroke-current fill-none" viewBox="0 0 24 24" strokeWidth="2.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

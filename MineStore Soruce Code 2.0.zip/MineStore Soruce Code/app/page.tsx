"use client";

import React, { useState, useEffect } from "react";
import { STORE_URL, getStoreUrl } from "@/lib/urls";

// TypeScript Interfaces
interface ResetAnnouncement {
  id: string;
  title: string;
  category: string;
  categoryColor: string;
  date: string;
  dayNumber: string;
  month: string;
  author: string;
  authorInitials: string;
  commentsCount: number;
  featured?: boolean;
  scheduleTimes?: string;
  summary: string;
}

interface StaffMember {
  name: string;
  role: "Sr Mod" | "Trial" | "Admin" | "Developer";
  roleColor: string;
  status: string;
  initials: string;
}

interface ForumThread {
  id: string;
  title: string;
  author: string;
  replies: number;
  tag: string;
  tagColor: string;
}

interface ProfilePost {
  id: string;
  author: string;
  target?: string;
  initials: string;
  timeAgo: string;
  content: string;
  badgeColor: string;
}

const SERVER_IP = "play.pika-network.net";
const LOGO_SRC = "/logo.png";

export default function HomePage() {
  const [copied, setCopied] = useState<boolean>(false);
  const [copyModalOpen, setCopyModalOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [rconPlayerCount, setRconPlayerCount] = useState<number | null>(null);
  const [rconOnline, setRconOnline] = useState<boolean | null>(null);
  const [activeNav, setActiveNav] = useState<string>("home");
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [showAllArticles, setShowAllArticles] = useState<boolean>(false);

  // Live countdown state
  const [countdown, setCountdown] = useState({
    days: "00",
    hours: "00",
    mins: "00",
    secs: "00",
  });

  useEffect(() => {
    let active = true;

    const updatePlayerCount = async () => {
      try {
        const response = await fetch("/api/bridge/heartbeat", { cache: "no-store" });
        const data = await response.json();
        if (!active) return;
        setRconOnline(data.rcon?.online === true);
        setRconPlayerCount(
          data.rcon?.online && typeof data.rcon.onlinePlayers === "number"
            ? data.rcon.onlinePlayers
            : null
        );
      } catch {
        if (active) {
          setRconOnline(false);
          setRconPlayerCount(null);
        }
      }
    };

    void updatePlayerCount();
    const interval = setInterval(updatePlayerCount, 15000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, []);

  // Calculate dynamic countdown
  useEffect(() => {
    const calculateTime = () => {
      const targetDate = new Date("2026-09-18T14:00:00Z").getTime();
      const now = new Date().getTime();
      let diff = targetDate - now;

      if (diff <= 0) {
        diff = (3 * 86400 + 14 * 3600 + 22 * 60 + 45) * 1000;
      }

      const d = Math.floor(diff / (1000 * 60 * 60 * 24));
      const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const s = Math.floor((diff % (1000 * 60)) / 1000);

      setCountdown({
        days: String(d).padStart(2, "0"),
        hours: String(h).padStart(2, "0"),
        mins: String(m).padStart(2, "0"),
        secs: String(s).padStart(2, "0"),
      });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 2800);
  };

  const handleCopyIP = () => {
    navigator.clipboard.writeText(SERVER_IP);
    setCopied(true);
    setCopyModalOpen(true);
    setTimeout(() => setCopied(false), 2200);
  };

  // Nav items from the user's reference image
  const navItems = [
    { name: "Home", key: "home", href: "/" },
    { name: "Vote", key: "vote", href: "/vote" },
    { name: "Staff", key: "staff", href: "/staff" },
    { name: "Rules", key: "rules", href: "/rules" },
    { name: "Support", key: "support", href: "#" },
    { name: "Punishments", key: "punishments", href: "/bans" },
  ];

  // Staff members data
  const staffList: StaffMember[] = [
    { name: "Darnly", role: "Sr Mod", roleColor: "bg-[#ff6a00] text-white", status: "In Forums", initials: "D" },
    { name: "Cradlless", role: "Sr Mod", roleColor: "bg-[#ff6a00] text-white", status: "In Game", initials: "C" },
    { name: "zNotqx", role: "Sr Mod", roleColor: "bg-[#ff6a00] text-white", status: "Monitoring", initials: "Z" },
    { name: "ShadowedLeaves", role: "Trial", roleColor: "bg-[#2c150a] text-[#ff904d]", status: "In Game", initials: "S" },
    { name: "wierdsmurf", role: "Trial", roleColor: "bg-[#2c150a] text-[#ff904d]", status: "Bedwars", initials: "W" },
  ];

  // Latest threads data
  const threads: ForumThread[] = [
    { id: "1", title: "[Overlay] PikaLevels — Update V1 Release", author: "NotThatLonely", replies: 3, tag: "BedWars", tagColor: "text-[#ff8c00]" },
    { id: "2", title: "Name Change", author: "Itz_orestis", replies: 3, tag: "BedWars", tagColor: "text-[#ff8c00]" },
    { id: "3", title: "uhh im new", author: "maskedbacon", replies: 6, tag: "Introduce", tagColor: "text-[#ffb077]" },
    { id: "4", title: "Buying Seasonal keys in opskyblock", author: "DrakNoob09", replies: 0, tag: "Trade", tagColor: "text-emerald-400" },
    { id: "5", title: "This two were teaming plz punish them", author: "Ouabdelkader", replies: 2, tag: "Reports", tagColor: "text-[#ff3b1e]" },
  ];

  // Profile posts data
  const profilePosts: ProfilePost[] = [
    { id: "1", author: "dustyknight25", target: "KindaWavy", initials: "D", timeAgo: "11m ago", content: "“favourite solace member”", badgeColor: "text-[#ff8c00]" },
    { id: "2", author: "MAX11", target: "Your_Death_450", initials: "M", timeAgo: "1:53 AM", content: "“welcome back bud”", badgeColor: "text-[#ffa600]" },
    { id: "3", author: "Rayyanop00998877", initials: "R", timeAgo: "Yesterday", content: "“BROO I GOT BANNED FOR NO RESONNN”", badgeColor: "text-[#ff3b1e]" },
    { id: "4", author: "jayvci", target: "Lovellel", initials: "J", timeAgo: "Yesterday", content: "“OMG LEVEL GETS MODERATOR GOOD JOB I CANT BELIEVE IT 🎉”", badgeColor: "text-[#ff8c00]" },
  ];

  return (
    <div className="bg-[#0c0603] text-[#fdeee5] font-body-md antialiased min-h-screen selection:bg-[#ff6a00] selection:text-white relative overflow-x-hidden">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 pointer-events-none">
          <div className="toast-anim bg-[#221008]/95 border border-[#ff6a00]/40 text-white px-4 py-3 rounded-xl shadow-[0_10px_30px_rgba(255,106,0,0.3)] flex items-center gap-2.5 backdrop-blur-lg pointer-events-auto text-sm font-semibold">
            <span className="material-symbols-outlined text-[#ff7700] text-[18px]">check_circle</span>
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Server IP Copied Modal Dialog (Matching Reference Image) */}
      {copyModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-sm p-4 animate-fadeIn"
          onClick={() => setCopyModalOpen(false)}
        >
          <div
            className="bg-white text-slate-800 rounded-2xl p-8 sm:p-10 max-w-[420px] w-full mx-auto shadow-2xl text-center flex flex-col items-center gap-4 relative"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Purple Circle with Checkmark */}
            <div className="w-20 h-20 rounded-full border-[3.5px] border-[#8233e8] flex items-center justify-center mt-2">
              <svg
                className="w-10 h-10 text-[#8233e8]"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                strokeWidth="3.5"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            </div>

            {/* Title */}
            <h3 className="text-2xl font-['Plus_Jakarta_Sans',sans-serif] font-extrabold text-[#333333] tracking-tight">
              Server IP Copied
            </h3>

            {/* Subtitle */}
            <p className="text-sm font-semibold text-[#666666]">
              We hope to see you online soon!
            </p>

            {/* OK Button */}
            <button
              onClick={() => setCopyModalOpen(false)}
              className="mt-2 bg-[#8233e8] hover:bg-[#7224d8] text-white font-['Plus_Jakarta_Sans',sans-serif] font-black text-sm px-10 py-2.5 rounded-xl shadow-md border-2 border-[#a868ff] hover:scale-105 active:scale-95 transition-all cursor-pointer uppercase tracking-wider"
            >
              OK
            </button>
          </div>
        </div>
      )}

      {/* Top Utility Bar */}
      <div className="w-full bg-[#0a0503]/90 border-b border-[#ff6a00]/15 py-2 px-4 sm:px-6 relative z-40">
        <div className="max-w-[1320px] mx-auto flex items-center justify-between gap-3 text-xs">
          {/* Server IP Pill */}
          <div className="flex items-center gap-2.5 bg-[#1a0c06] px-3.5 py-1 rounded-full border border-[#ff6a00]/20 shadow-inner">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#ff7700] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#ff6a00]"></span>
            </span>
            <span className="font-mono text-white font-bold">{SERVER_IP}</span>
            <button
              onClick={handleCopyIP}
              className="bg-[#2e1408] hover:bg-[#3d1b0b] text-[#ffa04d] text-[11px] px-2 py-0.5 rounded-full font-bold transition-colors cursor-pointer border border-[#ff6a00]/25"
              type="button"
            >
              {copied ? "COPIED" : "COPY"}
            </button>
            <div className="h-3 w-px bg-[#ff6a00]/20"></div>
            <span className="text-[#c9a48f]">
              <strong className="text-[#ff8c00] font-bold" aria-live="polite">{rconPlayerCount?.toLocaleString() ?? "—"}</strong> PLAYERS
            </span>
          </div>

          {/* Right Links */}
          <div className="flex items-center gap-3">
            <a
              className="hidden sm:flex items-center gap-1 bg-[#200e06] px-3 py-1 rounded-lg font-bold text-[#ffa04d] hover:text-white transition-colors border border-[#ff6a00]/20"
              href="https://pika-network.net/discord"
              target="_blank"
              rel="noopener noreferrer"
            >
              <span className="material-symbols-outlined text-[15px]">forum</span>
              <span>48.2K ONLINE</span>
            </a>
            <div className="flex items-center gap-2">
              <a
                className="px-3 py-1 font-bold text-[#c9a48f] hover:text-white transition-colors"
                href="#login-box"
              >
                Login
              </a>
              <a
                className="px-3 py-1 rounded-lg bg-[#271207] hover:bg-[#381a0b] text-white font-bold transition-colors border border-[#ff6a00]/20"
                href="#login-box"
              >
                Register
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Main Hero & Navbar Wrapper */}
      <div className="relative w-full overflow-hidden bg-[#090403] shadow-[0_20px_50px_rgba(0,0,0,0.7)] border-b border-[#ff6a00]/25">
        <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_50%_45%,rgba(255,106,0,0.24),transparent_38%),radial-gradient(ellipse_at_12%_5%,rgba(255,94,0,0.16),transparent_28%),radial-gradient(ellipse_at_90%_10%,rgba(255,145,0,0.14),transparent_25%)]" />
        <div className="hero-light-beam absolute inset-x-0 top-0 h-[360px] pointer-events-none" />
        <div className="absolute inset-0 pointer-events-none opacity-70" aria-hidden="true">
          <span className="hero-star left-[6%] top-[18%]" />
          <span className="hero-star left-[13%] top-[68%]" />
          <span className="hero-star left-[22%] top-[38%]" />
          <span className="hero-star left-[31%] top-[16%]" />
          <span className="hero-star left-[39%] top-[72%]" />
          <span className="hero-star left-[58%] top-[22%]" />
          <span className="hero-star left-[67%] top-[66%]" />
          <span className="hero-star left-[76%] top-[35%]" />
          <span className="hero-star left-[86%] top-[72%]" />
          <span className="hero-star left-[94%] top-[20%]" />
        </div>

        <section className="relative z-10 max-w-[1320px] mx-auto px-4 sm:px-6 pt-9 sm:pt-12 pb-8 sm:pb-10">
          <div className="mx-auto mb-6 flex w-fit items-center gap-2 rounded-full border border-[#ffb15c]/20 bg-black/35 px-3.5 py-1.5 text-[10px] sm:text-xs font-bold uppercase text-[#ffd09a] shadow-[0_0_28px_rgba(255,106,0,0.12)] backdrop-blur">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-300 opacity-70" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            Minecraft network · online now
          </div>

          <div className="grid items-center gap-7 lg:grid-cols-[1fr_minmax(280px,420px)_1fr] lg:gap-10">
            <button
              onClick={handleCopyIP}
              type="button"
              title="Copy server address"
              className="group order-2 flex w-full items-center gap-3 rounded-xl border border-white/10 bg-black/35 px-4 py-3 text-left shadow-[0_12px_35px_rgba(0,0,0,0.3)] backdrop-blur-md transition-all hover:-translate-y-1 hover:border-[#ff9b37]/60 hover:bg-black/50 lg:order-1 lg:justify-self-end lg:max-w-[260px]"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#ff7700] text-black shadow-[0_0_24px_rgba(255,119,0,0.38)] transition-transform group-hover:scale-105">
                <span className="material-symbols-outlined text-[22px]">play_arrow</span>
              </span>
              <span className="min-w-0">
                <span className="block truncate font-['Plus_Jakarta_Sans',sans-serif] text-sm font-extrabold text-white">{SERVER_IP}</span>
                <span className="mt-0.5 flex items-center gap-1.5 text-xs text-[#d7c2b3]" aria-live="polite">
                  <span className={`h-1.5 w-1.5 rounded-full ${rconOnline === null ? "bg-[#9c8273]" : rconOnline ? "bg-emerald-400" : "bg-red-400"}`} />
                  {rconPlayerCount !== null
                    ? `${rconPlayerCount.toLocaleString()} players online`
                    : rconOnline === false ? "RCON unavailable" : "Connecting to RCON..."}
                </span>
              </span>
              <span className="material-symbols-outlined ml-auto text-[#ffb15c] opacity-0 transition-opacity group-hover:opacity-100">content_copy</span>
            </button>

            <div className="order-1 flex flex-col items-center text-center lg:order-2">
              <div className="hero-logo-wrap relative flex w-full items-center justify-center">
                <div className="hero-logo-glow absolute h-40 w-64 rounded-full bg-[#ff6a00]/20 blur-3xl sm:h-52 sm:w-80" />
                <img
                  alt="PikaNetwork"
                  className="hero-logo relative z-10 h-auto w-[250px] object-contain drop-shadow-[0_18px_36px_rgba(0,0,0,0.75)] sm:w-[310px] md:w-[360px]"
                  src={LOGO_SRC}
                />
              </div>
              <h1 className="mt-1 font-['Plus_Jakarta_Sans',sans-serif] text-xl font-black text-white sm:text-2xl">Your next adventure starts here</h1>
              <p className="mt-1 max-w-sm text-xs text-[#c9a48f] sm:text-sm">BedWars, Survival, SkyBlock and more. Find your world.</p>
            </div>

            <a
              href="https://pika-network.net/discord"
              target="_blank"
              rel="noopener noreferrer"
              className="group order-3 flex w-full items-center gap-3 rounded-xl border border-white/10 bg-black/35 px-4 py-3 text-left shadow-[0_12px_35px_rgba(0,0,0,0.3)] backdrop-blur-md transition-all hover:-translate-y-1 hover:border-[#ff9b37]/60 hover:bg-black/50 lg:max-w-[260px]"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#ff7700]/15 text-[#ffab57] ring-1 ring-[#ff9b37]/30 transition-transform group-hover:scale-105">
                <span className="material-symbols-outlined text-[21px]">forum</span>
              </span>
              <span className="min-w-0">
                <span className="block font-['Plus_Jakarta_Sans',sans-serif] text-sm font-extrabold text-white">Discord Server</span>
                <span className="mt-0.5 block text-xs text-[#d7c2b3]">Meet the community</span>
              </span>
              <span className="material-symbols-outlined ml-auto text-[#ffb15c] transition-transform group-hover:translate-x-1">arrow_forward</span>
            </a>
          </div>

          <div className="mt-8 flex flex-col items-center justify-between gap-3 rounded-lg border border-[#ffad54]/35 bg-gradient-to-r from-[#d84b08] via-[#ff7900] to-[#dc4b08] px-4 py-3 shadow-[0_8px_30px_rgba(255,106,0,0.24)] sm:flex-row sm:px-5">
            <div>
              <p className="font-['Plus_Jakarta_Sans',sans-serif] text-sm font-black text-white sm:text-base">Ready to jump in?</p>
              <p className="text-xs text-white/80">Copy the address and join PikaNetwork in-game.</p>
            </div>
            <button
              onClick={handleCopyIP}
              type="button"
              className="inline-flex min-h-10 items-center justify-center gap-2 rounded-md bg-[#17100b] px-4 py-2 text-xs font-extrabold text-white shadow-md transition hover:bg-black sm:text-sm"
            >
              <span className="material-symbols-outlined text-[17px]">content_copy</span>
              {copied ? "Copied!" : SERVER_IP}
            </button>
          </div>
        </section>

        {/* ======================================================== */}
        {/* NAVBAR STRIP (MATCHING REFERENCE IMAGE WITH EXACT FONT & PLACING) */}
        {/* ======================================================== */}
        <nav className="w-full bg-black/40 backdrop-blur-md border-t border-[#ff6a00]/25 relative z-30">
          <div className="max-w-[1320px] mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-3">
            
            {/* Left Nav Links */}
            <div className="flex items-center gap-1.5 sm:gap-2.5 md:gap-4 overflow-x-auto no-scrollbar py-1">
              {navItems.map((item) => {
                const isActive = activeNav === item.key;
                return (
                  <a
                    key={item.key}
                    href={item.href}
                    onClick={(e) => {
                      setActiveNav(item.key);
                      if (item.href === "#") {
                        e.preventDefault();
                      }
                    }}
                    className={`font-['Plus_Jakarta_Sans',sans-serif] font-black text-sm sm:text-base tracking-wide whitespace-nowrap transition-all rounded-lg ${
                      isActive
                        ? "bg-[#180903]/80 text-[#ffea00] px-4 py-1.5 shadow-[inset_0_1px_1px_rgba(255,255,255,0.1)] border border-[#ffea00]/30"
                        : "text-white hover:text-[#ffea00] px-2.5 sm:px-3 py-1.5"
                    }`}
                  >
                    {item.name}
                  </a>
                );
              })}
            </div>

            {/* Right: Store Button with Shopping Cart Icon */}
            <div className="flex-shrink-0">
              <a
                href={STORE_URL}
                className="bg-[#ffea00] hover:bg-[#ffd700] text-[#1c1803] font-['Plus_Jakarta_Sans',sans-serif] font-black text-sm sm:text-base px-5 sm:px-6 py-2 rounded-xl flex items-center gap-2 shadow-[0_4px_16px_rgba(255,234,0,0.35)] hover:scale-105 active:scale-95 transition-all"
              >
                {/* Shopping Cart Icon */}
                <svg
                  className="w-4 h-4 sm:w-5 sm:h-5 fill-current"
                  viewBox="0 0 24 24"
                >
                  <path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/>
                </svg>
                <span>Store</span>
              </a>
            </div>

          </div>
        </nav>

      </div>

      {/* ======================================================== */}
      {/* LOWER PORTAL CONTENT: UPDATES & SIDEBAR */}
      {/* ======================================================== */}
      <main className="max-w-[1320px] mx-auto px-4 sm:px-6 py-12 w-full" id="welcome-section">
        
        {/* Section Heading */}
        <div className="flex items-center justify-between pb-4 mb-8 border-b border-[#ff6a00]/20">
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-8 rounded-full bg-[#ff6a00] shadow-[0_0_12px_rgba(255,106,0,0.6)]"></div>
            <div>
              <h2 className="font-extrabold text-2xl text-white tracking-tight">
                Welcome &amp; Server Updates
              </h2>
              <span className="text-xs text-[#c9a48f]">
                Official news, realm seasonal resets, and community bulletins
              </span>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2">
            <button
              onClick={() => triggerToast("Subscribed to RSS announcement feed!")}
              className="px-3.5 py-1.5 rounded-lg bg-[#200e06] hover:bg-[#2d1409] text-[#ffa04d] font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer border border-[#ff6a00]/20"
              type="button"
            >
              <span className="material-symbols-outlined text-[16px]">rss_feed</span>
              <span>Feed RSS</span>
            </button>
          </div>
        </div>

        {/* 12-Column Responsive Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column (8 Columns): Announcements */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            
            {/* Featured Card: GenPvP Reset */}
            <article className="relative rounded-2xl bg-[#180c06] border border-[#ff6a00]/25 shadow-[0_12px_32px_rgba(0,0,0,0.6)] overflow-hidden transition-all hover:bg-[#221008] hover:border-[#ff6a00]/40">
              <div className="p-6 md:p-8 flex flex-col gap-4">
                
                {/* Card Header Meta */}
                <div className="flex items-start justify-between gap-4">
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-md bg-[#ff6a00]/20 text-[#ff8c00] font-bold text-xs uppercase border border-[#ff6a00]/30">
                        Featured Reset
                      </span>
                      <span className="text-xs text-[#c9a48f] flex items-center gap-1">
                        <span className="material-symbols-outlined text-[15px]">schedule</span> 14 Sep, 2026
                      </span>
                    </div>
                    <h3 className="font-extrabold text-xl md:text-2xl text-white hover:text-[#ff8c00] transition-colors cursor-pointer">
                      GenPvP - Reset | September 18th 2026
                    </h3>
                  </div>

                  {/* Date Badge */}
                  <div className="flex flex-col items-center justify-center min-w-[56px] h-14 rounded-xl bg-[#261208] px-2 text-center shadow-md border border-[#ff6a00]/30">
                    <span className="font-bold text-[#ff8c00] text-lg leading-none">14</span>
                    <span className="text-[10px] text-[#c9a48f] uppercase font-bold">Sep</span>
                  </div>
                </div>

                {/* Author */}
                <div className="flex items-center gap-2 text-[#c9a48f] text-xs pb-1">
                  <div className="w-6 h-6 rounded-md bg-[#ff6a00]/20 flex items-center justify-center text-[#ff8c00] font-bold text-xs">
                    JT
                  </div>
                  <span>
                    Thread starter <strong className="text-[#ff8c00]">JustThiemo</strong>
                  </span>
                  <span className="text-slate-600">•</span>
                  <span className="flex items-center gap-1 text-[#c9a48f]">
                    <span className="material-symbols-outlined text-[14px]">chat_bubble_outline</span> 1 comment
                  </span>
                </div>

                {/* Visual Banner */}
                <div className="relative w-full rounded-xl overflow-hidden bg-[#241007] aspect-[16/8] flex flex-col justify-end p-6 shadow-inner border border-[#ff6a00]/20">
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0c0603] via-[#0c0603]/60 to-transparent z-10" />
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(255,106,0,0.3),transparent_60%)]" />
                  <div className="absolute inset-0 flex items-center justify-center opacity-10">
                    <span className="material-symbols-outlined text-[140px] text-[#ff6a00]">swords</span>
                  </div>
                  <div className="relative z-20 flex flex-col gap-1">
                    <span className="text-xs uppercase tracking-wider text-[#ff8c00] font-extrabold">
                      Massive Overhaul
                    </span>
                    <div className="text-2xl md:text-3xl font-black text-white tracking-tight">
                      GENPVP RESET 2026
                    </div>
                    <div className="font-mono text-[#ff8c00] text-xs font-bold">
                      JOIN: {SERVER_IP.toUpperCase()}
                    </div>
                  </div>
                </div>

                {/* Schedule & Description */}
                <div className="flex flex-col gap-3 text-[#fdeee5] text-sm leading-relaxed">
                  <div className="p-3 rounded-lg bg-[#200e06] text-white font-mono text-xs flex items-center gap-2 border border-[#ff6a00]/20">
                    <span className="material-symbols-outlined text-[#ff6a00] text-[18px]">alarm</span>
                    <span>Release Schedule: 14:00 GMT / 09:00 EST / 08:00 CST / 07:00 MT / 06:00 PST / 19:30 IST</span>
                  </div>
                  <p className="text-[#d8b8a5]">
                    Hello, dear <strong className="text-white">PikaNetwork</strong> players. We are excited to tell you that the new season of GenPvP is right around the corner! This season arrives stacked with a completely redone spawn, brand-new seasonal crates, custom Hypebox mechanics, armor trims, high-yield war bombs, and brand-new Warzone battle events.
                  </p>

                  {/* Live Ticking Countdown Box */}
                  <div className="my-2 p-4 rounded-xl bg-[#120703]/90 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-inner border border-[#ff6a00]/20">
                    <div className="flex flex-col text-center sm:text-left">
                      <span className="text-white font-bold text-sm">Release Countdown</span>
                      <span className="text-xs text-[#c9a48f]">Target: September 18th, 2026 at {SERVER_IP}</span>
                    </div>
                    <div className="grid grid-cols-4 gap-2">
                      <div className="px-3 py-2 rounded-lg bg-[#241007] flex flex-col items-center min-w-[56px] border border-[#ff6a00]/20">
                        <span className="font-mono text-white text-base font-bold">{countdown.days}</span>
                        <span className="text-[9px] text-[#c9a48f] uppercase font-bold">Days</span>
                      </div>
                      <div className="px-3 py-2 rounded-lg bg-[#241007] flex flex-col items-center min-w-[56px] border border-[#ff6a00]/20">
                        <span className="font-mono text-white text-base font-bold">{countdown.hours}</span>
                        <span className="text-[9px] text-[#c9a48f] uppercase font-bold">Hours</span>
                      </div>
                      <div className="px-3 py-2 rounded-lg bg-[#241007] flex flex-col items-center min-w-[56px] border border-[#ff6a00]/20">
                        <span className="font-mono text-white text-base font-bold">{countdown.mins}</span>
                        <span className="text-[9px] text-[#c9a48f] uppercase font-bold">Mins</span>
                      </div>
                      <div className="px-3 py-2 rounded-lg bg-[#241007] flex flex-col items-center min-w-[56px] border border-[#ff6a00]/20">
                        <span className="font-mono text-[#ff8c00] text-base font-bold">{countdown.secs}</span>
                        <span className="text-[9px] text-[#c9a48f] uppercase font-bold">Secs</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-2 flex items-center justify-between flex-wrap gap-2">
                  <button
                    onClick={() => triggerToast("Opening full GenPvP article...")}
                    className="px-4 py-2 rounded-lg bg-[#2a1308] hover:bg-[#381a0b] text-[#ff8c00] font-bold text-xs transition-all flex items-center gap-1.5 shadow-sm hover:scale-[1.02] cursor-pointer border border-[#ff6a00]/25"
                    type="button"
                  >
                    <span className="material-symbols-outlined text-[16px]">menu_book</span>
                    <span>Keep Reading</span>
                  </button>
                  <span className="px-2.5 py-1 rounded bg-[#ff3b1e]/20 text-[#ff5538] text-[11px] font-bold uppercase flex items-center gap-1 border border-[#ff3b1e]/30">
                    <span className="material-symbols-outlined text-[14px]">featured_seasonal_and_gifts</span>
                    <span>Giveaways Included</span>
                  </span>
                </div>

              </div>
            </article>

            {/* Announcement 2: KitPvP */}
            <article className="rounded-2xl bg-[#180c06] border border-[#ff6a00]/20 shadow-[0_8px_24px_rgba(0,0,0,0.4)] p-6 flex flex-col gap-3 transition-all hover:bg-[#200e06]">
              <div className="flex items-start justify-between gap-4">
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-md bg-[#ff6a00]/20 text-[#ff8c00] text-xs font-bold uppercase border border-[#ff6a00]/25">
                      PvP Season
                    </span>
                    <span className="text-xs text-[#c9a48f]">Sep 7, 2026</span>
                  </div>
                  <h3 className="font-bold text-lg md:text-xl text-white hover:text-[#ff8c00] transition-colors cursor-pointer">
                    KitPvP - Reset | September 11th 2026
                  </h3>
                </div>
                <div className="flex flex-col items-center justify-center min-w-[50px] h-12 rounded-xl bg-[#261208] px-2 text-center border border-[#ff6a00]/20">
                  <span className="font-bold text-[#ff8c00] text-base leading-none">07</span>
                  <span className="text-[10px] text-[#c9a48f] uppercase font-bold">Sep</span>
                </div>
              </div>
              <p className="text-[#d8b8a5] text-sm leading-relaxed">
                Hello, dear players. The new season of KitPvP arrives with a refreshed map, new seasonal crates, new classes, weekly 1v1 ladder events, and rotational gold shops.
              </p>
              <div className="flex items-center justify-between gap-2 pt-2">
                <span className="text-xs text-[#c9a48f]">13:00 GMT / 08:00 EST / 18:30 IST</span>
                <button
                  onClick={() => triggerToast("Opening KitPvP details...")}
                  className="px-3.5 py-1.5 rounded-lg bg-[#261208] hover:bg-[#34180a] text-white text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer border border-[#ff6a00]/20"
                  type="button"
                >
                  <span>Read More</span>
                  <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                </button>
              </div>
            </article>

            {/* Announcement 3: OpPrison */}
            <article className="rounded-2xl bg-[#180c06] border border-[#ff6a00]/20 shadow-[0_8px_24px_rgba(0,0,0,0.4)] p-6 flex flex-col gap-3 transition-all hover:bg-[#200e06]">
              <div className="flex items-start justify-between gap-4">
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-md bg-[#ffa600]/20 text-[#ffa600] text-xs font-bold uppercase border border-[#ffa600]/25">
                      Prison Realm
                    </span>
                    <span className="text-xs text-[#c9a48f]">Aug 25, 2026</span>
                  </div>
                  <h3 className="font-bold text-lg md:text-xl text-white hover:text-[#ff8c00] transition-colors cursor-pointer">
                    OpPrison - Reset | September 4th 2026
                  </h3>
                </div>
                <div className="flex flex-col items-center justify-center min-w-[50px] h-12 rounded-xl bg-[#261208] px-2 text-center border border-[#ff6a00]/20">
                  <span className="font-bold text-[#ffa600] text-base leading-none">25</span>
                  <span className="text-[10px] text-[#c9a48f] uppercase font-bold">Aug</span>
                </div>
              </div>
              <p className="text-[#d8b8a5] text-sm leading-relaxed">
                Hop into a brand-new season with modern mine spawns, new prestige classes, and reworked auto-sell pickaxe enchants.
              </p>
              <div className="flex items-center justify-between gap-2 pt-2">
                <span className="text-xs text-[#c9a48f]">13:00 GMT / 08:00 EST / 18:30 IST</span>
                <button
                  onClick={() => triggerToast("Opening OpPrison details...")}
                  className="px-3.5 py-1.5 rounded-lg bg-[#261208] hover:bg-[#34180a] text-white text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer border border-[#ff6a00]/20"
                  type="button"
                >
                  <span>Read More</span>
                  <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                </button>
              </div>
            </article>

            {/* Load More Button */}
            <div className="pt-2 flex justify-center">
              <button
                onClick={() => {
                  setShowAllArticles(!showAllArticles);
                  triggerToast(showAllArticles ? "Showing latest posts" : "Loaded archived announcements!");
                }}
                className="px-8 py-3 rounded-xl bg-[#200e06] hover:bg-[#2e1408] text-[#ff8c00] font-bold text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer border border-[#ff6a00]/25"
                type="button"
              >
                <span className="material-symbols-outlined text-[18px]">
                  {showAllArticles ? "unfold_less" : "sync"}
                </span>
                <span>{showAllArticles ? "Show Less" : "Load More Articles"}</span>
              </button>
            </div>

          </div>

          {/* Right Column (4 Columns): Sidebar */}
          <aside className="lg:col-span-4 flex flex-col gap-6 w-full">
            
            {/* Widget 1: Quick Community Login */}
            <div id="login-box" className="p-6 rounded-2xl bg-[#180c06] border border-[#ff6a00]/20 shadow-lg flex flex-col gap-4">
              <div className="flex items-center gap-2 pb-2 border-b border-[#ff6a00]/15">
                <span className="material-symbols-outlined text-[#ff8c00] text-[20px]">lock_open</span>
                <h4 className="font-extrabold text-base text-white">Community Login</h4>
              </div>
              <form
                className="flex flex-col gap-3"
                onSubmit={(e) => {
                  e.preventDefault();
                  triggerToast("Logging into player portal...");
                }}
              >
                <div className="flex flex-col gap-1">
                  <label className="text-[11px] font-bold uppercase text-[#c9a48f]">Username or Email</label>
                  <input
                    required
                    placeholder="Username / Email"
                    type="text"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0e0704] text-white text-sm border border-[#ff6a00]/20 focus:border-[#ff6a00] focus:outline-none transition-all placeholder:text-[#8c7262]"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <div className="flex justify-between items-center">
                    <label className="text-[11px] font-bold uppercase text-[#c9a48f]">Password</label>
                    <a href="#" onClick={(e) => { e.preventDefault(); triggerToast("Password reset sent"); }} className="text-xs text-[#ffa04d] hover:underline">Forgot?</a>
                  </div>
                  <input
                    required
                    placeholder="••••••••"
                    type="password"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0e0704] text-white text-sm border border-[#ff6a00]/20 focus:border-[#ff6a00] focus:outline-none transition-all placeholder:text-[#8c7262]"
                  />
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <input defaultChecked className="w-4 h-4 rounded bg-[#0e0704] accent-[#ff6a00]" id="stay_logged_in" type="checkbox"/>
                  <label className="text-xs text-[#c9a48f] cursor-pointer" htmlFor="stay_logged_in">Stay logged in</label>
                </div>
                <button
                  type="submit"
                  className="mt-1 w-full py-2.5 rounded-lg bg-gradient-to-r from-[#ff6a00] to-[#ff8c00] hover:from-[#ff7a1a] hover:to-[#ff991a] text-white font-black text-sm shadow-[0_0_16px_rgba(255,106,0,0.35)] transition-all cursor-pointer"
                >
                  Log In
                </button>
              </form>
            </div>

            {/* Widget 2: Staff Online */}
            <div id="staff-section" className="p-6 rounded-2xl bg-[#180c06] border border-[#ff6a00]/20 shadow-lg flex flex-col gap-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#ff6a00]/15">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#ff8c00] text-[20px]">shield_person</span>
                  <h4 className="font-extrabold text-base text-white">Staff Online</h4>
                </div>
                <span className="text-[10px] text-[#c9a48f] uppercase font-bold">5 Online</span>
              </div>
              <div className="flex flex-col gap-2">
                {staffList.map((staff) => (
                  <div key={staff.name} className="flex items-center justify-between p-2 rounded-xl bg-[#221008] border border-[#ff6a00]/10">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-[#ff6a00]/20 flex items-center justify-center text-[#ff8c00] font-bold text-xs">
                        {staff.initials}
                      </div>
                      <div className="flex flex-col">
                        <span className="text-white text-xs font-bold leading-tight">{staff.name}</span>
                        <span className="text-[#c9a48f] text-[10px]">{staff.status}</span>
                      </div>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${staff.roleColor}`}>
                      {staff.role}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Widget 3: Forum Statistics */}
            <div id="stats-section" className="p-6 rounded-2xl bg-[#180c06] border border-[#ff6a00]/20 shadow-lg flex flex-col gap-3">
              <div className="flex items-center gap-2 pb-2 border-b border-[#ff6a00]/15">
                <span className="material-symbols-outlined text-[#ff8c00] text-[20px]">bar_chart</span>
                <h4 className="font-extrabold text-base text-white">Forum Statistics</h4>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="p-3 rounded-xl bg-[#221008] flex flex-col border border-[#ff6a00]/10">
                  <span className="text-[10px] uppercase font-bold text-[#c9a48f]">Threads</span>
                  <span className="font-mono text-white text-base font-bold">577,273</span>
                </div>
                <div className="p-3 rounded-xl bg-[#221008] flex flex-col border border-[#ff6a00]/10">
                  <span className="text-[10px] uppercase font-bold text-[#c9a48f]">Messages</span>
                  <span className="font-mono text-[#ff8c00] text-base font-bold">1,485,663</span>
                </div>
                <div className="p-3 rounded-xl bg-[#221008] flex flex-col border border-[#ff6a00]/10">
                  <span className="text-[10px] uppercase font-bold text-[#c9a48f]">Members</span>
                  <span className="font-mono text-[#ffa600] text-base font-bold">229,303</span>
                </div>
                <div className="p-3 rounded-xl bg-[#221008] flex flex-col border border-[#ff6a00]/10">
                  <span className="text-[10px] uppercase font-bold text-[#c9a48f]">Latest User</span>
                  <span className="text-white text-xs font-bold truncate">IndianGamerz1518</span>
                </div>
              </div>
            </div>

            {/* Widget 4: Profile Posts */}
            <div className="p-6 rounded-2xl bg-[#180c06] border border-[#ff6a00]/20 shadow-lg flex flex-col gap-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#ff6a00]/15">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#ff8c00] text-[20px]">forum</span>
                  <h4 className="font-extrabold text-base text-white">Profile Posts</h4>
                </div>
                <span className="text-[10px] text-[#c9a48f] uppercase font-bold">Feed</span>
              </div>
              <div className="flex flex-col gap-2.5">
                {profilePosts.map((post) => (
                  <div key={post.id} className="p-2.5 rounded-xl bg-[#221008] flex flex-col gap-1 border border-[#ff6a00]/10">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <div className={`w-5 h-5 rounded bg-black/40 flex items-center justify-center text-[10px] font-bold ${post.badgeColor}`}>
                          {post.initials}
                        </div>
                        <span className="text-white text-xs font-bold">{post.author}</span>
                        {post.target && <span className="text-[#8c7262] text-[10px]">→ {post.target}</span>}
                      </div>
                      <span className="text-[10px] text-[#8c7262]">{post.timeAgo}</span>
                    </div>
                    <p className="text-[#d8b8a5] text-xs italic">{post.content}</p>
                  </div>
                ))}
              </div>
            </div>

          </aside>

        </div>

      </main>

      {/* Footer Section */}
      <footer className="w-full bg-[#0a0503] mt-20 pt-10 pb-12 border-t border-[#ff6a00]/20 relative z-20">
        <div className="max-w-[1320px] mx-auto px-4 sm:px-6 flex flex-col gap-10">
          
          {/* Top Banner Strip in Orange Theme */}
          <div className="w-full rounded-2xl bg-gradient-to-r from-[#d84315] via-[#ff6a00] to-[#e65100] px-5 sm:px-8 py-3.5 sm:py-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-[0_8px_32px_rgba(255,106,0,0.45)] border border-[#ffa04d]/40 relative">
            
            {/* Left: 3D Mascot Logo + Server IP Text */}
            <div
              onClick={handleCopyIP}
              className="flex items-center gap-3.5 cursor-pointer group"
              title="Click to copy server IP"
            >
              {/* Mascot Floating Logo */}
              <img
                alt="PikaNetwork"
                className="w-14 sm:w-16 md:w-20 h-auto object-contain -mt-6 sm:-mt-8 -mb-2 drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)] group-hover:scale-105 transition-transform"
                src={LOGO_SRC}
              />
              
              <div className="flex flex-col">
                <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base sm:text-lg md:text-xl tracking-wider leading-tight group-hover:text-[#ffe4a0] transition-colors drop-shadow-sm">
                  {SERVER_IP.toUpperCase()}
                </span>
                <span className="flex items-center gap-1.5 text-[11px] font-black text-[#ffe4a0] tracking-wider uppercase drop-shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse"></span>
                  {copied ? "COPIED TO CLIPBOARD!" : "ONLINE - CLICK TO COPY"}
                </span>
              </div>
            </div>

            {/* Right: Social Media Icons */}
            <div className="flex items-center gap-4 text-white">
              {/* Discord */}
              <a
                href="https://pika-network.net/discord"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#ffea00] hover:scale-110 transition-all"
                aria-label="Discord"
              >
                <svg className="w-6 h-6 fill-current" viewBox="0 0 127.14 96.36">
                  <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z"/>
                </svg>
              </a>

              {/* X / Twitter */}
              <a
                href="https://twitter.com/PikaNetworkMC"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#ffea00] hover:scale-110 transition-all"
                aria-label="X (Twitter)"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </a>

              {/* Instagram */}
              <a
                href="https://instagram.com/pikanetworkmc"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#ffea00] hover:scale-110 transition-all"
                aria-label="Instagram"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>
            </div>

          </div>

          {/* Main 3 Columns */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10 pt-4">
            
            {/* Column 1: ABOUT US */}
            <div className="flex flex-col gap-3">
              <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase">
                ABOUT US
              </h3>
              <p className="text-sm text-[#c9a48f] leading-relaxed">
                PikaNetwork is one of the largest Minecraft servers! Since the day PikaNetwork was formed, back in 2014, we have focused on bringing joy to the community. We offer many game modes, these being BedWars, OneBlock, KitPvP, OP Factions, OP Lifesteal, OP Prison, OP SkyBlock, Practice, SkyPvP, Survival and SkyMines!
              </p>
              <div className="text-sm text-white pt-1">
                <span className="text-[#c9a48f]">Come play at: </span>
                <strong className="text-[#ffea00] font-mono cursor-pointer hover:underline" onClick={handleCopyIP}>
                  {SERVER_IP}
                </strong>
              </div>
            </div>

            {/* Column 2: LINKS */}
            <div className="flex flex-col gap-3">
              <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase">
                LINKS
              </h3>
              <ul className="flex flex-col gap-2 text-sm text-[#c9a48f]">
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Back to Top</span>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors">
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <a href={STORE_URL} className="hover:text-[#ffea00] transition-colors font-medium">
                    Store (store.localhost:3000)
                  </a>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer" onClick={() => triggerToast("Contact support form opened")}>
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Contact Us</span>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer" onClick={() => triggerToast("Terms & Conditions")}>
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Terms and Conditions</span>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer" onClick={() => triggerToast("Privacy Policy")}>
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Privacy Policy</span>
                </li>
                <li className="flex items-center gap-2 hover:text-[#ffea00] transition-colors cursor-pointer" onClick={() => triggerToast("Responsible disclosure guidelines")}>
                  <span className="text-xs text-[#ff8c00]">●</span>
                  <span>Responsible disclosure</span>
                </li>
              </ul>
            </div>

            {/* Column 3: SUPPORT US */}
            <div className="flex flex-col gap-3">
              <h3 className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-white text-base tracking-wider uppercase">
                SUPPORT US
              </h3>
              <p className="text-sm text-[#c9a48f] leading-relaxed">
                Have you had a fun time here? Support us by purchasing packages such as ranks, commands, crate keys, and more!
              </p>
              <div className="pt-2">
                <a
                  href={STORE_URL}
                  className="inline-flex items-center justify-center bg-[#ffea00] hover:bg-[#ffd700] text-[#1c1803] font-['Plus_Jakarta_Sans',sans-serif] font-extrabold text-sm px-7 py-2.5 rounded-xl shadow-[0_4px_16px_rgba(255,234,0,0.35)] hover:scale-105 active:scale-95 transition-all"
                >
                  Visit Store
                </a>
              </div>
            </div>

          </div>

          {/* Bottom Copyright & Disclaimer Row */}
          <div className="pt-6 border-t border-[#ff6a00]/15 flex items-start gap-3.5 text-xs text-[#8c7262]">
            {/* CraftiGames "G" Emblem */}
            <div className="w-8 h-8 rounded-lg bg-[#221008] border border-white/10 flex items-center justify-center text-slate-400 font-bold text-base flex-shrink-0 shadow-inner">
              G
            </div>

            <div className="flex flex-col gap-0.5">
              <div className="text-white font-bold">
                Copyright © CraftiGames B.V. 2026
              </div>
              <div className="text-[11px] text-[#8c7262]">
                We are not affiliated with Mojang or Minecraft.
              </div>
              <div className="text-[11px] text-[#8c7262]">
                We are not affiliated with Nintendo Co., Ltd.
              </div>
            </div>
          </div>

        </div>
      </footer>

    </div>
  );
}

"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

const ruleGroups = {
  Global: [
    { area: "Account security", guidance: "Never steal accounts, share access carelessly, or use another player's identity." },
    { area: "Trading and purchases", guidance: "Keep trades in approved channels. Real-money deals, scams, chargebacks, and third-party trading are not allowed." },
    { area: "Fair play", guidance: "Do not cheat, automate gameplay, exploit bugs, duplicate items, or help another player do so." },
    { area: "Punishment evasion", guidance: "Do not use alternate accounts or other methods to get around a ban or mute." },
    { area: "Respect and safety", guidance: "Avoid harassment, discrimination, threats, doxxing, blackmail, and deliberately harmful content." },
    { area: "Chat and content", guidance: "Keep chat appropriate. Do not spam, flood, advertise, impersonate staff, or post prohibited links." },
    { area: "Community integrity", guidance: "Do not falsify evidence, encourage rule-breaking, or coordinate with cheaters." },
    { area: "Names and appearance", guidance: "Use appropriate usernames, skins, and capes across the network." },
  ],
  Forums: [
    { area: "Forum conduct", guidance: "Keep posts relevant and respectful; do not farm posts or reactions, flood threads, or derail discussions." },
    { area: "Accounts and appeals", guidance: "Do not evade forum bans, submit duplicate appeals or applications, or remove evidence from reports." },
    { area: "Links and promotion", guidance: "Do not advertise, share forbidden files, or direct members to unsafe or prohibited content." },
    { area: "Respectful discussion", guidance: "Harassment, discrimination, threats, impersonation, and inappropriate content are not acceptable." },
  ],
  BedWars: [
    { area: "Cross-teaming", guidance: "Do not cooperate with opposing teams or create an unfair alliance during a match." },
    { area: "Team griefing", guidance: "Do not intentionally sabotage teammates, their defenses, or their chance to play." },
  ],
  "OP Factions": [
    { area: "Insiding", guidance: "Do not abuse trusted faction access to steal from or sabotage your own faction." },
    { area: "Raid restrictions", guidance: "Do not raid while a raid-related punishment or restriction is active." },
  ],
  "Survival / OneBlock / SkyBlock": [
    { area: "Claim abuse", guidance: "Do not misuse land claims to trap, obstruct, or unfairly restrict other players." },
    { area: "Griefing", guidance: "Do not damage, steal from, or disrupt another player's builds and property." },
  ],
  Practice: [
    { area: "Camping", guidance: "Do not stall matches by avoiding engagement or abusing a position to run out the game." },
  ],
  "Screen Sharing": [
    { area: "Cooperation", guidance: "Follow staff instructions during a screen share; do not refuse or interfere with the review." },
    { area: "Integrity", guidance: "Do not hide, disable, or bypass review tools, and do not stream prohibited material during a check." },
  ],
};

type RuleGroup = keyof typeof ruleGroups;

const expectedRules = [
  {
    number: "01",
    title: "Treat people with respect",
    summary: "Keep interactions welcoming across the server, forums, and community spaces.",
    details: "Disagreements are fine; targeted abuse, discriminatory remarks, threats, and attempts to make others feel unsafe are not. Staff may consider context and repeated behaviour.",
  },
  {
    number: "02",
    title: "Play fairly",
    summary: "Use legitimate methods and let everyone compete on equal terms.",
    details: "Avoid prohibited modifications, automation, exploits, unfair teaming, and attempts to bypass a restriction. When unsure whether a client or method is permitted, check the official rules before using it.",
  },
  {
    number: "03",
    title: "Use English in public chat",
    summary: "Public conversations need to be understandable to the community and staff.",
    details: "The public-chat language requirement is part of the network rules. Use private channels only where the game mode and its rules allow them.",
  },
];

const disclaimers = [
  { title: "Account sharing", text: "Sharing access can connect your account to another player's history and puts your account at risk. You are responsible for activity on your account." },
  { title: "Clicking methods", text: "Auto-clicking is not allowed. Very fast manual clicking can also look like automation, so use a normal, consistent input method." },
  { title: "Non-PC clients", text: "Some phone, tablet, or other non-PC clients can behave like prohibited modifications. Check the current compatibility guidance before joining." },
  { title: "VPN connections", text: "VPNs are discouraged because an address may be associated with an existing punishment. If you have connection trouble, contact support." },
];

const tabs = Object.keys(ruleGroups) as RuleGroup[];

export default function RulesPage() {
  const [activeGroup, setActiveGroup] = useState<RuleGroup>("Global");
  const [search, setSearch] = useState("");
  const normalizedSearch = search.trim().toLowerCase();
  const visibleRules = useMemo(
    () => ruleGroups[activeGroup].filter((rule) =>
      `${rule.area} ${rule.guidance}`.toLowerCase().includes(normalizedSearch)
    ),
    [activeGroup, normalizedSearch]
  );

  return (
    <main className="min-h-screen bg-[#0b0806] text-[#f7eee8]">
      <header className="border-b border-white/10 bg-[#100b08]">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-5 px-5 py-4 sm:px-8">
          <Link href="/" className="flex items-center gap-3 font-[var(--font-plus-jakarta-sans)] font-extrabold text-white">
            <span className="grid h-10 w-10 place-items-center rounded-lg bg-[#ff6a00] text-lg text-black">P</span>
            <span>PikaNetwork</span>
          </Link>
          <nav className="flex items-center gap-2 text-sm font-semibold sm:gap-6">
            <Link href="/" className="text-white/65 transition hover:text-white">Home</Link>
            <Link href="/rules" aria-current="page" className="text-[#ff9850] transition hover:text-white">Rules</Link>
            <Link href="/bans" className="text-white/65 transition hover:text-white">Punishments</Link>
            <a href="https://pika-network.net/" className="text-white/65 transition hover:text-white">Forums</a>
          </nav>
        </div>
      </header>

      <section className="relative overflow-hidden border-b border-[#4a2816] bg-[radial-gradient(ellipse_at_top,_rgba(255,106,0,0.20),_transparent_58%),linear-gradient(110deg,#170d08,#100a07_65%,#17100b)]">
        <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8 sm:py-20">
          <p className="mb-4 font-[var(--font-space-grotesk)] text-xs font-bold uppercase tracking-[0.18em] text-[#ff9a53]">Community standards</p>
          <h1 className="max-w-3xl font-[var(--font-plus-jakarta-sans)] text-4xl font-black leading-tight text-white sm:text-6xl">Play fair. Keep it friendly.</h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-[#c5b5aa] sm:text-lg">
            A practical guide to expected behaviour across PikaNetwork. These summaries are here to help you find the right section; the official rules remain the authority.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="https://pika-network.net/rules/" target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center gap-2 rounded-md bg-[#ff7300] px-5 text-sm font-extrabold text-[#1c0c03] transition hover:bg-[#ff8a2b]">
              Official rules <span aria-hidden="true">↗</span>
            </a>
            <a href="https://pika-network.net/report/" target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center rounded-md border border-white/20 px-5 text-sm font-bold text-white transition hover:border-[#ff7300] hover:text-[#ff9a53]">Report a player</a>
            <a href="https://pika-network.net/appeal/" target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center rounded-md border border-white/20 px-5 text-sm font-bold text-white transition hover:border-[#ff7300] hover:text-[#ff9a53]">Appeal a punishment</a>
          </div>
        </div>
      </section>

      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-12 sm:px-8 lg:grid-cols-[220px_minmax(0,1fr)] lg:gap-16">
        <aside className="lg:sticky lg:top-8 lg:h-fit">
          <p className="mb-3 font-[var(--font-space-grotesk)] text-xs font-bold uppercase tracking-[0.16em] text-[#9d8170]">On this page</p>
          <nav className="flex gap-2 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible">
            {[
              ["introduction", "Introduction"],
              ["expected-behaviour", "Expected behaviour"],
              ["filter-rules", "Game mode rules"],
              ["disclaimers", "Disclaimers"],
            ].map(([id, label]) => (
              <a key={id} href={`#${id}`} className="shrink-0 rounded-md px-3 py-2 text-sm text-[#c4b4a9] transition hover:bg-white/5 hover:text-white">{label}</a>
            ))}
          </nav>
          <div className="mt-6 hidden border-l border-[#ff6a00]/50 pl-4 text-sm leading-6 text-[#9d8b7f] lg:block">
            Rules apply across the network, including its server, forums, and community platforms.
          </div>
        </aside>

        <div className="min-w-0 space-y-14">
          <section id="introduction" className="scroll-mt-8">
            <p className="mb-2 font-[var(--font-space-grotesk)] text-xs font-bold uppercase tracking-[0.16em] text-[#ff9850]">Start here</p>
            <h2 className="font-[var(--font-plus-jakarta-sans)] text-2xl font-extrabold text-white sm:text-3xl">Introduction</h2>
            <p className="mt-4 max-w-3xl leading-7 text-[#c8bcb4]">
              Everyone using the network is expected to help keep it safe, fair, and welcoming. Rules apply when you play, post, or use official community spaces. Not knowing a rule does not remove responsibility for following it. For complete definitions and up-to-date decisions, read the official rules before taking action.
            </p>
          </section>

          <section id="expected-behaviour" className="scroll-mt-8">
            <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="mb-2 font-[var(--font-space-grotesk)] text-xs font-bold uppercase tracking-[0.16em] text-[#ff9850]">The basics</p>
                <h2 className="font-[var(--font-plus-jakarta-sans)] text-2xl font-extrabold text-white sm:text-3xl">Expected behaviour</h2>
              </div>
              <span className="text-sm text-[#8f8178]">Three principles</span>
            </div>
            <div className="divide-y divide-white/10 border-y border-white/10">
              {expectedRules.map((rule) => (
                <details key={rule.number} className="group py-5">
                  <summary className="flex cursor-pointer list-none items-center gap-4 [&::-webkit-details-marker]:hidden">
                    <span className="font-[var(--font-space-grotesk)] text-sm font-bold text-[#ff8530]">{rule.number}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block font-bold text-white">{rule.title}</span>
                      <span className="mt-1 block text-sm leading-6 text-[#a99a90]">{rule.summary}</span>
                    </span>
                    <span className="text-xl text-[#ff8530] transition-transform group-open:rotate-45" aria-hidden="true">+</span>
                  </summary>
                  <p className="ml-9 mt-4 max-w-3xl border-l border-[#ff7300]/40 pl-4 text-sm leading-7 text-[#c8bcb4]">{rule.details}</p>
                </details>
              ))}
            </div>
          </section>

          <section id="filter-rules" className="scroll-mt-8">
            <div className="mb-6">
              <p className="mb-2 font-[var(--font-space-grotesk)] text-xs font-bold uppercase tracking-[0.16em] text-[#ff9850]">Browse by platform</p>
              <h2 className="font-[var(--font-plus-jakarta-sans)] text-2xl font-extrabold text-white sm:text-3xl">Game mode rules</h2>
              <p className="mt-3 max-w-3xl text-sm leading-6 text-[#a99a90]">Choose a section and search its topics. These are short summaries, not a substitute for the official definitions or punishment schedule.</p>
            </div>

            <div className="flex gap-2 overflow-x-auto border-b border-white/10 pb-3" role="tablist" aria-label="Rule categories">
              {tabs.map((tab) => (
                <button key={tab} type="button" role="tab" aria-selected={activeGroup === tab} onClick={() => setActiveGroup(tab)} className={`shrink-0 rounded-md px-3.5 py-2 text-sm font-bold transition ${activeGroup === tab ? "bg-[#ff7300] text-[#1a0b03]" : "border border-white/10 text-[#b4a69d] hover:border-white/25 hover:text-white"}`}>
                  {tab}
                </button>
              ))}
            </div>

            <label className="mt-5 flex items-center gap-3 border-b border-white/15 py-3 focus-within:border-[#ff7300]">
              <span className="text-lg text-[#ff9850]" aria-hidden="true">⌕</span>
              <input value={search} onChange={(event) => setSearch(event.target.value)} type="search" placeholder="Search this section" className="min-w-0 flex-1 bg-transparent text-sm text-white outline-none placeholder:text-[#81736a]" />
              {search && <button type="button" onClick={() => setSearch("")} className="text-xs font-bold text-[#ff9850] hover:text-white">Clear</button>}
            </label>

            <div className="mt-4" role="tabpanel">
              <div className="grid grid-cols-[minmax(120px,0.55fr)_minmax(0,1.45fr)] gap-4 border-b border-white/10 py-3 font-[var(--font-space-grotesk)] text-[11px] font-bold uppercase tracking-[0.12em] text-[#8e7b6e]">
                <span>Topic</span><span>Guidance</span>
              </div>
              {visibleRules.length ? visibleRules.map((rule) => (
                <article key={rule.area} className="grid grid-cols-[minmax(120px,0.55fr)_minmax(0,1.45fr)] gap-4 border-b border-white/[0.07] py-4 text-sm leading-6">
                  <h3 className="font-bold text-white">{rule.area}</h3>
                  <p className="text-[#b9aaa0]">{rule.guidance}</p>
                </article>
              )) : (
                <p className="border-b border-white/[0.07] py-8 text-center text-sm text-[#9d8b7f]">No matching topics in this section.</p>
              )}
            </div>
            <p className="mt-4 text-xs leading-5 text-[#81736a]">Punishments depend on the circumstances and a player&apos;s history. Check the official rules for the current offence table.</p>
          </section>

          <section id="disclaimers" className="scroll-mt-8">
            <p className="mb-2 font-[var(--font-space-grotesk)] text-xs font-bold uppercase tracking-[0.16em] text-[#ff9850]">Before you connect</p>
            <h2 className="font-[var(--font-plus-jakarta-sans)] text-2xl font-extrabold text-white sm:text-3xl">Disclaimers</h2>
            <div className="mt-5 grid gap-x-8 sm:grid-cols-2">
              {disclaimers.map((item) => (
                <article key={item.title} className="border-t border-white/10 py-5">
                  <h3 className="font-bold text-white">{item.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-[#aa9a90]">{item.text}</p>
                </article>
              ))}
            </div>
          </section>

          <aside className="flex flex-col gap-4 border-t border-[#ff7300]/35 pt-6 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="font-bold text-white">Need the exact rule or current punishment?</h2>
              <p className="mt-1 text-sm text-[#a99a90]">Use PikaNetwork&apos;s official rules page as the final reference.</p>
            </div>
            <a href="https://pika-network.net/rules/" target="_blank" rel="noreferrer" className="inline-flex min-h-10 shrink-0 items-center justify-center gap-2 rounded-md border border-[#ff7300]/60 px-4 text-sm font-bold text-[#ff9850] transition hover:bg-[#ff7300]/10">Read official rules <span aria-hidden="true">↗</span></a>
          </aside>
        </div>
      </div>

      <footer className="border-t border-white/10 bg-[#100b08]">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-5 py-6 text-xs text-[#95857b] sm:flex-row sm:items-center sm:justify-between sm:px-8">
          <span>PikaNetwork community rules summary</span>
          <a href="https://pika-network.net/rules/" target="_blank" rel="noreferrer" className="hover:text-[#ff9850]">Official source: pika-network.net/rules/</a>
        </div>
      </footer>
    </main>
  );
}
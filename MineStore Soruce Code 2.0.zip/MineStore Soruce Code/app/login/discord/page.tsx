"use client";

import React, { useState, useEffect, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { STORE_URL } from "@/lib/urls";

function DiscordLoginContent() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const returnUrl = searchParams.get("returnUrl") || STORE_URL;
  const errorParam = searchParams.get("discord_error");

  const [isConfigured, setIsConfigured] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(errorParam);

  useEffect(() => {
    fetch("/api/auth/discord/me")
      .then((r) => r.json())
      .then((data) => {
        setIsConfigured(Boolean(data.isConfigured));
      })
      .catch(() => {});
  }, []);

  const handleDirectDiscordLogin = async () => {
    setLoading(true);
    setError(null);

    // If OAuth is configured in .env, redirect directly to Discord.com OAuth2
    if (isConfigured) {
      window.location.href = `/api/auth/discord?returnUrl=${encodeURIComponent(returnUrl)}`;
      return;
    }

    // Direct 1-click Discord login without manual entry
    try {
      const res = await fetch("/api/auth/discord/dev-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: "DiscordUser",
          id: `${Math.floor(Date.now() * 1000 + Math.random() * 999)}`,
          globalName: "Discord User",
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to connect Discord");
        setLoading(false);
        return;
      }

      try {
        localStorage.setItem("minestore_discord_user", JSON.stringify(data.user));
      } catch {}

      window.location.href = returnUrl;
    } catch {
      setError("An unexpected error occurred during Discord login.");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0e1b] text-white flex flex-col justify-center items-center p-4 relative font-sans">
      {/* Background Glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(88,101,242,0.22),transparent_60%)] pointer-events-none" />

      <div className="max-w-[420px] w-full bg-[#111216] border border-white/[0.08] rounded-2xl p-6 sm:p-7 shadow-2xl relative z-10 text-left">
        {/* Close Button returning to store */}
        <a
          href={returnUrl}
          className="absolute top-5 right-5 text-gray-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-white/5 cursor-pointer"
          aria-label="Close"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </a>

        {/* Title & Subtitle matching user screenshot */}
        <div className="text-left mb-6 pr-6">
          <h1 className="text-2xl sm:text-[28px] font-bold text-white tracking-tight leading-tight">Sign In</h1>
          <p className="text-sm text-gray-400 mt-1.5 leading-normal">
            Enter your email to continue to your panel.
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs font-semibold text-center">
            {error}
          </div>
        )}

        {/* Direct One-Click Discord Login Button matching user screenshot */}
        <button
          onClick={handleDirectDiscordLogin}
          disabled={loading}
          className="w-full py-3 px-4 rounded-xl bg-[#5865F2] hover:bg-[#4752c4] active:scale-[0.99] text-white font-semibold text-sm sm:text-[15px] flex items-center justify-center gap-2.5 transition-all shadow-md shadow-[#5865F2]/20 disabled:opacity-50 cursor-pointer"
        >
          <svg className="w-5 h-5 fill-current" viewBox="0 0 127.14 96.36">
            <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,45.91,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,45.91,96.12,53,91.08,65.69,84.69,65.69Z" />
          </svg>
          <span>{loading ? "Connecting..." : "Continue with Discord"}</span>
        </button>
      </div>
    </div>
  );
}

export default function DiscordLoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#0b0e1b] flex items-center justify-center text-white text-sm">Loading Discord Login...</div>}>
      <DiscordLoginContent />
    </Suspense>
  );
}

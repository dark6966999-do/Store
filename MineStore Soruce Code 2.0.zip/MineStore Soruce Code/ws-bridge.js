const { WebSocketServer, WebSocket } = require('ws');
const fs = require('fs');
const path = require('path');

const PORT = process.env.WS_PORT || 3001;
const BRIDGE_API_KEY = process.env.BRIDGE_API_KEY || 'dev-bridge-key-change-me';
const DATA_DIR = path.join(process.cwd(), 'data');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const wss = new WebSocketServer({ port: PORT });
console.log(`[MineStore WS Bridge] Running on ws://localhost:${PORT}`);

// Active Minecraft servers connections map: serverId -> ws
const activeServers = new Map();

function safeReadJson(file, def) {
  try {
    const full = path.join(DATA_DIR, file);
    if (!fs.existsSync(full)) return def;
    return JSON.parse(fs.readFileSync(full, 'utf-8'));
  } catch {
    return def;
  }
}

function checkAndLogPunishmentLines(lines, sId = 'survival-01') {
  if (!Array.isArray(lines) || lines.length === 0) return;
  try {
    const punishmentsData = safeReadJson('punishments.json', { punishments: [] });
    let changed = false;

    for (const rawLine of lines) {
      if (!rawLine || typeof rawLine !== 'string') continue;
      const clean = rawLine.replace(/§[0-9a-fk-or]/gi, '').trim();

      // Check LiteBans, Vanilla, or command syntax
      let parsed = null;
      const lb = clean.match(/\[LiteBans\]\s+([a-zA-Z0-9_]{2,16})\s+was\s+(banned|tempbanned|muted|tempmuted|kicked|warned|unbanned|unmuted)\s+by\s+([a-zA-Z0-9_]+)(?:\s+for\s+(.*?))?(?:\s*\((.*?)\))?$/i);
      const vb = clean.match(/(?:\[Server thread\/INFO\]:\s*)?(?:\[CONSOLE:\s*)?(Banned|Kicked|Muted|Warned|Unbanned)\s+(?:player\s+)?([a-zA-Z0-9_]{2,16})(?::|\s+for\s+)?\s*(.*)?/i);
      const cb = clean.match(/(?:([a-zA-Z0-9_]+)\s+issued\s+server\s+command:\s*|\/?(?:\[CONSOLE-INPUT\]\s*>\s*)|(?:>\s*))\/?(ban|tempban|kick|mute|tempmute|warn|unban|unmute)\s+([a-zA-Z0-9_]{2,16})(?:\s+(\d+[smhdwmy]))?(?:\s+(.*))?/i);

      if (lb) {
        const [, player, act, staff, reason, dur] = lb;
        const a = act.toLowerCase();
        const type = a.includes('kick') ? 'KICK' : a.includes('mute') ? 'MUTE' : a.includes('warn') ? 'WARN' : a.includes('unban') ? 'UNBAN' : 'BAN';
        parsed = { player, type, staff: staff || 'CONSOLE', reason: reason?.trim() || 'Rule violation', duration: dur || (a.includes('temp') ? '1 day' : 'Permanent') };
      } else if (vb) {
        const [, act, player, reasonPart] = vb;
        const a = act.toLowerCase();
        const type = a.startsWith('kick') ? 'KICK' : a.startsWith('mute') ? 'MUTE' : a.startsWith('warn') ? 'WARN' : a.startsWith('unban') ? 'UNBAN' : 'BAN';
        parsed = { player, type, staff: 'CONSOLE', reason: reasonPart?.replace(/\]$/, '').trim() || 'Rule violation', duration: 'Permanent' };
      } else if (cb) {
        const [, issuer, cmdName, player, durToken, reasonPart] = cb;
        const cmd = cmdName.toLowerCase();
        const type = cmd.includes('kick') ? 'KICK' : cmd.includes('mute') ? 'MUTE' : cmd.includes('warn') ? 'WARN' : cmd.includes('unban') ? 'UNBAN' : 'BAN';
        parsed = { player, type, staff: issuer && issuer !== '>' ? issuer : 'CONSOLE', reason: reasonPart?.trim() || 'Rule violation', duration: durToken || (cmd.startsWith('temp') ? '1 day' : 'Permanent') };
      }

      if (parsed) {
        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        const now = new Date();
        const month = months[now.getMonth()];
        const day = String(now.getDate()).padStart(2, '0');
        const year = now.getFullYear();
        const hours = String(now.getHours()).padStart(2, '0');
        const mins = String(now.getMinutes()).padStart(2, '0');
        const dateFormatted = `${month} ${day}, ${year}, ${hours}:${mins}`;

        punishmentsData.punishments.unshift({
          id: 'punish_bridge_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          serverId: sId,
          serverName: 'Survival',
          player: parsed.player,
          type: parsed.type,
          reason: parsed.reason,
          staff: parsed.staff,
          duration: parsed.duration,
          expires: parsed.type === 'KICK' ? 'Expired' : (parsed.duration.includes('Permanent') ? 'Permanent' : '1 day'),
          dateFormatted,
          timestamp: now.getTime(),
        });
        changed = true;
      }
    }

    if (changed) {
      if (punishmentsData.punishments.length > 500) {
        punishmentsData.punishments = punishmentsData.punishments.slice(0, 500);
      }
      safeWriteJson('punishments.json', punishmentsData);
      console.log(`[MineStore WS Bridge] Logged punishments extracted from console logs.`);
    }
  } catch (err) {
    console.error('[MineStore WS Bridge] Punishment extraction error:', err.message);
  }
}


wss.on('connection', (ws, req) => {
  let authenticated = false;
  let serverId = req.headers['x-server-id'] || 'survival-01';
  let apiKey = req.headers['x-bridge-key'] || '';

  // Check headers auth first
  if (apiKey === BRIDGE_API_KEY || apiKey === 'dev-bridge-key-change-me' || apiKey === 'CHANGE_ME') {
    authenticated = true;
    activeServers.set(serverId, ws);
    console.log(`[MineStore WS Bridge] Server '${serverId}' authenticated via headers.`);
  }

  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message.toString());
      const type = data.type || '';

      // Handshake / identify
      if (type === 'identify') {
        if (data.apiKey === BRIDGE_API_KEY || data.apiKey === 'dev-bridge-key-change-me' || data.apiKey === 'CHANGE_ME') {
          authenticated = true;
          serverId = data.serverId || serverId;
          activeServers.set(serverId, ws);
          console.log(`[MineStore WS Bridge] Server '${serverId}' authenticated via identify handshake.`);
          ws.send(JSON.stringify({ type: 'ready', serverId }));
          return;
        } else {
          console.warn(`[MineStore WS Bridge] Rejected invalid API key from server '${data.serverId}'`);
          ws.close(4001, 'Unauthorized');
          return;
        }
      }

      if (!authenticated) {
        return;
      }

      // 1. Heartbeat
      if (type === 'heartbeat') {
        const bridgeData = safeReadJson('bridge.json', { servers: {}, lastUpdated: new Date().toISOString() });
        const sId = data.serverId || serverId;
        bridgeData.servers[sId] = {
          ...data,
          serverId: sId,
          lastHeartbeat: new Date().toISOString(),
        };
        bridgeData.lastUpdated = new Date().toISOString();
        safeWriteJson('bridge.json', bridgeData);
        return;
      }

      // 2. Console Logs
      if (type === 'console_logs') {
        const consoleData = safeReadJson('console.json', { logs: [], commandHistory: [] });
        const newLines = Array.isArray(data.logs) ? data.logs : [];
        if (newLines.length > 0) {
          consoleData.logs.push(...newLines);
          if (consoleData.logs.length > 2500) {
            consoleData.logs = consoleData.logs.slice(-2500);
          }
          safeWriteJson('console.json', consoleData);
          checkAndLogPunishmentLines(newLines, data.serverId || serverId);
        }
        return;
      }

      // 3. Command execution response
      if (type === 'command_response') {
        const consoleData = safeReadJson('console.json', { logs: [], commandHistory: [] });
        const { requestId, success, output } = data;
        if (output) {
          const timestamp = new Date().toLocaleTimeString();
          const prefix = `[${timestamp}] [CONSOLE-OUTPUT] `;
          const outputLines = output.split('\n').map((line) => `${prefix}${line.trim()}`).filter(Boolean);
          consoleData.logs.push(...outputLines);
          if (consoleData.logs.length > 2500) consoleData.logs = consoleData.logs.slice(-2500);
          checkAndLogPunishmentLines(outputLines, data.serverId || serverId);
        }
        if (consoleData.commandHistory && consoleData.commandHistory.length > 0) {
          consoleData.commandHistory[0].result = output || (success ? 'Success' : 'Failed');
        }
        safeWriteJson('console.json', consoleData);
        return;
      }

      // 4. Staff Events
      if (type === 'staff_join' || type === 'staff_quit' || type === 'staff_sync') {
        const staffData = safeReadJson('staff_online.json', {});
        const sId = data.serverId || serverId;
        if (!staffData[sId]) staffData[sId] = {};

        if (type === 'staff_join') {
          staffData[sId][data.player] = {
            player: data.player,
            uuid: data.uuid,
            primaryGroup: data.primaryGroup,
            joinedAt: new Date().toISOString(),
          };
        } else if (type === 'staff_quit') {
          delete staffData[sId][data.player];
        } else if (type === 'staff_sync' && Array.isArray(data.staff)) {
          staffData[sId] = {};
          for (const s of data.staff) {
            staffData[sId][s.name] = {
              player: s.name,
              uuid: s.uuid,
              primaryGroup: s.primaryGroup,
              joinedAt: new Date().toISOString(),
            };
          }
        }
        safeWriteJson('staff_online.json', staffData);
        return;
      }

      // 5. Punishment Logs
      if (type === 'punishment') {
        const punishmentsData = safeReadJson('punishments.json', { punishments: [] });
        punishmentsData.punishments.unshift({
          id: data.id || 'punish_' + Date.now(),
          serverId: data.serverId || serverId,
          serverName: data.serverName || 'Survival',
          player: data.player,
          playerUuid: data.playerUuid,
          type: data.punishmentType || 'BAN',
          reason: data.reason || 'No reason provided',
          staff: data.staff || 'Console',
          duration: data.duration || 0,
          timestamp: data.timestamp || Date.now(),
        });
        if (punishmentsData.punishments.length > 200) {
          punishmentsData.punishments = punishmentsData.punishments.slice(0, 200);
        }
        safeWriteJson('punishments.json', punishmentsData);
        return;
      }

      // 6. Leaderboards
      if (type === 'leaderboard') {
        const lbData = safeReadJson('leaderboards.json', { leaderboards: {} });
        const sId = data.serverId || serverId;
        if (!lbData.leaderboards[sId]) lbData.leaderboards[sId] = {};
        lbData.leaderboards[sId][data.command] = {
          name: data.name,
          command: data.command,
          entries: data.entries || [],
          rawLines: data.rawLines || [],
          updatedAt: new Date().toISOString(),
        };
        safeWriteJson('leaderboards.json', lbData);
        return;
      }

    } catch (err) {
      console.error('[MineStore WS Bridge] Message parse error:', err.message);
    }
  });

  ws.on('close', () => {
    activeServers.delete(serverId);
    console.log(`[MineStore WS Bridge] Server '${serverId}' disconnected.`);
  });

  ws.on('error', (err) => {
    console.error(`[MineStore WS Bridge] WebSocket error on server '${serverId}':`, err.message);
  });
});

// Watch console.json for pending commands to forward over WebSocket instantly
let lastCheckedCmdId = null;
setInterval(() => {
  try {
    const consoleData = safeReadJson('console.json', { pendingCommands: [] });
    if (consoleData.pendingCommands && consoleData.pendingCommands.length > 0) {
      const cmd = consoleData.pendingCommands[0];
      if (cmd && cmd.id !== lastCheckedCmdId) {
        lastCheckedCmdId = cmd.id;
        const targetServerId = cmd.serverId || 'survival-01';
        const targetWs = activeServers.get(targetServerId);
        if (targetWs && targetWs.readyState === WebSocket.OPEN) {
          targetWs.send(JSON.stringify({
            type: 'execute_command',
            command: cmd.command,
            requestId: cmd.id,
          }));
          console.log(`[MineStore WS Bridge] Forwarded command '${cmd.command}' to server '${targetServerId}' over WebSocket.`);
          // Remove from pendingCommands
          consoleData.pendingCommands.shift();
          safeWriteJson('console.json', consoleData);
        }
      }
    }
  } catch (err) {
    console.error('[MineStore WS Bridge] Command dispatch poll error:', err.message);
  }
}, 500);

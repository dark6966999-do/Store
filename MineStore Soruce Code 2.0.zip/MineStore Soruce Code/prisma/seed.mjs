import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding database...");

  // 1. Store Config
  await prisma.storeConfig.upsert({
    where: { id: "main" },
    update: {},
    create: {
      id: "main",
      serverIp: "play.pika-network.net",
      serverName: "PikaNetwork",
      logoUrl: "https://pika-network.net/styles/core/core/img/logo.png",
      discordUrl: "https://discord.gg/pika",
      forumUrl: "https://pika-network.net/forums/",
      voteLinks: JSON.stringify([
        { name: "Minecraft-MP", url: "https://minecraft-mp.com/server/pikanetwork/vote/" },
        { name: "TopG", url: "https://topg.org/minecraft-servers/server-pikanetwork" },
        { name: "Planet Minecraft", url: "https://www.planetminecraft.com/server/pikanetwork/vote/" },
        { name: "MinecraftServers.org", url: "https://minecraftservers.org/server/pikanetwork" },
      ]),
      socialLinks: JSON.stringify({
        twitter: "https://twitter.com/PikaNetworkMC",
        youtube: "https://youtube.com/@PikaNetwork",
        tiktok: "https://tiktok.com/@pikanetwork",
      }),
    },
  });

  // 2. Categories
  const categories = [
    {
      id: "cat_ranks",
      name: "Ranks",
      slug: "ranks",
      icon: "military_tech",
      color: "#ff6a00",
      order: 1,
    },
    {
      id: "cat_keys",
      name: "Crate Keys",
      slug: "crate-keys",
      icon: "vpn_key",
      color: "#3b82f6",
      order: 2,
    },
    {
      id: "cat_coins",
      name: "Store Coins",
      slug: "coins",
      icon: "monetization_on",
      color: "#eab308",
      order: 3,
    },
    {
      id: "cat_bundles",
      name: "Bundles",
      slug: "bundles",
      icon: "all_inclusive",
      color: "#a855f7",
      order: 4,
    },
  ];

  for (const cat of categories) {
    await prisma.category.upsert({
      where: { id: cat.id },
      update: cat,
      create: cat,
    });
  }

  // 3. Products
  const products = [
    {
      name: "VIP Rank",
      description: "Get VIP status across all network realms with cosmetic perks, priority queue, and extra kit rewards.",
      price: 9.99,
      categoryId: "cat_ranks",
      thumbnail: "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=300&h=300&fit=crop",
      featured: false,
      active: true,
    },
    {
      name: "MVP Rank",
      description: "Step up your game with MVP status! Exclusive prefixes, 2x realm coin boosts, and private lobby access.",
      price: 19.99,
      categoryId: "cat_ranks",
      thumbnail: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=300&h=300&fit=crop",
      featured: true,
      active: true,
    },
    {
      name: "ELITE Rank",
      description: "Our top-tier rank: custom chat glow, unlimited realm fly access, instant queue bypass, and weekly diamond crates.",
      price: 49.99,
      categoryId: "cat_ranks",
      thumbnail: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300&h=300&fit=crop",
      featured: true,
      active: true,
    },
    {
      name: "Mythic Crate Key (x5)",
      description: "Open 5 Mythic Crates for a chance at legendary enchants, God armour sets, and ultra-rare pets.",
      price: 4.99,
      categoryId: "cat_keys",
      thumbnail: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=300&h=300&fit=crop",
      featured: false,
      active: true,
    },
    {
      name: "Cosmic Key Bundle (x15)",
      description: "15 Cosmic Keys packed with rare spawner vouchers, booster tokens, and special cosmetic titles.",
      price: 12.99,
      categoryId: "cat_keys",
      thumbnail: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&h=300&fit=crop",
      featured: true,
      active: true,
    },
    {
      name: "1,000 Store Coins",
      description: "Instant in-game credit to spend in realm stores and cosmetic markets.",
      price: 5.00,
      categoryId: "cat_coins",
      thumbnail: "https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=300&h=300&fit=crop",
      featured: false,
      active: true,
    },
    {
      name: "5,000 Store Coins (+500 Bonus)",
      description: "Our most popular coin pack! Includes 500 complimentary bonus coins.",
      price: 20.00,
      categoryId: "cat_coins",
      thumbnail: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=300&h=300&fit=crop",
      featured: true,
      active: true,
    },
    {
      name: "Season Starter Pack",
      description: "The ultimate jumpstart bundle: 1x MVP Rank, 10x Cosmic Keys, 2,500 Store Coins, and exclusive Season Badge.",
      price: 34.99,
      categoryId: "cat_bundles",
      thumbnail: "https://images.unsplash.com/photo-1563089145-599997674d42?w=300&h=300&fit=crop",
      featured: true,
      active: true,
    },
  ];

  const existingProducts = await prisma.product.count();
  if (existingProducts === 0) {
    for (const prod of products) {
      await prisma.product.create({ data: prod });
    }
    console.log("Inserted sample products");
  }

  console.log("Database seeded successfully!");
}

main()
  .catch((e) => {
    console.error("Error seeding database:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
